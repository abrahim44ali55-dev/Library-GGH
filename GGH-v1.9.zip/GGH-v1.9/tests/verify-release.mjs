import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (relativePath) => readFileSync(path.join(root, relativePath), "utf8");

const requiredFiles = [
  "Main",
  "Main.lua",
  "README.md",
  "COMPATIBILITY.md",
  "GGH/Core.lua",
  "GGH/Icons.lua",
  "GGH/Themes.lua",
  "GGH/Utils.lua",
  "GGH/Window.lua",
  "GGH/Elements/Registry.lua",
  "GGH/Systems/ConnectionBag.lua",
  "GGH/Systems/KeySystem.lua",
  "GGH/Systems/Viewport.lua",
];

for (const file of requiredFiles) {
  assert.ok(existsSync(path.join(root, file)), `Missing release file: ${file}`);
}

const remoteEntry = read("Main");
const localEntry = read("Main.lua");
const icons = read("GGH/Icons.lua");
const themes = read("GGH/Themes.lua");
const windowModule = read("GGH/Window.lua");
const keySystem = read("GGH/Systems/KeySystem.lua");
const registry = read("GGH/Elements/Registry.lua");
const compatibility = read("COMPATIBILITY.md");

const remotePaths = [...remoteEntry.matchAll(/loadModule\("([^"]+)"\)/g)].map((match) => match[1]);
assert.ok(remotePaths.length >= 8, "Remote entry must load the modular implementation");
for (const remotePath of remotePaths) {
  assert.ok(existsSync(path.join(root, remotePath)), `Remote module path has no local file: ${remotePath}`);
}

const localModulePaths = [...localEntry.matchAll(/require\((folder(?:\.[A-Za-z0-9_]+)+)\)/g)]
  .map((match) => match[1].replace(/^folder\./, "").replaceAll(".", "/") + ".lua");
assert.ok(localModulePaths.length >= 8, "Local entry must require the modular implementation");
for (const modulePath of localModulePaths) {
  assert.ok(existsSync(path.join(root, "GGH", modulePath)), `Local require path has no file: ${modulePath}`);
}

const iconCount = [...icons.matchAll(/^\s*\["[^"]+"\]\s*=\s*"rbxassetid:\/\/\d+"/gm)].length;
assert.equal(iconCount, 1715, "Icon mapping count changed unexpectedly");

const themeCount = [...themes.matchAll(/^\s*\["[^"]+"\]\s*=\s*\{/gm)].length;
assert.equal(themeCount, 40, "Built-in theme count changed unexpectedly");

for (const publicName of [
  "CreateWindow",
  "CreateTab",
  "AddTab",
  "GetTab",
  "RemoveTab",
  "ClearAllTabs",
  "CreateTheme",
  "AddTheme",
  "GetIcon",
  "HasIcon",
  "ListIcons",
  "SearchIcons",
  "GetHWID",
  "MakeKeySystem",
  "CreateKey",
  "KeySystem",
  "AddKeySystem",
]) {
  assert.ok(
    `${remoteEntry}\n${localEntry}\n${windowModule}\n${keySystem}\n${icons}`.includes(publicName),
    `Missing expected public API name: ${publicName}`,
  );
}

for (const typeName of [
  "section", "paragraph", "button", "toggle", "slider", "input", "dropdown",
  "colorpicker", "keybind", "code", "label", "separator", "image", "linkbutton",
  "playerstats", "floatingbutton", "sliderinput",
]) {
  assert.ok(registry.includes(`typeName == "${typeName}"`), `Missing element type: ${typeName}`);
}

assert.ok(keySystem.includes("No key validation source configured"));
assert.ok(!keySystem.includes("#inputKey >= 3"), "Permissive key-length fallback must stay removed");
assert.ok(remoteEntry.includes("https://raw.githubusercontent.com/abrahim44ali55-dev/Library-GGH/main/"));
assert.ok(windowModule.includes("Viewport.Attach(ScreenGui, Main"));
assert.ok(windowModule.includes('Viewport.Attach(ScreenGui, FloatingIcon'));
assert.ok(windowModule.includes('Viewport.Attach(ScreenGui, btn, buttonResources'));
assert.ok(!windowModule.includes("while FloatingIcon and FloatingIcon.Parent"));
assert.ok(!windowModule.includes("while btn and btn.Parent"));
assert.ok(windowModule.includes("FirstTab = true"));
assert.ok(compatibility.includes("لم يتوفر مترجم Luau"));

console.log(`Release checks passed: ${requiredFiles.length} required files, ${iconCount} icons, ${themeCount} themes, local and remote module paths, and public API smoke checks.`);