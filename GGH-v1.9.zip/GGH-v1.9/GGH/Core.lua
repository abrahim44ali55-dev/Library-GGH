local Core = {}

function Core.new()
	return {
		Version = "v1.9.0",
	}
end

return Core