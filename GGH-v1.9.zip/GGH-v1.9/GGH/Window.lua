return function(GGH, Modules)
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local CoreGui = game:GetService("CoreGui")
local LocalizationService = game:GetService("LocalizationService")
local HttpService = game:GetService("HttpService")
local Themes = Modules.Themes
local GGH_ICONS = GGH.Icons
local ResolveIcon = GGH.ResolveIcon
local Utils = Modules.Utils
local MakeIcon = Utils.MakeIcon
local BindIconToText = Utils.BindIconToText
local GetGuiParent = Utils.GetGuiParent
local MakeTranslatable = Utils.MakeTranslatable
local Corner = Utils.Corner
local Stroke = Utils.Stroke
local AddTextStroke = Utils.AddTextStroke
local SoftStroke = Utils.SoftStroke
local AddBlackBorder = Utils.AddBlackBorder
local Tween = Utils.Tween
local ClampFrameToScreen = Utils.ClampFrameToScreen
local GetSafePickerPosition = Utils.GetSafePickerPosition
local ContrastColor = Utils.ContrastColor
local SmoothDestroy = Utils.SmoothDestroy
local FadeOutGui = Utils.FadeOutGui
local ElementRegistry = Modules.ElementRegistry
local ConnectionBag = Modules.ConnectionBag
local Viewport = Modules.Viewport
function GGH:RegisterTheme(name, overrides, baseName)
	if type(name) ~= "string" or name == "" then
		return false, "Theme name must be a non-empty string"
	end
	if type(overrides) ~= "table" then
		return false, "Theme values must be a table"
	end
	local base = Themes[baseName or "Monochrome"]
	if not base then
		return false, "Base theme was not found"
	end
	local theme = table.clone(base)
	for key, value in pairs(overrides) do
		theme[key] = value
	end
	Themes[name] = theme
	return true, theme
end
GGH.CreateTheme = GGH.RegisterTheme
GGH.AddTheme = GGH.RegisterTheme

function GGH:CreateWindow(Config)
    Config = Config or {}
    if type(Config) ~= "table" then
        error("[GGH v1.9] CreateWindow expects a configuration table.", 2)
    end
    local function ConfigNumber(value, fallback, fieldName)
        if value == nil then return fallback end
        local number = tonumber(value)
        if not number or number ~= number or math.abs(number) == math.huge then
            error("[GGH v1.9] " .. fieldName .. " must be a finite number.", 3)
        end
        return number
    end
    if Config.KeySystem or Config.KeySystemEnabled then
        local Players = game:GetService("Players")
        local HttpService = game:GetService("HttpService")
        local Player = Players.LocalPlayer
        local PlayerGui = Player:WaitForChild("PlayerGui")
        local correctKeys = Config.Key or Config.CorrectKey or "GGH-1234"
        if type(correctKeys) ~= "table" then correctKeys = {correctKeys} end
        local normalizedKeys = {}
        for _, key in ipairs(correctKeys) do
            if key ~= nil then table.insert(normalizedKeys, tostring(key)) end
        end
        correctKeys = normalizedKeys
        local getLink = tostring(Config.GetKeyLink or Config.KeyLink or "https://linkvertise.com")
        local discLink = tostring(Config.DiscordLink or "https://discord.gg")
        local kTitle = tostring(Config.Title or "GGH Library")
        local useHWID = Config.KeyHWID == true or Config.HWID == true or Config.HWIDLock == true
        local useExpire = Config.KeyExpiration == true or Config.Expiration == true or Config.KeyExpires == true
        local duration = ConfigNumber(Config.KeyDuration or Config.Duration, 86400, "KeyDuration")
        if useExpire and duration <= 0 then
            error("[GGH v1.9] KeyDuration must be greater than zero when expiration is enabled.", 2)
        end
        local saveFolder = "GGH_Keys"
        local function getHWID()
            local hwid = "UNKNOWN"
            local ok, res = pcall(function() return gethwid and gethwid() or "" end)
            if ok and res and res ~= "" then hwid = res
            else
                local ok2, res2 = pcall(function() return game:GetService("RbxAnalyticsService"):GetClientId() end)
                if ok2 and res2 ~= "" then hwid = res2
                else hwid = tostring(Player.UserId).."-"..tostring(Player.AccountAge)
                end
            end
            return hwid
        end
        local function loadSavedKey()
            if not (isfolder and isfile and readfile) then return nil end
            if not isfolder(saveFolder) then return nil end
            local hwid = getHWID()
            for _, key in ipairs(correctKeys) do
                local path = saveFolder.."/"..key:gsub("[^%w]", "_")..".json"
                if isfile(path) then
                    local ok, content = pcall(function() return readfile(path) end)
                    if ok and content then
                        local data = {}
                        pcall(function() data = HttpService:JSONDecode(content) end)
                        if useHWID and data.hwid and data.hwid ~= hwid then
                        else
                            if useExpire and data.timestamp then
                                local elapsed = os.time() - data.timestamp
                                if elapsed > duration then
                                    pcall(function() delfile(path) end)
                                else
                                    return {valid=true, key=key, remaining=duration - elapsed}
                                end
                            else
                                return {valid=true, key=key}
                            end
                        end
                    end
                end
            end
            return nil
        end
        local function saveKey(key)
            if not (writefile and isfolder) then return end
            pcall(function()
                if not isfolder(saveFolder) then makefolder(saveFolder) end
                local data = {hwid = getHWID(), timestamp = os.time(), key = key}
                local path = saveFolder.."/"..key:gsub("[^%w]", "_")..".json"
                writefile(path, HttpService:JSONEncode(data))
            end)
        end
        local saved = loadSavedKey()
        local finished = false
        local success = false
        if saved and saved.valid then
            finished = true
            success = true
        else
            local Colors = {
                Background = Color3.fromRGB(18, 18, 22),
                Surface = Color3.fromRGB(25, 25, 30),
                Primary = Color3.fromRGB(45, 45, 50),
                TextPrimary = Color3.fromRGB(220, 220, 225),
                TextSecondary = Color3.fromRGB(140, 140, 150),
                Success = Color3.fromRGB(25, 135, 84),
                Error = Color3.fromRGB(180, 50, 50),
                Discord = Color3.fromRGB(60, 70, 180),
                GetKey = Color3.fromRGB(40, 140, 100),
                Border = Color3.fromRGB(40, 40, 45),
                NeonWhite = Color3.fromRGB(255, 255, 255),
                NeonGlow = Color3.fromRGB(240, 248, 255)
            }
            local screenGui = Instance.new("ScreenGui")
            screenGui.Name = "GGH_KeySystem"
            screenGui.ResetOnSpawn = false
            screenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
            screenGui.DisplayOrder = 200
            screenGui.Parent = PlayerGui
            local backdrop = Instance.new("Frame")
            backdrop.Size = UDim2.new(1,0,1,0)
            backdrop.BackgroundColor3 = Color3.fromRGB(0,0,0)
            backdrop.BackgroundTransparency = 0.2
            backdrop.BorderSizePixel = 0
            backdrop.Parent = screenGui
            local container = Instance.new("Frame")
            container.Size = UDim2.new(0,420,0,540)
            container.Position = UDim2.new(0.5,-210,0.5,-270)
            container.BackgroundColor3 = Colors.Background
            container.BorderSizePixel = 0
            container.Parent = screenGui
            Instance.new("UICorner", container).CornerRadius = UDim.new(0,20)
            local border = Instance.new("Frame")
            border.Size = UDim2.new(1,6,1,6)
            border.Position = UDim2.new(0,-3,0,-3)
            border.BackgroundTransparency = 1
            border.Parent = container
            Instance.new("UICorner", border).CornerRadius = UDim.new(0,23)
            local bStroke = Instance.new("UIStroke", border)
            bStroke.Color = Colors.NeonWhite
            bStroke.Thickness = 2
            bStroke.Transparency = 0.3
            local grad = Instance.new("UIGradient", bStroke)
            grad.Color = ColorSequence.new{ColorSequenceKeypoint.new(0, Colors.NeonWhite), ColorSequenceKeypoint.new(0.5, Colors.NeonGlow), ColorSequenceKeypoint.new(1, Colors.NeonWhite)}
            grad.Transparency = NumberSequence.new{NumberSequenceKeypoint.new(0,0.9), NumberSequenceKeypoint.new(0.2,0.1), NumberSequenceKeypoint.new(0.8,0.1), NumberSequenceKeypoint.new(1,0.9)}
            task.spawn(function() while screenGui.Parent do local tw = TweenService:Create(grad, TweenInfo.new(4, Enum.EasingStyle.Linear), {Rotation = grad.Rotation + 360}) tw:Play() tw.Completed:Wait() end end)
            local iconCont = Instance.new("Frame", container)
            iconCont.Size = UDim2.new(0,56,0,56)
            iconCont.Position = UDim2.new(0.5,-28,0,24)
            iconCont.BackgroundColor3 = Colors.Primary
            iconCont.BorderSizePixel = 0
            Instance.new("UICorner", iconCont).CornerRadius = UDim.new(0,14)
            local icon = Instance.new("ImageLabel", iconCont)
            icon.Size = UDim2.new(0.8,0,0.8,0)
            icon.Position = UDim2.new(0.1,0,0.1,0)
            icon.BackgroundTransparency = 1
            icon.Image = "rbxassetid://95233466475324"
            icon.ImageColor3 = Colors.NeonWhite
            icon.ScaleType = Enum.ScaleType.Fit
            local titleLbl = Instance.new("TextLabel", container)
            titleLbl.Size = UDim2.new(1,-32,0,32)
            titleLbl.Position = UDim2.new(0,16,0,90)
            titleLbl.BackgroundTransparency = 1
            titleLbl.Text = kTitle.." - Key System"
            titleLbl.TextColor3 = Colors.TextPrimary
            titleLbl.TextSize = 20
            titleLbl.Font = Enum.Font.GothamBold
            local sub = Instance.new("TextLabel", container)
            sub.Size = UDim2.new(1,-32,0,30)
            sub.Position = UDim2.new(0,16,0,120)
            sub.BackgroundTransparency = 1
            sub.Text = "Enter your access key to continue"
            sub.TextColor3 = Colors.TextSecondary
            sub.TextSize = 14
            sub.Font = Enum.Font.Gotham
            local infoText = ""
            if useHWID then infoText = infoText.."HWID Lock: ON  " end
            if useExpire then infoText = infoText.."Expires: "..math.floor(duration/3600).."h "..math.floor((duration%3600)/60).."m" end
            if infoText == "" then infoText = "Key System Enabled" end
            local infoLbl = Instance.new("TextLabel", container)
            infoLbl.Size = UDim2.new(1,-32,0,20)
            infoLbl.Position = UDim2.new(0,16,0,148)
            infoLbl.BackgroundTransparency = 1
            infoLbl.Text = infoText
            infoLbl.TextColor3 = Color3.fromRGB(100,180,255)
            infoLbl.TextSize = 11
            infoLbl.Font = Enum.Font.Gotham
            local inputCont = Instance.new("Frame", container)
            inputCont.Size = UDim2.new(1,-64,0,52)
            inputCont.Position = UDim2.new(0,32,0,175)
            inputCont.BackgroundColor3 = Colors.Surface
            inputCont.BorderSizePixel = 0
            Instance.new("UICorner", inputCont).CornerRadius = UDim.new(0,12)
            local textBox = Instance.new("TextBox", inputCont)
            textBox.Size = UDim2.new(1,-24,1,0)
            textBox.Position = UDim2.new(0,12,0,0)
            textBox.BackgroundTransparency = 1
            textBox.Text = ""
            textBox.PlaceholderText = "Enter key here"
            textBox.TextColor3 = Colors.TextPrimary
            textBox.PlaceholderColor3 = Colors.TextSecondary
            textBox.TextSize = 16
            textBox.Font = Enum.Font.Gotham
            textBox.TextXAlignment = Enum.TextXAlignment.Left
            textBox.ClearTextOnFocus = false
            local status = Instance.new("TextLabel", container)
            status.Size = UDim2.new(1,-32,0,30)
            status.Position = UDim2.new(0,16,0,235)
            status.BackgroundTransparency = 1
            status.Text = ""
            status.TextColor3 = Colors.Error
            status.TextSize = 13
            status.Font = Enum.Font.Gotham
            status.TextWrapped = true
            local verifyBtn = Instance.new("TextButton", container)
            verifyBtn.Size = UDim2.new(1,-64,0,48)
            verifyBtn.Position = UDim2.new(0,32,0,275)
            verifyBtn.BackgroundColor3 = Colors.Primary
            verifyBtn.BorderSizePixel = 0
            verifyBtn.Text = "Verify Access Key"
            verifyBtn.TextColor3 = Colors.TextPrimary
            verifyBtn.TextSize = 16
            verifyBtn.Font = Enum.Font.GothamMedium
            Instance.new("UICorner", verifyBtn).CornerRadius = UDim.new(0,12)
            local btnCont = Instance.new("Frame", container)
            btnCont.Size = UDim2.new(1,-64,0,48)
            btnCont.Position = UDim2.new(0,32,0,335)
            btnCont.BackgroundTransparency = 1
            local getKeyBtn = Instance.new("TextButton", btnCont)
            getKeyBtn.Size = UDim2.new(0.48,0,1,0)
            getKeyBtn.BackgroundColor3 = Colors.GetKey
            getKeyBtn.BorderSizePixel = 0
            getKeyBtn.Text = "Get Key"
            getKeyBtn.TextColor3 = Colors.TextPrimary
            getKeyBtn.TextSize = 14
            getKeyBtn.Font = Enum.Font.GothamMedium
            Instance.new("UICorner", getKeyBtn).CornerRadius = UDim.new(0,10)
            local discBtn = Instance.new("TextButton", btnCont)
            discBtn.Size = UDim2.new(0.48,0,1,0)
            discBtn.Position = UDim2.new(0.52,0,0,0)
            discBtn.BackgroundColor3 = Colors.Discord
            discBtn.BorderSizePixel = 0
            discBtn.Text = "Discord"
            discBtn.TextColor3 = Colors.TextPrimary
            discBtn.TextSize = 14
            discBtn.Font = Enum.Font.GothamMedium
            Instance.new("UICorner", discBtn).CornerRadius = UDim.new(0,10)
            local hwidLbl = Instance.new("TextLabel", container)
            hwidLbl.Size = UDim2.new(1,-32,0,20)
            hwidLbl.Position = UDim2.new(0,16,0,395)
            hwidLbl.BackgroundTransparency = 1
            hwidLbl.Text = "HWID: "..getHWID():sub(1,32).."... (Click to copy)"
            hwidLbl.TextColor3 = Colors.TextSecondary
            hwidLbl.TextSize = 10
            hwidLbl.Font = Enum.Font.Code
            hwidLbl.TextWrapped = true
            local hwidBtn = Instance.new("TextButton", container)
            hwidBtn.Size = UDim2.new(1,-64,0,30)
            hwidBtn.Position = UDim2.new(0,32,0,395)
            hwidBtn.BackgroundTransparency = 1
            hwidBtn.Text = ""
            local timerLbl = Instance.new("TextLabel", container)
            timerLbl.Size = UDim2.new(1,-32,0,20)
            timerLbl.Position = UDim2.new(0,16,0,420)
            timerLbl.BackgroundTransparency = 1
            timerLbl.Text = useExpire and "Key will expire after "..duration.." seconds" or "Key never expires"
            timerLbl.TextColor3 = Colors.TextSecondary
            timerLbl.TextSize = 10
            timerLbl.Font = Enum.Font.Gotham
            local function checkKey(k) for _, v in ipairs(correctKeys) do if k==v then return true end end return false end
            local function doVerify()
                local k = textBox.Text
                if k=="" then status.Text="Please enter an access key" status.TextColor3=Colors.Error return end
                if checkKey(k) then
                    if useHWID then
                        local existingPath = saveFolder.."/"..k:gsub("[^%w]", "_")..".json"
                        if isfile and isfile(existingPath) then
                            local ok, content = pcall(function() return readfile(existingPath) end)
                            if ok and content then
                                local data = {}
                                pcall(function() data = HttpService:JSONDecode(content) end)
                                if data.hwid and data.hwid ~= getHWID() then
                                    status.Text="HWID Mismatch! Key bound to another device." status.TextColor3=Colors.Error
                                    return
                                end
                            end
                        end
                    end
                    status.Text="Key correct! Loading..." status.TextColor3=Colors.Success
                    saveKey(k)
                    TweenService:Create(container, TweenInfo.new(0.3, Enum.EasingStyle.Quad), {Size=UDim2.new(0,0,0,0)}):Play()
                    task.wait(0.35)
                    screenGui:Destroy()
                    success=true finished=true
                else
                    status.Text="Wrong key! Please try again." status.TextColor3=Colors.Error
                    local orig=container.Position
                    for i=1,6 do container.Position=orig+UDim2.new(0,(i%2==0 and 6 or -6),0,0) task.wait(0.05) end
                    container.Position=orig
                end
            end
            verifyBtn.MouseButton1Click:Connect(doVerify)
            textBox.FocusLost:Connect(function(enter) if enter then doVerify() end end)
            getKeyBtn.MouseButton1Click:Connect(function() if setclipboard then setclipboard(getLink) end status.Text="Get Key link copied!" status.TextColor3=Colors.Success end)
            discBtn.MouseButton1Click:Connect(function() if setclipboard then setclipboard(discLink) end status.Text="Discord link copied!" status.TextColor3=Colors.Success end)
            hwidBtn.MouseButton1Click:Connect(function() if setclipboard then setclipboard(getHWID()) end status.Text="HWID copied!" status.TextColor3=Colors.Success end)
            container.Size=UDim2.new(0,0,0,0)
            TweenService:Create(container, TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {Size=UDim2.new(0,420,0,540)}):Play()
            repeat task.wait(0.1) until finished
        end
        if not success then return nil end
    end
    local function GetLuminance(c)
        return 0.299*c.R + 0.587*c.G + 0.114*c.B
    end
    local function AutoTextColors(theme)
        theme = table.clone(theme)
        local lum = GetLuminance(theme.MainBg)
        if lum > 0.5 then
            theme.Text = Color3.fromRGB(20,20,25)
            theme.SubText = Color3.fromRGB(80,80,85)
            theme.SectionText = Color3.fromRGB(100,100,105)
            theme.ParagraphText = Color3.fromRGB(40,40,45)
        else
            theme.Text = Color3.fromRGB(240,240,245)
            theme.SubText = Color3.fromRGB(180,180,190)
            theme.SectionText = Color3.fromRGB(150,150,160)
            theme.ParagraphText = Color3.fromRGB(220,220,230)
        end
        return theme
    end
    local ScreenGui = Instance.new("ScreenGui")
    ScreenGui.Name = "GGH_Library"
    ScreenGui.ResetOnSpawn = false
    ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    pcall(function() ScreenGui.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets end)
    local windowResources = ConnectionBag.new()
    windowResources:Connect(ScreenGui.Destroying, function()
        windowResources:Destroy()
    end)
    local function TrackConnection(connection)
        return windowResources:Add(connection)
    end
    if Config.DeferEnable ~= false then
        ScreenGui.Enabled = false
        local lastAdd = os.clock()
        local addConn = TrackConnection(ScreenGui.DescendantAdded:Connect(function() lastAdd = os.clock() end))
        task.spawn(function()
            local t0 = os.clock()
            repeat task.wait() until os.clock() - lastAdd > 0.25 or os.clock() - t0 > 4
            addConn:Disconnect()
            if ScreenGui.Parent then ScreenGui.Enabled = true end
        end)
    end
    ScreenGui.Parent = GetGuiParent()
    local SizePresets = {
        ["Tiny"]   = {W=360, H=260},
        ["Small"]  = {W=400, H=300},
        ["Medium"] = {W=460, H=340},
        ["Large"]  = {W=520, H=380},
        ["Huge"]   = {W=600, H=440},
    }
    local function DetectDevicePreset()
        local cam = workspace.CurrentCamera
        local vp = cam and cam.ViewportSize or Vector2.new(1920,1080)
        local isTouch = UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled
        local isSmallTouch = UserInputService.TouchEnabled
        if vp.X < 500 or vp.Y < 500 then
            return SizePresets.Tiny, "Tiny"
        elseif vp.X < 700 or isTouch then
            return SizePresets.Small, "Small"
        elseif vp.X < 1100 or isSmallTouch then
            return SizePresets.Medium, "Medium"
        elseif vp.X < 1600 then
            return SizePresets.Large, "Large"
        else
            return SizePresets.Huge, "Huge"
        end
    end

    local autoPreset, autoName = DetectDevicePreset()
    local finalW = ConfigNumber(Config.Width, autoPreset.W, "Width")
    local finalH = ConfigNumber(Config.Height, autoPreset.H, "Height")
    if finalW <= 0 or finalH <= 0 then
        error("[GGH v1.9] Width and Height must be greater than zero.", 2)
    end
    if Config.SizePreset and SizePresets[Config.SizePreset] then
        finalW = SizePresets[Config.SizePreset].W
        finalH = SizePresets[Config.SizePreset].H
        autoName = Config.SizePreset
    end
    local Title = tostring(Config.Title or "GGH Library")
    local SubTitle = tostring(Config.SubTitle or ("v1.9 [" .. autoName .. "]"))
    local DefaultTheme = Config.Theme or "Monochrome"
    if not Themes[DefaultTheme] then DefaultTheme = "Monochrome" end
    local CurrentTheme = AutoTextColors(Themes[DefaultTheme])

    local Main = Instance.new("Frame")
    Main.Name = "Main"
    Main.Size = UDim2.new(0, finalW, 0, finalH)
    Main.Position = UDim2.new(0.5, -finalW/2, 0.5, -finalH/2)
    Main.BackgroundColor3 = CurrentTheme.MainBg
    local WindowTrans = ConfigNumber(Config.WindowTransparency or Config.WindowTrans or Config.Transparency or Config.BackgroundTransparency, 0.1, "WindowTransparency")
    local ElementTrans = ConfigNumber(Config.ElementTransparency or Config.ElementTrans or Config.ElementsTransparency, 0.05, "ElementTransparency")
    if WindowTrans > 1 then WindowTrans = WindowTrans/100 end
    if ElementTrans > 1 then ElementTrans = ElementTrans/100 end
    WindowTrans = math.clamp(WindowTrans,0,0.7)
    ElementTrans = math.clamp(ElementTrans,0,0.7)
    Main.BackgroundTransparency = WindowTrans
    Main.BorderSizePixel = 0
    Main.ClipsDescendants = true
    Main.Parent = ScreenGui
    Viewport.Attach(ScreenGui, Main, windowResources, "inside", 4)
    Corner(Main, 18)
    if Config.BackgroundImage or Config.Background or Config.BgImage then
        local bgSrc = Config.BackgroundImage or Config.Background or Config.BgImage
        local function extractId(text)
            if not text then return nil end
            text = tostring(text)
            local id = text:match("id=(%d+)") or text:match("rbxassetid://(%d+)") or text:match("(%d+)")
            return id
        end
        local bgId = extractId(bgSrc)
        local bgImg
        if bgId then
            bgImg = "rbxassetid://"..bgId
        else
            bgImg = bgSrc
        end
        local BgImage = Instance.new("ImageLabel", Main)
        BgImage.Name = "BackgroundImage"
        BgImage.Size = UDim2.new(1,0,1,0)
        BgImage.Position = UDim2.new(0,0,0,0)
        BgImage.BackgroundTransparency = 1
        BgImage.Image = bgImg
        BgImage.ImageTransparency = Config.BgTransparency or Config.BackgroundTransparency or 0.2
        BgImage.ScaleType = Config.BgScaleType or Enum.ScaleType.Crop
        BgImage.ZIndex = 0
        Corner(BgImage, 18)
        if not Config.BackgroundTransparency then
            Main.BackgroundTransparency = 0.1
        end
    end

    local MainStroke = Stroke(Main, CurrentTheme.Stroke, 1)
    MainStroke.Name = "MainStroke"
    MainStroke.Transparency = 0.5
    local Header = Instance.new("Frame", Main)
    Header.Name = "Header"
    Header.Size = UDim2.new(1,0,0,52)
    Header.BackgroundColor3 = CurrentTheme.HeaderBg
    Header.BackgroundTransparency = WindowTrans
    Header.BorderSizePixel = 0
    Header.ZIndex = 20
    Corner(Header, 18)
    local HeaderFix = Instance.new("Frame", Header)
    HeaderFix.Name = "HeaderFix"
    HeaderFix.Size = UDim2.new(1,0,0,18)
    HeaderFix.Position = UDim2.new(0,0,1,-9)
    HeaderFix.BackgroundColor3 = CurrentTheme.HeaderBg
    HeaderFix.BackgroundTransparency = WindowTrans
    HeaderFix.BorderSizePixel = 0
    HeaderFix.ZIndex = 19
    GGH.SizePresets = SizePresets
    local AccentLine = Instance.new("Frame", Header)
    AccentLine.Size = UDim2.new(1,0,0,1)
    AccentLine.Position = UDim2.new(0,0,1,0)
    AccentLine.BackgroundColor3 = CurrentTheme.Accent
    AccentLine.BackgroundTransparency = 0.6
    AccentLine.ZIndex = 21
    AccentLine.BorderSizePixel = 0
    local TitleLabel = Instance.new("TextLabel", Header)
    TitleLabel.Text = Title
    TitleLabel.Position = UDim2.new(0,18,0,7)
    TitleLabel.Size = UDim2.new(0,180,0,18)
    TitleLabel.BackgroundTransparency = 1
    TitleLabel.TextXAlignment = Enum.TextXAlignment.Left
    TitleLabel.Font = Enum.Font.GothamBold
    TitleLabel.TextSize = 15
    TitleLabel.TextColor3 = CurrentTheme.Text
    TitleLabel.ZIndex = 4
    TitleLabel.AutoLocalize = true AddTextStroke(TitleLabel)
    local SubLabel = Instance.new("TextLabel", Header)
    SubLabel.Text = SubTitle
    SubLabel.Position = UDim2.new(0,18,0,26)
    SubLabel.Size = UDim2.new(0,180,0,12)
    SubLabel.BackgroundTransparency = 1
    SubLabel.TextXAlignment = Enum.TextXAlignment.Left
    SubLabel.Font = Enum.Font.Gotham
    SubLabel.TextSize = 11
    SubLabel.TextColor3 = CurrentTheme.SubText
    SubLabel.ZIndex = 4
    SubLabel.AutoLocalize = true AddTextStroke(SubLabel)
    local WindowIconValue = Config.Icon or Config.TitleIcon or Config.UIIcon or Config.WindowIcon or Config.Logo
    local TitleIconImg = Instance.new("ImageLabel", Header)
    TitleIconImg.Name = "TitleIcon"
    TitleIconImg.Size = UDim2.new(0, 24, 0, 24)
    TitleIconImg.Position = UDim2.new(0, 14, 0.5, -12)
    TitleIconImg.BackgroundTransparency = 1
    TitleIconImg.ScaleType = Enum.ScaleType.Fit
    TitleIconImg.ImageColor3 = CurrentTheme.Accent
    TitleIconImg.ZIndex = 4
    TitleIconImg.Visible = false
    local GGH_UpdateHeader
    local function ApplyTitleIcon(icon)
        WindowIconValue = icon
        local res = ResolveIcon(icon)
        if res then
            TitleIconImg.Image = res
            TitleIconImg.Visible = true
            TitleLabel.Position = UDim2.new(0, 46, 0, 7)
            SubLabel.Position = UDim2.new(0, 46, 0, 26)
        else
            TitleIconImg.Image = ""
            TitleIconImg.Visible = false
            TitleLabel.Position = UDim2.new(0, 18, 0, 7)
            SubLabel.Position = UDim2.new(0, 18, 0, 26)
        end
        if GGH_UpdateHeader then GGH_UpdateHeader() end
    end
    ApplyTitleIcon(WindowIconValue)

    local Controls = Instance.new("CanvasGroup", Header)
    Controls.Size = UDim2.new(0,200,0,32)
    Controls.Position = UDim2.new(1,-208,0.5,-16)
    Controls.BackgroundTransparency = 1
    Controls.ZIndex = 10
    Controls.ClipsDescendants = false
    local ControlsLayout = Instance.new("UIListLayout", Controls)
    ControlsLayout.FillDirection = Enum.FillDirection.Horizontal
    ControlsLayout.Padding = UDim.new(0,6)
    ControlsLayout.SortOrder = Enum.SortOrder.LayoutOrder
    ControlsLayout.HorizontalAlignment = Enum.HorizontalAlignment.Right

    local showSearch = true
    local showSettings = true
    local showFloat = true
    if Config.HideButtons then
        for _, v in ipairs(Config.HideButtons) do
            local lv = string.lower(tostring(v))
            if lv == "search" then showSearch = false end
            if lv == "theme" or lv == "settings" then showSettings = false end
            if lv == "float" or lv == "floating" then showFloat = false end
        end
    end
    if Config.DisableSearchButton then showSearch = false end
    if Config.DisableThemeButton then showSettings = false end
    if Config.DisableFloatButton then showFloat = false end

    local function CreateCtrlButton(name, text, bg, iconName)
        local btn = Instance.new("TextButton", Controls)
        btn.Name = name
        btn.Size = UDim2.new(0,32,0,32)
        btn.BackgroundColor3 = bg
        btn.BackgroundTransparency = 0
        btn.Text = text
        btn.Font = Enum.Font.GothamBold
        btn.TextSize = 14
        btn.TextColor3 = (name=="CloseBtn") and CurrentTheme.CloseText or CurrentTheme.Text
        btn.ZIndex = 25
        btn.AutoButtonColor = false
        btn.LayoutOrder = 10
        Corner(btn, 10)
        if iconName then
            btn.Text = ""
            local ic = MakeIcon(btn, iconName, 18)
            ic.AnchorPoint = Vector2.new(0.5, 0.5)
            ic.Position = UDim2.fromScale(0.5, 0.5)
            ic.ZIndex = 26
            BindIconToText(btn, ic)
        end
        return btn
    end

    local SearchBtn, ThemeBtn, FloatBtn
    local MinBtn, MaxBtn, CloseBtn
    local order = 1

    if showSearch then
        SearchBtn = CreateCtrlButton("SearchBtn", "", CurrentTheme.ElementBg2, "search")
        SearchBtn.LayoutOrder = order; order+=1
    end
    if showSettings then
        ThemeBtn = CreateCtrlButton("ThemeBtn", "", CurrentTheme.ElementBg2, "settings")
        ThemeBtn.LayoutOrder = order; order+=1
    end
    MinBtn = CreateCtrlButton("MinBtn", "", CurrentTheme.ElementBg2, "minus")
    MinBtn.TextSize = 20
    MinBtn.LayoutOrder = order; order+=1
    MaxBtn = CreateCtrlButton("MaxBtn", "", CurrentTheme.ElementBg2, "plus")
    MaxBtn.TextSize = 20
    MaxBtn.LayoutOrder = order; order+=1
    MaxBtn.Visible = false
    if showFloat then
        FloatBtn = CreateCtrlButton("FloatBtn", "", CurrentTheme.ElementBg2, "circle-dot")
        FloatBtn.LayoutOrder = order; order+=1
    end
    CloseBtn = CreateCtrlButton("CloseBtn", "", CurrentTheme.CloseBg, "x")
    CloseBtn.LayoutOrder = order; order+=1
    CloseBtn.TextSize = 13

    local visibleCount = 0
    if showSearch then visibleCount+=1 end
    if showSettings then visibleCount+=1 end
    visibleCount+=1
    visibleCount+=1
    if showFloat then visibleCount+=1 end
    local totalW = visibleCount*32 + (visibleCount-1)*6
    Controls.Size = UDim2.new(0, totalW, 0, 32)
    Controls.Position = UDim2.new(1, -totalW - 8, 0.5, -16)

    do
        local holding = false
        TitleLabel.TextTruncate = Enum.TextTruncate.AtEnd
        SubLabel.TextTruncate = Enum.TextTruncate.AtEnd
        local function layout(animate)
            local w = Main.AbsoluteSize.X
            if w <= 0 then return end
            local x = TitleIconImg.Visible and 46 or 18
            local avail = holding and (w - x - 14) or (w - x - (totalW + 8) - 12)
            avail = math.max(avail, 40)
            local ts, ss = UDim2.new(0, avail, 0, 18), UDim2.new(0, avail, 0, 12)
            if animate then
                Tween(TitleLabel, {Size = ts}, 0.2)
                Tween(SubLabel, {Size = ss}, 0.2)
            else
                TitleLabel.Size = ts
                SubLabel.Size = ss
            end
        end
        GGH_UpdateHeader = function() layout(false) end
        Main:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() if not holding then layout(false) end end)
        task.defer(layout, false)
        task.delay(0.5, function() if not holding then layout(false) end end)

        local function setHold(state)
            if holding == state then return end
            holding = state
            if state then
                Tween(Controls, {GroupTransparency = 1}, 0.18)
                task.delay(0.18, function() if holding then Controls.Visible = false end end)
            else
                Controls.Visible = true
                Tween(Controls, {GroupTransparency = 0}, 0.22)
            end
            layout(true)
        end
        for _, obj in ipairs({TitleLabel, SubLabel, TitleIconImg}) do
            obj.InputBegan:Connect(function(input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                    setHold(true)
                end
            end)
        end
        TrackConnection(UserInputService.InputEnded:Connect(function(input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                setHold(false)
            end
        end))
    end

    local SearchBar = Instance.new("Frame", Main)
    SearchBar.Name = "SearchBar"
    SearchBar.Size = UDim2.new(1,-16,0,0)
    SearchBar.Position = UDim2.new(0,8,0,56)
    SearchBar.BackgroundColor3 = CurrentTheme.ElementBg
    SearchBar.Visible = false
    SearchBar.ZIndex = 90
    SearchBar.ClipsDescendants = true
    Corner(SearchBar, 10)
    local SBStroke = Stroke(SearchBar, CurrentTheme.Accent, 1)
    SBStroke.Name = "SearchStroke"
    local SearchBox = Instance.new("TextBox", SearchBar)
    SearchBox.Size = UDim2.new(1,-50,1,-6)
    SearchBox.Position = UDim2.new(0,14,0,3)
    SearchBox.BackgroundTransparency = 1
    SearchBox.PlaceholderText = "Search toggles, buttons, tabs..."
    SearchBox.Text = ""
    SearchBox.Font = Enum.Font.Gotham
    SearchBox.TextSize = 13
    SearchBox.TextColor3 = CurrentTheme.Text
    SearchBox.PlaceholderColor3 = CurrentTheme.SubText
    SearchBox.TextXAlignment = Enum.TextXAlignment.Left
    SearchBox.ClearTextOnFocus = false
    SearchBox.ZIndex = 91
    SearchBox.AutoLocalize = true
    local SearchClose = Instance.new("TextButton", SearchBar)
    SearchClose.Size = UDim2.new(0,28,0,28)
    SearchClose.Position = UDim2.new(1,-32,0.5,-14)
    SearchClose.BackgroundColor3 = CurrentTheme.ElementBg2
    SearchClose.Text = ""
    SearchClose.Font = Enum.Font.GothamBold
    SearchClose.TextSize = 12
    SearchClose.TextColor3 = CurrentTheme.Text
    SearchClose.ZIndex = 91
    Corner(SearchClose, 7)
    do
        local scIcon = MakeIcon(SearchClose, "x", 14)
        scIcon.AnchorPoint = Vector2.new(0.5, 0.5)
        scIcon.Position = UDim2.fromScale(0.5, 0.5)
        scIcon.ZIndex = 92
        BindIconToText(SearchClose, scIcon)
    end
    local ThemeDropdown = Instance.new("Frame", Main)
    ThemeDropdown.Name = "ThemeDropdown"
    ThemeDropdown.Size = UDim2.new(0,220,0,0)
    ThemeDropdown.Position = UDim2.new(1,-228,0,56)
    ThemeDropdown.BackgroundColor3 = CurrentTheme.ElementBg
    ThemeDropdown.Visible = false
    ThemeDropdown.ZIndex = 100
    ThemeDropdown.ClipsDescendants = true
    Corner(ThemeDropdown, 12)
    Stroke(ThemeDropdown, CurrentTheme.Stroke, 1)

    local ThemeList = Instance.new("ScrollingFrame", ThemeDropdown)
    ThemeList.Size = UDim2.new(1,-8,1,-8)
    ThemeList.Position = UDim2.new(0,4,0,4)
    ThemeList.BackgroundTransparency = 1
    ThemeList.CanvasSize = UDim2.new(0,0,0,0)
    ThemeList.AutomaticCanvasSize = Enum.AutomaticSize.Y
    ThemeList.ScrollBarThickness = 3
    ThemeList.ScrollBarImageColor3 = CurrentTheme.Accent
    ThemeList.ZIndex = 101
    ThemeList.ClipsDescendants = true
    ThemeList.ScrollingDirection = Enum.ScrollingDirection.Y
    local TL = Instance.new("UIListLayout", ThemeList)
    TL.Padding = UDim.new(0,6)
    TL.SortOrder = Enum.SortOrder.LayoutOrder
    local TLP = Instance.new("UIPadding", ThemeList)
    TLP.PaddingTop = UDim.new(0,8) TLP.PaddingBottom = UDim.new(0,8) TLP.PaddingLeft = UDim.new(0,8) TLP.PaddingRight = UDim.new(0,8)

    local ThemeHeader = Instance.new("TextLabel", ThemeList)
    ThemeHeader.Size = UDim2.new(1,0,0,20)
    ThemeHeader.BackgroundTransparency = 1
    ThemeHeader.Text = "SETTINGS"
    ThemeHeader.Font = Enum.Font.GothamBold
    ThemeHeader.TextSize = 11
    ThemeHeader.TextColor3 = CurrentTheme.Text
    ThemeHeader.TextXAlignment = Enum.TextXAlignment.Left
    ThemeHeader.LayoutOrder = -100
    AddTextStroke(ThemeHeader)

    local SaveToggleFrame = Instance.new("Frame", ThemeList)
    SaveToggleFrame.Size = UDim2.new(1,0,0,38)
    SaveToggleFrame.BackgroundColor3 = CurrentTheme.ElementBg2
    SaveToggleFrame.LayoutOrder = -90
    Corner(SaveToggleFrame, 8)
    Stroke(SaveToggleFrame, CurrentTheme.Stroke, 1)

    local SaveTitle = Instance.new("TextLabel", SaveToggleFrame)
    SaveTitle.Size = UDim2.new(1,-56,1,0)
    SaveTitle.Position = UDim2.new(0,10,0,0)
    SaveTitle.BackgroundTransparency = 1
    SaveTitle.Text = "Save Settings"
    SaveTitle.Font = Enum.Font.GothamMedium
    SaveTitle.TextSize = 12
    SaveTitle.TextColor3 = CurrentTheme.Text
    SaveTitle.TextXAlignment = Enum.TextXAlignment.Left
    AddTextStroke(SaveTitle)

    local SaveToggleBg = Instance.new("Frame", SaveToggleFrame)
    SaveToggleBg.Size = UDim2.new(0,44,0,22)
    SaveToggleBg.Position = UDim2.new(1,-50,0.5,-11)
    SaveToggleBg.BackgroundColor3 = CurrentTheme.ElementBg
    Corner(SaveToggleBg, 11)

    local SaveCircle = Instance.new("Frame", SaveToggleBg)
    SaveCircle.Size = UDim2.new(0,16,0,16)
    SaveCircle.Position = UDim2.new(0,3,0.5,-8)
    SaveCircle.BackgroundColor3 = Color3.fromRGB(255,255,255)
    Corner(SaveCircle, 8)

    local SaveToggleBtn = Instance.new("TextButton", SaveToggleFrame)
    SaveToggleBtn.Size = UDim2.new(1,0,1,0)
    SaveToggleBtn.BackgroundTransparency = 1
    SaveToggleBtn.Text = ""

    local Sep1 = Instance.new("Frame", ThemeList)
    Sep1.Size = UDim2.new(1,0,0,1)
    Sep1.BackgroundColor3 = CurrentTheme.Stroke
    Sep1.BackgroundTransparency = 0.5
    Sep1.LayoutOrder = -85

    local TabList = Instance.new("ScrollingFrame", Main)
    TabList.Name = "TabList"
    TabList.Size = UDim2.new(0,140,1,-64)
    TabList.Position = UDim2.new(0,8,0,58)
    TabList.BackgroundColor3 = CurrentTheme.TabListBg
    TabList.BackgroundTransparency = WindowTrans
    TabList.BorderSizePixel = 0
    TabList.CanvasSize = UDim2.new(0,0,0,0)
    TabList.AutomaticCanvasSize = Enum.AutomaticSize.Y
    TabList.ScrollBarThickness = 3
    TabList.ScrollBarImageColor3 = CurrentTheme.Accent
    TabList.ClipsDescendants = true
    TabList.ZIndex = 15
    Corner(TabList, 12)
    local TLLayout = Instance.new("UIListLayout", TabList)
    TLLayout.Padding = UDim.new(0,6)
    TLLayout.SortOrder = Enum.SortOrder.LayoutOrder
    local TLP2 = Instance.new("UIPadding", TabList)
    TLP2.PaddingTop = UDim.new(0,6) TLP2.PaddingBottom = UDim.new(0,6) TLP2.PaddingLeft = UDim.new(0,6) TLP2.PaddingRight = UDim.new(0,6)
    local Container = Instance.new("Frame", Main)
    Container.Name = "Container"
    Container.Size = UDim2.new(1,-160,1,-64)
    Container.Position = UDim2.new(0,152,0,58)
    Container.BackgroundTransparency = 1
    Container.ClipsDescendants = true
    Container.ZIndex = 15
    local ConfirmFrame = Instance.new("Frame", ScreenGui)
    ConfirmFrame.Name = "ConfirmOverlay"
    ConfirmFrame.Size = Main.Size
    ConfirmFrame.Position = Main.Position
    ConfirmFrame.BackgroundColor3 = Color3.fromRGB(0,0,0)
    ConfirmFrame.BackgroundTransparency = 0.6
    ConfirmFrame.Visible = false
    ConfirmFrame.ZIndex = 200
    Corner(ConfirmFrame, 16)
    Main:GetPropertyChangedSignal("Position"):Connect(function() ConfirmFrame.Position = Main.Position end)
    Main:GetPropertyChangedSignal("Size"):Connect(function() if not ConfirmFrame.Visible then ConfirmFrame.Size = Main.Size end end)
    local ConfirmBox = Instance.new("Frame", ConfirmFrame)
    ConfirmBox.Size = UDim2.new(0,300,0,160)
    ConfirmBox.Position = UDim2.new(0.5,-150,0.5,-80)
    ConfirmBox.BackgroundColor3 = CurrentTheme.ElementBg
    ConfirmBox.ZIndex = 201
    Corner(ConfirmBox, 14)
    Stroke(ConfirmBox, CurrentTheme.Stroke, 1)
    local CT = Instance.new("TextLabel", ConfirmBox)
    CT.Text = "Confirm Close"
    CT.Size = UDim2.new(1,-20,0,24)
    CT.Position = UDim2.new(0,10,0,14)
    CT.BackgroundTransparency = 1
    CT.Font = Enum.Font.GothamBold
    CT.TextSize = 16
    CT.TextColor3 = CurrentTheme.Text
    CT.TextXAlignment = Enum.TextXAlignment.Left
    CT.ZIndex = 202
    CT.AutoLocalize = true AddTextStroke(CT)
    local CT2 = Instance.new("TextLabel", ConfirmBox)
    CT2.Text = "Are you sure you want to close GGH Library?"
    CT2.Size = UDim2.new(1,-20,0,44)
    CT2.Position = UDim2.new(0,10,0,44)
    CT2.BackgroundTransparency = 1
    CT2.TextWrapped = true
    CT2.Font = Enum.Font.Gotham
    CT2.TextSize = 12
    CT2.TextColor3 = CurrentTheme.SubText
    CT2.TextXAlignment = Enum.TextXAlignment.Left
    CT2.ZIndex = 202
    CT2.AutoLocalize = true AddTextStroke(CT2)
    local YesBtn = Instance.new("TextButton", ConfirmBox)
    YesBtn.Size = UDim2.new(0,120,0,36)
    YesBtn.Position = UDim2.new(0,20,1,-48)
    YesBtn.BackgroundColor3 = CurrentTheme.Accent
    YesBtn.Text = "Yes, Close"
    YesBtn.Font = Enum.Font.GothamBold
    YesBtn.TextSize = 13
    YesBtn.TextColor3 = Color3.fromRGB(255,255,255)
    YesBtn.ZIndex = 202
    YesBtn.AutoLocalize = true AddTextStroke(YesBtn)
    Corner(YesBtn, 9)
    local NoBtn = Instance.new("TextButton", ConfirmBox)
    NoBtn.Size = UDim2.new(0,120,0,36)
    NoBtn.Position = UDim2.new(1,-140,1,-48)
    NoBtn.BackgroundColor3 = CurrentTheme.ElementBg2
    NoBtn.Text = "Cancel"
    NoBtn.Font = Enum.Font.GothamBold
    NoBtn.TextSize = 13
    NoBtn.TextColor3 = CurrentTheme.Text
    NoBtn.ZIndex = 202
    NoBtn.AutoLocalize = true AddTextStroke(NoBtn)
    Corner(NoBtn, 9)
    do
        local dragging = false
        local potentialDrag = false
        local dragStart, startPos
        local DRAG_THRESHOLD = 8
        local dragObjects = {Header, TitleLabel, SubLabel, HeaderFix}
        local function updateScreenSizeMain()
            local viewportSize = ScreenGui.AbsoluteSize
            local currentPos = Main.Position
            local buttonSize = Main.AbsoluteSize
            if buttonSize.X == 0 then return end
            local clampedX = math.clamp(currentPos.X.Offset, 0, viewportSize.X - buttonSize.X)
            local clampedY = math.clamp(currentPos.Y.Offset, 0, viewportSize.Y - buttonSize.Y)
            if clampedX ~= currentPos.X.Offset or clampedY ~= currentPos.Y.Offset then
                Main.Position = UDim2.fromOffset(clampedX, clampedY)
            end
            ClampFrameToScreen(Main, ScreenGui)
        end
        local function ApplyResponsiveSize()
            local vp = ScreenGui.AbsoluteSize
            if vp.X < 100 or vp.Y < 100 then return end
            local maxW = math.clamp(vp.X * 0.88, 340, 620)
            local maxH = math.clamp(vp.Y * 0.78, 300, 500)
            local curSize = Main.AbsoluteSize
            if curSize.X > vp.X - 20 or curSize.Y > vp.Y - 80 then
                Main.Size = UDim2.fromOffset(math.min(curSize.X, maxW), math.min(curSize.Y, maxH))
            end
            ClampFrameToScreen(Main, ScreenGui)
        end

        local oldUpdate = updateScreenSizeMain
        local function newUpdateWrapper()
            oldUpdate()
            ApplyResponsiveSize()
        end
        ScreenGui:GetPropertyChangedSignal("AbsoluteSize"):Connect(newUpdateWrapper)
        task.spawn(function() task.wait(0.2) newUpdateWrapper() end)
        ApplyResponsiveSize()

        local function StartDrag(input)
            if ScreenGui:FindFirstChild("GGH_ColorPicker_Overlay") then return end
            if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                potentialDrag = true
                dragging = false
                dragStart = input.Position
                startPos = Main.Position
            end
        end
        for _, obj in ipairs(dragObjects) do obj.InputBegan:Connect(StartDrag) end
        TrackConnection(UserInputService.InputChanged:Connect(function(input)
            if potentialDrag and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
                local delta = input.Position - dragStart
                if not dragging and delta.Magnitude >= DRAG_THRESHOLD then dragging = true end
                if dragging then
                    local newX = startPos.X.Offset + delta.X
                    local newY = startPos.Y.Offset + delta.Y
                    local viewportSize = ScreenGui.AbsoluteSize
                    local frameSize = Main.AbsoluteSize
                    local clampedX = math.clamp(newX, -20, viewportSize.X - frameSize.X + 20)
                    local clampedY = math.clamp(newY, -36, viewportSize.Y - frameSize.Y + 20)
                    Main.Position = UDim2.fromOffset(clampedX, clampedY)
                end
            end
        end))
        TrackConnection(UserInputService.InputEnded:Connect(function(input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then dragging = false potentialDrag = false end
        end))
    end
    local ResizeGrip = Instance.new("Frame", Main)
    ResizeGrip.Name = "ResizeGrip"
    ResizeGrip.Size = UDim2.new(0,20,0,20)
    ResizeGrip.Position = UDim2.new(1,-20,1,-20)
    ResizeGrip.BackgroundTransparency = 1
    ResizeGrip.ZIndex = 50
    ResizeGrip.Visible = true
    for i=1,3 do
        local line = Instance.new("Frame", ResizeGrip)
        line.Size = UDim2.new(0, 12 - (i*2), 0, 1.5)
        line.Position = UDim2.new(1, -12 + (i*2) -1, 1, -12 + (i*2) -1)
        line.BackgroundColor3 = CurrentTheme.SubText
        line.BackgroundTransparency = 0.4
        line.BorderSizePixel = 0
        line.Rotation = -45
        line.ZIndex = 51
    end

    local minimized = false
    local savedSize = Main.Size
    local baseSize = Main.Size

    local function UpdateResizeGrip()
        if minimized then
            ResizeGrip.Visible = false
            return
        end
        ResizeGrip.Visible = true
    end
    Main:GetPropertyChangedSignal("AbsoluteSize"):Connect(UpdateResizeGrip)
    task.spawn(function() task.wait(0.5) UpdateResizeGrip() end)
    local resizing = false
    local resizeStart, startSize
    ResizeGrip.InputBegan:Connect(function(input)
        if minimized then return end
        if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
            resizing = true
            resizeStart = input.Position
            startSize = Main.Size
        end
    end)
    TrackConnection(UserInputService.InputChanged:Connect(function(input)
        if resizing and not minimized and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
            local delta = input.Position - resizeStart
            local newW = math.clamp(startSize.X.Offset + delta.X, 380, 900)
            local newH = math.clamp(startSize.Y.Offset + delta.Y, 300, 700)
            Main.Size = UDim2.new(0, newW, 0, newH)
            baseSize = Main.Size
            savedSize = baseSize
            ConfirmFrame.Size = UDim2.new(0, newW, 0, newH)
        end
    end))
    TrackConnection(UserInputService.InputEnded:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then resizing = false end
    end))

    MinBtn.MouseButton1Click:Connect(function()
        if not minimized then
            minimized = true
            savedSize = Main.Size
            if SearchBar.Visible or ThemeDropdown.Visible then
                baseSize = savedSize
            end
            HeaderFix.Visible = false
            ThemeDropdown.Visible = false
            SearchBar.Visible = false
            Tween(Main, {Size = UDim2.new(0,savedSize.X.Offset,0,52)}, 0.22)
            TabList.Visible = false
            Container.Visible = false
            MinBtn.Visible = false
            MaxBtn.Visible = true
            ResizeGrip.Visible = false
        end
    end)
    MaxBtn.MouseButton1Click:Connect(function()
        if minimized then
            minimized = false
            HeaderFix.Visible = true
            TabList.Visible = true
            Container.Visible = true
            Tween(Main, {Size = savedSize}, 0.25)
            Tween(ConfirmFrame, {Size = savedSize}, 0.25)
            MaxBtn.Visible = false
            MinBtn.Visible = true
            task.wait(0.15)
            UpdateResizeGrip()
        end
    end)
    CloseBtn.MouseButton1Click:Connect(function()
        if minimized then
            minimized = false
            HeaderFix.Visible = true
            Tween(Main, {Size = savedSize}, 0.25)
            Tween(ConfirmFrame, {Size = savedSize}, 0.25)
            TabList.Visible = true
            Container.Visible = true
            MaxBtn.Visible = false
            MinBtn.Visible = true
            task.wait(0.27)
            UpdateResizeGrip()
            ConfirmFrame.Size = savedSize
            ConfirmFrame.Position = Main.Position
            ConfirmFrame.Visible = true
        else
            ConfirmFrame.Size = Main.Size
            ConfirmFrame.Position = Main.Position
            ConfirmFrame.Visible = true
        end
    end)
    NoBtn.MouseButton1Click:Connect(function() ConfirmFrame.Visible = false ConfirmFrame.Size = Main.Size end)
    local GGH_Closing = false
    YesBtn.MouseButton1Click:Connect(function()
        if GGH_Closing then return end
        GGH_Closing = true
        ConfirmFrame.Visible = false
        FadeOutGui(ScreenGui, 0.4, function() SmoothDestroy(ScreenGui) end)
    end)
    local Tabs = {}
    local TabsByName = {}
    local ThemeListeners = {}
    local CurrentThemeName = DefaultTheme
    local SaveMgr = {Enabled = false, CanWrite = false, Pending = 0, Registry = {}, Stored = {}, KeyCount = {}}
    function SaveMgr.MarkDirty() end
    function SaveMgr.RegisterElement() end
    local ThemableElements = {}
    local function RegisterThemable(obj, prop, themeKey) table.insert(ThemableElements, {obj=obj, prop=prop, key=themeKey}) end
    local function ApplyTheme(themeName)
        local sourceTheme = Themes[themeName]
        if not sourceTheme then return end
        local theme = AutoTextColors(sourceTheme)
        CurrentThemeName = themeName
        CurrentTheme = theme
        Main.BackgroundColor3 = theme.MainBg
        Header.BackgroundColor3 = theme.HeaderBg
        HeaderFix.BackgroundColor3 = theme.HeaderBg
        TabList.BackgroundColor3 = theme.TabListBg
        AccentLine.BackgroundColor3 = theme.Accent
        TabList.ScrollBarImageColor3 = theme.Accent
        ThemeList.ScrollBarImageColor3 = theme.Accent
        MainStroke.Color = theme.Stroke
        TitleLabel.TextColor3 = theme.Text
        SubLabel.TextColor3 = theme.SubText
        TitleIconImg.ImageColor3 = theme.Accent
        if SearchBtn then SearchBtn.BackgroundColor3 = theme.ElementBg2; SearchBtn.TextColor3 = theme.Text end
        if ThemeBtn then ThemeBtn.BackgroundColor3 = theme.ElementBg2; ThemeBtn.TextColor3 = theme.Text end
        MinBtn.BackgroundColor3 = theme.ElementBg2
        MinBtn.TextColor3 = theme.Text
        MaxBtn.BackgroundColor3 = theme.ElementBg2
        MaxBtn.TextColor3 = theme.Text
        if FloatBtn then FloatBtn.BackgroundColor3 = floatEnabled and theme.Accent or theme.ElementBg2; FloatBtn.TextColor3 = theme.Text end
        CloseBtn.BackgroundColor3 = theme.CloseBg
        CloseBtn.TextColor3 = theme.CloseText
        SearchBar.BackgroundColor3 = theme.ElementBg
        SBStroke.Color = theme.Accent
        SearchBox.TextColor3 = theme.Text
        SearchBox.PlaceholderColor3 = theme.SubText
        SearchClose.BackgroundColor3 = theme.ElementBg2
        SearchClose.TextColor3 = theme.Text
        ThemeDropdown.BackgroundColor3 = theme.ElementBg
        ThemeHeader.TextColor3 = theme.Text
        ConfirmBox.BackgroundColor3 = theme.ElementBg
        CT.TextColor3 = theme.Text
        CT2.TextColor3 = theme.SubText
        YesBtn.BackgroundColor3 = theme.Accent
        NoBtn.BackgroundColor3 = theme.ElementBg2
        NoBtn.TextColor3 = theme.Text
        for _, item in ipairs(ThemableElements) do
            if item.obj and item.obj.Parent then
                if item.prop == "BackgroundColor3" then
                    item.obj.BackgroundColor3 = theme[item.key]
                elseif item.prop == "TextColor3" then
                    item.obj.TextColor3 = theme[item.key]
                elseif item.prop == "Stroke" then
                    item.obj.Color = theme[item.key]
                elseif item.prop == "ScrollBar" then
                    item.obj.ScrollBarImageColor3 = theme.Accent
                end
            end
        end
        for _, page in ipairs(Container:GetChildren()) do
            if page:IsA("ScrollingFrame") then
                for _, v in ipairs(page:GetDescendants()) do
                    if v:IsA("Frame") then
                        if v.BackgroundColor3 == CurrentTheme.ElementBg or v.BackgroundColor3 == CurrentTheme.ElementBg2 or v.BackgroundColor3 == CurrentTheme.TabListBg then
                        end
                    end
                end
                page.ScrollBarImageColor3 = theme.Accent
            end
        end
        for _, fn in ipairs(ThemeListeners) do pcall(fn, theme) end
        for _, t in pairs(Tabs) do
            if t.Button then
                if t.Page and t.Page.Visible then
                    t.Button.BackgroundColor3 = theme.Accent
                    t.Button.TextColor3 = Color3.fromRGB(255,255,255)
                else
                    t.Button.BackgroundColor3 = theme.ElementBg
                    t.Button.TextColor3 = Color3.fromRGB(170,170,180)
                end
            end
        end
    end

    local ThemeOpen = false
    local SearchOpen = false
    local originalSizeBeforeExtra = nil
    local FloatingIcon = nil
    floatEnabled = false

    local function EnsureUnminimizedForPopup()
        if minimized then
            minimized = false
            HeaderFix.Visible = true
            Main.Size = savedSize
            ConfirmFrame.Size = savedSize
            TabList.Visible = true
            Container.Visible = true
            MaxBtn.Visible = false
            MinBtn.Visible = true
            UpdateResizeGrip()
        end
    end

    local function CreateFloatingIcon()
        if FloatingIcon then FloatingIcon:Destroy() end
        local floatingResources = ConnectionBag.new()
        FloatingIcon = Instance.new("TextButton", ScreenGui)
        FloatingIcon.Name = "FloatingIcon"
        FloatingIcon.Size = UDim2.new(0,40,0,40)
        FloatingIcon.Position = UDim2.new(0.5,-20,0,15)
        FloatingIcon.BackgroundColor3 = CurrentTheme.Accent
        FloatingIcon.Text = "G"
        FloatingIcon.Font = Enum.Font.GothamBold
        FloatingIcon.TextSize = 16
        FloatingIcon.TextColor3 = Color3.new(1,1,1)
        FloatingIcon.ZIndex = 200
        FloatingIcon.AutoButtonColor = false
        Corner(FloatingIcon, 20)
        Stroke(FloatingIcon, Color3.new(1,1,1), 1).Transparency = 0.5
        if ResolveIcon(WindowIconValue) then
            FloatingIcon.Text = ""
            local fim = MakeIcon(FloatingIcon, WindowIconValue, 22, Color3.new(1, 1, 1))
            fim.AnchorPoint = Vector2.new(0.5, 0.5)
            fim.Position = UDim2.fromScale(0.5, 0.5)
            fim.ZIndex = 201
        end

        local dragging = false
        local dragStartPos
        local startGuiPos
        local hasDragged = false

        floatingResources:Connect(FloatingIcon.InputBegan, function(input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                dragging = true
                hasDragged = false
                dragStartPos = input.Position
                startGuiPos = FloatingIcon.Position
            end
        end)
        floatingResources:Connect(UserInputService.InputChanged, function(input)
            if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
                local delta = input.Position - dragStartPos
                if delta.Magnitude > 5 then hasDragged = true end
                local rawPos = UDim2.new(startGuiPos.X.Scale, startGuiPos.X.Offset + delta.X, startGuiPos.Y.Scale, startGuiPos.Y.Offset + delta.Y)
                FloatingIcon.Position = Viewport.ClampPosition(FloatingIcon, ScreenGui, rawPos, "inside", 4)
            end
        end)
        Viewport.Attach(ScreenGui, FloatingIcon, floatingResources, "inside", 4)
        floatingResources:Connect(FloatingIcon.Destroying, function()
            floatingResources:Destroy()
        end)
        floatingResources:Connect(UserInputService.InputEnded, function(input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                dragging = false
                task.wait(0.05)
                hasDragged = false
            end
        end)
        floatingResources:Connect(FloatingIcon.MouseButton1Click, function()
            if hasDragged then return end
            ConfirmFrame.Visible = false
            Main.Visible = not Main.Visible
            if Main.Visible then
                if originalSizeBeforeExtra then
                    savedSize = originalSizeBeforeExtra
                    originalSizeBeforeExtra = nil
                    SearchOpen = false
                    ThemeOpen = false
                    SearchBar.Visible = false
                    ThemeDropdown.Visible = false
                    TabList.Position = UDim2.new(0,8,0,58)
                    TabList.Size = UDim2.new(0,140,1,-64)
                    Container.Position = UDim2.new(0,152,0,58)
                    Container.Size = UDim2.new(1,-160,1,-64)
                end
                if minimized then
                    minimized = false
                    HeaderFix.Visible = true
                    TabList.Visible = true
                    Container.Visible = true
                    MinBtn.Visible = true
                    MaxBtn.Visible = false
                    UpdateResizeGrip()
                end
                Main.Size = savedSize
                Tween(Main, {Size = savedSize}, 0.22)
            end
        end)
    end

    if FloatBtn then FloatBtn.MouseButton1Click:Connect(function()
        floatEnabled = not floatEnabled
        if floatEnabled then
            Tween(FloatBtn, {BackgroundColor3 = CurrentTheme.Accent}, 0.2)
            FloatBtn.TextColor3 = Color3.new(1,1,1)
            CreateFloatingIcon()
        else
            Tween(FloatBtn, {BackgroundColor3 = CurrentTheme.ElementBg2}, 0.2)
            FloatBtn.TextColor3 = CurrentTheme.Text
            if FloatingIcon then FloatingIcon:Destroy() FloatingIcon=nil end ConfirmFrame.Visible = false
        end
    end) end

    local function ExpandWindow(extraH)
        if originalSizeBeforeExtra == nil then
            originalSizeBeforeExtra = Main.Size
        end
        local targetH = originalSizeBeforeExtra.Y.Offset + extraH
        targetH = math.clamp(targetH, 300, 700)
        Tween(Main, {Size = UDim2.new(0, originalSizeBeforeExtra.X.Offset, 0, targetH)}, 0.28)
    end
    local function RestoreWindowSize()
        if ThemeOpen or SearchOpen then return end
        if originalSizeBeforeExtra then
            Tween(Main, {Size = originalSizeBeforeExtra}, 0.25)
            task.wait(0.05)
            originalSizeBeforeExtra = nil
        end
    end

    if ThemeBtn then ThemeBtn.MouseButton1Click:Connect(function()
        EnsureUnminimizedForPopup()
        if SearchOpen then
            SearchOpen = false
            Tween(SearchBar, {Size = UDim2.new(1,-16,0,0)}, 0.2)
            task.wait(0.2)
            SearchBar.Visible = false
            SearchBox.Text = ""
            Tween(TabList, {Position = UDim2.new(0,8,0,58), Size = UDim2.new(0,140,1,-64)}, 0.2)
            Tween(Container, {Position = UDim2.new(0,152,0,58), Size = UDim2.new(1,-160,1,-64)}, 0.2)
        end
        ThemeOpen = not ThemeOpen
        if ThemeOpen then
            ThemeDropdown.Visible = true
            ThemeDropdown.Size = UDim2.new(0,200,0,0)
            local maxH = math.clamp(Main.AbsoluteSize.Y - 80, 150, 360)
                Tween(ThemeDropdown, {Size = UDim2.new(0,200,0,maxH)}, 0.3)
        else
            Tween(ThemeDropdown, {Size = UDim2.new(0,200,0,0)}, 0.25)
            task.wait(0.25)
            ThemeDropdown.Visible = false
        end
    end) end

    for name, th in pairs(Themes) do
        local Btn = Instance.new("TextButton", ThemeList)
        Btn.Size = UDim2.new(1,0,0,28)
        Btn.BackgroundColor3 = th.ElementBg2
        Btn.Text = name
        Btn.Font = Enum.Font.GothamMedium
        Btn.TextSize = 11
        Btn.TextColor3 = th.Text
        Btn.ZIndex = 102
        Btn.AutoLocalize = true
        Corner(Btn, 6)
        Stroke(Btn, th.Accent, 1)
        Btn.MouseButton1Click:Connect(function()
            ApplyTheme(name)
            ThemeDropdown.Visible = false
            ThemeOpen = false
            SubLabel.Text = "Theme: " .. name
            SaveMgr.MarkDirty()
            RestoreWindowSize()
            if FloatingIcon then
                FloatingIcon.BackgroundColor3 = CurrentTheme.Accent
            end
        end)
    end
    do
        local function SafeName(s)
            s = tostring(s or "")
            s = s:gsub("[^%w_%-]", "_")
            if not s:find("%w") then s = "GGH" end
            return s
        end

        SaveMgr.CanWrite = (type(writefile) == "function") and (type(readfile) == "function") and (type(isfile) == "function")
        SaveMgr.Folder = tostring(Config.ConfigFolder or "GGH_Configs")
        SaveMgr.Path = SaveMgr.Folder .. "/" .. SafeName(Config.ConfigName or Config.SaveName or Config.Title or "GGH") .. "_" .. tostring(game.PlaceId) .. ".json"

        local function RefreshSaveToggle(animate)
            local th = CurrentTheme
            local on = SaveMgr.Enabled
            local bgCol = on and th.Accent or th.ElementBg
            local pos = on and UDim2.new(1, -19, 0.5, -8) or UDim2.new(0, 3, 0.5, -8)
            if animate then
                Tween(SaveToggleBg, {BackgroundColor3 = bgCol}, 0.2)
                Tween(SaveCircle, {Position = pos}, 0.2)
            else
                SaveToggleBg.BackgroundColor3 = bgCol
                SaveCircle.Position = pos
            end
        end

        local function WriteFile(payload)
            if not SaveMgr.CanWrite then return false end
            local ok = pcall(function()
                if type(isfolder) == "function" and type(makefolder) == "function" and not isfolder(SaveMgr.Folder) then
                    makefolder(SaveMgr.Folder)
                end
                writefile(SaveMgr.Path, HttpService:JSONEncode(payload))
            end)
            return ok
        end

        local Loaded = nil
        if SaveMgr.CanWrite then
            local ok, data = pcall(function()
                if isfile(SaveMgr.Path) then
                    return HttpService:JSONDecode(readfile(SaveMgr.Path))
                end
                return nil
            end)
            if ok and type(data) == "table" then Loaded = data end
        end
        if Loaded then
            SaveMgr.Enabled = (Loaded.SaveEnabled == true)
            if SaveMgr.Enabled and type(Loaded.Elements) == "table" then
                SaveMgr.Stored = Loaded.Elements
            end
        elseif Config.SaveDefault == true or Config.AutoSave == true then
            SaveMgr.Enabled = SaveMgr.CanWrite
        end

        function SaveMgr.Flush()
            if not SaveMgr.Enabled or not SaveMgr.CanWrite then return end
            local merged = {}
            for k, v in pairs(SaveMgr.Stored) do merged[k] = v end
            for key, entry in pairs(SaveMgr.Registry) do
                if entry.applied then
                    local ok, v = pcall(entry.get)
                    if ok and v ~= nil then merged[key] = v end
                end
            end
            SaveMgr.Stored = merged
            WriteFile({Version = 2, SaveEnabled = true, Theme = CurrentThemeName, Elements = merged})
        end

        local scheduled = false
        function SaveMgr.MarkDirty()
            if not SaveMgr.Enabled or not SaveMgr.CanWrite or scheduled then return end
            scheduled = true
            task.delay(0.6, function()
                scheduled = false
                if SaveMgr.Pending > 0 then
                    SaveMgr.MarkDirty()
                    return
                end
                SaveMgr.Flush()
            end)
        end

        function SaveMgr.SetEnabled(state, silent)
            state = state and true or false
            if state and not SaveMgr.CanWrite then return false end
            SaveMgr.Enabled = state
            if state then
                SaveMgr.Flush()
            else
                SaveMgr.Stored = {}
                WriteFile({Version = 2, SaveEnabled = false})
            end
            RefreshSaveToggle(not silent)
            return true
        end

        local KeyAlias = {
            color = "colorpicker", key = "keybind",
            sliderbox = "sliderinput", inputslider = "sliderinput",
            buttonfloat = "floatbutton", btnfloat = "floatbutton", floatingbutton = "floatbutton",
        }

        function SaveMgr.RegisterElement(tabName, typ, Cfg, api, userCb)
            if type(api) ~= "table" then return end
            typ = KeyAlias[typ] or typ
            local get, set
            if typ == "toggle" then
                get = function() return api:GetValue() == true end
                set = function(v) if type(v) == "boolean" then api:SetValue(v) end end
            elseif typ == "slider" or typ == "sliderinput" then
                get = function() return api:GetValue() end
                set = function(v) if type(v) == "number" then api:SetValue(v) end end
            elseif typ == "input" then
                get = function() return api:GetValue() end
                set = function(v)
                    if type(v) == "string" then
                        api:SetValue(v)
                        if userCb then pcall(userCb, v) end
                    end
                end
            elseif typ == "dropdown" then
                local isMulti = Cfg.Multi or Cfg.MultiSelect or Cfg.Multiple or false
                get = function()
                    local sel = api:Get()
                    if isMulti then
                        local out = {}
                        if type(sel) == "table" then
                            for _, o in ipairs(sel) do table.insert(out, tostring(o)) end
                        end
                        return out
                    end
                    if sel == nil then return nil end
                    return tostring(sel)
                end
                set = function(v)
                    local opts = Cfg.Options or {}
                    local function exists(x)
                        for _, o in ipairs(opts) do if o == x then return true end end
                        return false
                    end
                    if isMulti then
                        if type(v) ~= "table" then return end
                        local out = {}
                        for _, o in ipairs(v) do if exists(o) then table.insert(out, o) end end
                        api:Set(out)
                    else
                        if type(v) == "string" and exists(v) then api:Set(v) end
                    end
                end
            elseif typ == "colorpicker" then
                get = function()
                    local c = api:Get()
                    if typeof(c) == "Color3" then return c:ToHex() end
                    return nil
                end
                set = function(v)
                    if type(v) == "string" then
                        local ok, c = pcall(Color3.fromHex, v)
                        if ok and typeof(c) == "Color3" then api:Set(c) end
                    end
                end
            elseif typ == "keybind" then
                get = function()
                    local k = api:GetValue()
                    if typeof(k) == "EnumItem" then return k.Name end
                    return nil
                end
                set = function(v) if type(v) == "string" then api:SetValue(v) end end
            elseif typ == "floatbutton" then
                get = function() return api:GetState() end
                set = function(v) api:SetState(v) end
            else
                return
            end

            local base = tostring(tabName) .. "|" .. typ .. "|" .. tostring(Cfg.Title or Cfg.Name or "")
            local n = SaveMgr.KeyCount[base] or 0
            SaveMgr.KeyCount[base] = n + 1
            local key = (n == 0) and base or (base .. "#" .. n)

            local entry = {get = get, applied = true}
            SaveMgr.Registry[key] = entry
            local saved = SaveMgr.Stored[key]
            if SaveMgr.Enabled and saved ~= nil then
                entry.applied = false
                SaveMgr.Pending += 1
                task.delay(0.12, function()
                    pcall(set, saved)
                    entry.applied = true
                    SaveMgr.Pending = math.max(0, SaveMgr.Pending - 1)
                end)
            end
        end

        table.insert(ThemeListeners, function(th)
            SaveToggleFrame.BackgroundColor3 = th.ElementBg2
            SaveTitle.TextColor3 = th.Text
            Sep1.BackgroundColor3 = th.Stroke
            RefreshSaveToggle(false)
        end)
        if not SaveMgr.CanWrite then
            SaveTitle.Text = "Save Settings (not supported)"
        end
        RefreshSaveToggle(false)
        SaveToggleBtn.MouseButton1Click:Connect(function()
            if not SaveMgr.CanWrite then return end
            SaveMgr.SetEnabled(not SaveMgr.Enabled)
        end)

        if SaveMgr.Enabled and Loaded and type(Loaded.Theme) == "string" and Themes[Loaded.Theme] and Loaded.Theme ~= CurrentThemeName then
            pcall(ApplyTheme, Loaded.Theme)
        end
        if SaveMgr.Enabled then
            task.delay(1.5, function() SaveMgr.Flush() end)
        end
    end

    local Window = {}
    local WindowAPI_Trans_W = WindowTrans
    local WindowAPI_Trans_E = ElementTrans

    local FirstTab = true
    local AllSearchElements = {}
    local function AddSearch(frame, title, typ, tabName) table.insert(AllSearchElements, {Frame=frame, Title=title:lower(), Type=typ:lower(), Tab=tabName:lower()}) end

    local function ToggleSearch()
        EnsureUnminimizedForPopup()
        if ThemeOpen then
            ThemeOpen = false
            Tween(ThemeDropdown, {Size = UDim2.new(0,200,0,0)}, 0.25)
            task.wait(0.25)
            ThemeDropdown.Visible = false
        end
        SearchOpen = not SearchOpen
        if SearchOpen then
            SearchBar.Visible = true
            SearchBar.Size = UDim2.new(1,-16,0,0)
            Tween(SearchBar, {Size = UDim2.new(1,-16,0,42)}, 0.25)
            Tween(TabList, {Position = UDim2.new(0,8,0,104), Size = UDim2.new(0,140,1,-110)}, 0.2)
            Tween(Container, {Position = UDim2.new(0,152,0,104), Size = UDim2.new(1,-160,1,-110)}, 0.2)
            task.wait(0.15)
            SearchBox:CaptureFocus()
        else
            SearchBox.Text = ""
            for _, el in ipairs(AllSearchElements) do if el.Frame and el.Frame.Parent then el.Frame.Visible = true end end
            for _, t in pairs(Tabs) do if t.Button then t.Button.Visible = true end end
            Tween(SearchBar, {Size = UDim2.new(1,-16,0,0)}, 0.2)
            task.wait(0.2)
            SearchBar.Visible = false
            Tween(TabList, {Position = UDim2.new(0,8,0,58), Size = UDim2.new(0,140,1,-64)}, 0.2)
            Tween(Container, {Position = UDim2.new(0,152,0,58), Size = UDim2.new(1,-160,1,-64)}, 0.2)
        end
    end
    if SearchBtn then SearchBtn.MouseButton1Click:Connect(ToggleSearch) end
    SearchClose.MouseButton1Click:Connect(ToggleSearch)
    SearchBox:GetPropertyChangedSignal("Text"):Connect(function()
        local query = SearchBox.Text:lower()
        if query == "" then
            for _, el in ipairs(AllSearchElements) do if el.Frame and el.Frame.Parent then el.Frame.Visible = true end end
            for _, t in pairs(Tabs) do if t.Button then t.Button.Visible = true end end
            return
        end
        for _, el in ipairs(AllSearchElements) do
            local match = string.find(el.Title, query, 1, true) or string.find(el.Type, query, 1, true) or string.find(el.Tab, query, 1, true)
            if el.Frame and el.Frame.Parent then el.Frame.Visible = (match ~= nil) end
        end
        for _, t in pairs(Tabs) do if t.Button then local n = t.Button.Text:lower() t.Button.Visible = (string.find(n, query, 1, true) ~= nil) end end
    end)
    function Window:CreateTab(Name, TabIcon)
        if type(Name) == "table" then
            local tcfg = Name
            Name = tcfg.Title or tcfg.Name or "Tab"
            TabIcon = tcfg.Icon or tcfg.Image or TabIcon
        end
        Name = tostring(Name)
        local tabResources = ConnectionBag.new()
        local function TrackConnection(connection)
            return tabResources:Add(connection)
        end
        local TabButton = Instance.new("TextButton", TabList)
        TabButton.Size = UDim2.new(1,0,0,36)
        TabButton.BackgroundColor3 = CurrentTheme.ElementBg
        TabButton.BackgroundTransparency = 0
        TabButton.Text = Name
        TabButton.TextTruncate = Enum.TextTruncate.AtEnd
        TabButton.TextWrapped = false
        TabButton.Font = Enum.Font.GothamMedium
        TabButton.TextSize = 12
        TabButton.TextColor3 = Color3.fromRGB(170,170,180)
        TabButton.TextXAlignment = Enum.TextXAlignment.Left
        TabButton.AutoButtonColor = false
        TabButton.AutoLocalize = true
        TabButton.ClipsDescendants = true
        Corner(TabButton, 10)
        local tabPad = Instance.new("UIPadding", TabButton)
        tabPad.PaddingLeft = UDim.new(0,12)
        tabPad.PaddingRight = UDim.new(0,8)
        if ResolveIcon(TabIcon) then
            tabPad.PaddingLeft = UDim.new(0, 34)
            local tabIconImg = MakeIcon(TabButton, TabIcon, 16)
            tabIconImg.AnchorPoint = Vector2.new(0, 0.5)
            tabIconImg.Position = UDim2.new(0, -22, 0.5, 0)
            tabIconImg.ZIndex = TabButton.ZIndex + 1
            BindIconToText(TabButton, tabIconImg)
        end
        TabButton.MouseEnter:Connect(function()
            if #Name > 15 then
                SubLabel.Text = Name
                TabButton.TextWrapped = true
                Tween(TabButton, {Size = UDim2.new(1,0,0,52)}, 0.2)
                TabButton.Text = Name
            end
        end)
        TabButton.MouseLeave:Connect(function()
            SubLabel.Text = SubTitle
            Tween(TabButton, {Size = UDim2.new(1,0,0,36)}, 0.2)
            TabButton.TextWrapped = false
            TabButton.Text = Name
        end)
        RegisterThemable(TabButton, "BackgroundColor3", "ElementBg")
    AddBlackBorder(TabButton, 1, 0.7)
    AddTextStroke(TabButton)
        local TabPage = Instance.new("ScrollingFrame", Container)
        tabResources:Connect(TabPage.Destroying, function()
            tabResources:Destroy()
        end)
        TabPage.Name = Name.."Page"
        TabPage.Size = UDim2.new(1,0,1,0)
        TabPage.BackgroundTransparency = 1
        TabPage.Visible = false
        TabPage.CanvasSize = UDim2.new(0,0,0,0)
        TabPage.AutomaticCanvasSize = Enum.AutomaticSize.Y
        TabPage.ScrollBarThickness = 3
        TabPage.ScrollBarImageColor3 = CurrentTheme.Accent
        TabPage.ScrollingDirection = Enum.ScrollingDirection.Y
        TabPage.BorderSizePixel = 0
        TabPage.ClipsDescendants = true
        TabPage.ZIndex = 16
        RegisterThemable(TabPage, "ScrollBar", "Accent")
        local Layout = Instance.new("UIListLayout", TabPage)
        Layout.Padding = UDim.new(0, 8)
        Layout.SortOrder = Enum.SortOrder.LayoutOrder
        local Padding = Instance.new("UIPadding", TabPage)
        Padding.PaddingTop = UDim.new(0,2) Padding.PaddingBottom = UDim.new(0,20) Padding.PaddingLeft = UDim.new(0,2) Padding.PaddingRight = UDim.new(0,4)
        local IsScrolling = false
        TabPage:GetPropertyChangedSignal("CanvasPosition"):Connect(function() IsScrolling = true task.delay(0.35, function() IsScrolling = false end) end)
        TabButton.MouseButton1Click:Connect(function()
            for _, t in pairs(Tabs) do if t.Page then t.Page.Visible = false end if t.Button then Tween(t.Button, {BackgroundColor3 = CurrentTheme.ElementBg}, 0.15) t.Button.TextColor3 = Color3.fromRGB(170,170,180) end end
            TabPage.Visible = true
            Tween(TabButton, {BackgroundColor3 = CurrentTheme.Accent}, 0.15)
            TabButton.TextColor3 = Color3.fromRGB(255,255,255)
        end)
        if FirstTab then FirstTab = false TabPage.Visible = true TabButton.BackgroundColor3 = CurrentTheme.Accent TabButton.TextColor3 = Color3.fromRGB(255,255,255) end
        local tabRecord = {Button = TabButton, Page = TabPage, Name = Name}
        table.insert(Tabs, tabRecord)
        TabsByName[Name] = tabRecord

        local function CreateSection(Cfg)
            local SecFrame = Instance.new("Frame", TabPage)
            SecFrame.Size = UDim2.new(1,-4,0,26)
            SecFrame.BackgroundTransparency = 1
            AddSearch(SecFrame, Cfg.Title or "Section", "Section", Name)
            local Dot = Instance.new("Frame", SecFrame)
            Dot.Size = UDim2.new(0,6,0,6)
            Dot.Position = UDim2.new(0,2,0.5,-3)
            Dot.BackgroundColor3 = CurrentTheme.Accent
            Corner(Dot, 3)
            RegisterThemable(Dot, "BackgroundColor3", "Accent")
            local Sec = Instance.new("TextLabel", SecFrame)
            Sec.Size = UDim2.new(1,-20,1,0)
            Sec.Position = UDim2.new(0,16,0,0)
            Sec.BackgroundTransparency = 1
            Sec.Text = (Cfg and Cfg.Title or "Section"):upper()
            Sec.Font = Enum.Font.GothamBold
            Sec.TextSize = 11
            Sec.TextColor3 = CurrentTheme.SectionText
            Sec.TextXAlignment = Enum.TextXAlignment.Left
            Sec.AutoLocalize = true AddTextStroke(Sec)
            RegisterThemable(Sec, "TextColor3", "SectionText")
            local Line = Instance.new("Frame", SecFrame)
            Line.Size = UDim2.new(1,-16,0,1)
            Line.Position = UDim2.new(0,16,1,-1)
            Line.BackgroundColor3 = CurrentTheme.Stroke
            Line.BackgroundTransparency = 0.5
            RegisterThemable(Line, "BackgroundColor3", "Stroke")
            local CreateSectionAPI = {}
            function CreateSectionAPI:Refresh(newCfg) return CreateSectionAPI end
            return CreateSectionAPI

        end

        local function CreateParagraph(Cfg)
            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0,60)
            Frame.AutomaticSize = Enum.AutomaticSize.Y
            Frame.BackgroundColor3 = CurrentTheme.TabListBg
            Corner(Frame, 10)
            RegisterThemable(Frame, "BackgroundColor3", "TabListBg")
            AddSearch(Frame, Cfg.Title.." "..(Cfg.Content or ""), "Paragraph", Name)
            local pad = Instance.new("UIPadding", Frame)
            pad.PaddingTop = UDim.new(0,10) pad.PaddingBottom = UDim.new(0,10) pad.PaddingLeft = UDim.new(0,12) pad.PaddingRight = UDim.new(0,12)
            local T = Instance.new("TextLabel", Frame)
            T.Size = UDim2.new(1,0,0,20)
            T.AutomaticSize = Enum.AutomaticSize.Y
            T.BackgroundTransparency = 1
            T.Text = Cfg.Title .. "\n" .. (Cfg.Content or "")
            T.TextWrapped = true
            T.TextXAlignment = Enum.TextXAlignment.Left
            T.Font = Enum.Font.Gotham
            T.TextSize = 12
            T.TextColor3 = CurrentTheme.ParagraphText
            T.AutoLocalize = true
            RegisterThemable(T, "TextColor3", "ParagraphText")
            local CreateParagraphAPI = {}
            function CreateParagraphAPI:Refresh(newCfg) return CreateParagraphAPI end
            return CreateParagraphAPI

        end

        local function CreateButton(Cfg)
            local Btn = Instance.new("TextButton", TabPage)
            Btn.Size = UDim2.new(1,-4,0,38)
            Btn.BackgroundColor3 = CurrentTheme.ElementBg2
            Btn.Text = Cfg.Title
            Btn.Font = Enum.Font.GothamMedium
            Btn.TextSize = 13
            Btn.TextColor3 = CurrentTheme.Text
            Btn.AutoButtonColor = false
            Btn.AutoLocalize = true
            Corner(Btn, 10)
            local st = Stroke(Btn, CurrentTheme.StrokeLight, 1)
            RegisterThemable(Btn, "BackgroundColor3", "ElementBg2")
            RegisterThemable(Btn, "TextColor3", "Text")
            RegisterThemable(st, "Stroke", "StrokeLight")
            AddSearch(Btn, Cfg.Title, "Button", Name)
            local ButtonAPI = {}
            function ButtonAPI:Refresh(newCfg)
                if newCfg then
                    if newCfg.Title then Btn.Text = newCfg.Title; Cfg.Title = newCfg.Title end
                    if newCfg.Callback then Cfg.Callback = newCfg.Callback end
                end
                return ButtonAPI
            end
            function ButtonAPI:SetTitle(t) Btn.Text = t return ButtonAPI end
            function ButtonAPI:Fire() pcall(Cfg.Callback) return ButtonAPI end
            Btn.MouseButton1Click:Connect(function()
                if IsScrolling then return end
                Tween(Btn, {BackgroundColor3 = CurrentTheme.ElementBg}, 0.1)
                task.wait(0.1)
                Tween(Btn, {BackgroundColor3 = CurrentTheme.ElementBg2}, 0.1)
                pcall(Cfg.Callback)
            end)
            return ButtonAPI
        end

        local function CreateToggle(Cfg)
            local State = Cfg.Default or false
            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0,40)
            Frame.BackgroundColor3 = CurrentTheme.ElementBg
            Corner(Frame, 10)
            RegisterThemable(Frame, "BackgroundColor3", "ElementBg")
            RegisterThemable(SoftStroke(Frame, CurrentTheme.Stroke), "Stroke", "Stroke")
            AddSearch(Frame, Cfg.Title, "Toggle", Name)
            local Title = Instance.new("TextLabel", Frame)
            Title.Text = Cfg.Title
            Title.AutoLocalize = true
            Title.Size = UDim2.new(1,-66,1,0)
            Title.Position = UDim2.new(0,12,0,0)
            Title.BackgroundTransparency = 1
            Title.TextXAlignment = Enum.TextXAlignment.Left
            Title.Font = Enum.Font.GothamMedium
            Title.TextSize = 13
            Title.TextColor3 = CurrentTheme.Text
            Title.AutoLocalize = true
            RegisterThemable(Title, "TextColor3", "Text")
            local Bg = Instance.new("Frame", Frame)
            Bg.Size = UDim2.new(0,48,0,26)
            Bg.Position = UDim2.new(1,-58,0.5,-13)
            Bg.BackgroundColor3 = State and CurrentTheme.Accent or CurrentTheme.ElementBg2
            Corner(Bg, 13)
            local Circle = Instance.new("Frame", Bg)
            Circle.Size = UDim2.new(0,20,0,20)
            Circle.Position = State and UDim2.new(1,-23,0.5,-10) or UDim2.new(0,3,0.5,-10)
            Circle.BackgroundColor3 = Color3.fromRGB(255,255,255)
            Corner(Circle, 10)
            local Btn = Instance.new("TextButton", Frame)
            Btn.Size = UDim2.new(1,0,1,0)
            Btn.BackgroundTransparency = 1
            Btn.Text = ""
            table.insert(ThemeListeners, function(th)
                if not Bg.Parent then return end
                Bg.BackgroundColor3 = State and th.Accent or th.ElementBg2
            end)
            local ToggleAPI = {}
            function ToggleAPI:SetValue(v)
                State = v
                Tween(Bg, {BackgroundColor3 = State and CurrentTheme.Accent or CurrentTheme.ElementBg2}, 0.2)
                Tween(Circle, {Position = State and UDim2.new(1,-23,0.5,-10) or UDim2.new(0,3,0.5,-10)}, 0.2)
                pcall(function() Cfg.Callback(State) end)
                return ToggleAPI
            end
            function ToggleAPI:GetValue() return State end
            function ToggleAPI:Refresh(newCfg)
                if newCfg then
                    if newCfg.Title then Title.Text = newCfg.Title end
            Title.AutoLocalize = true
                    if newCfg.Default ~= nil then self:SetValue(newCfg.Default) end
                end
                return ToggleAPI
            end
            function ToggleAPI:Set(v) return self:SetValue(v) end
            function ToggleAPI:Get() return self:GetValue() end

            Btn.MouseButton1Click:Connect(function()
                if IsScrolling then return end
                State = not State
                Tween(Bg, {BackgroundColor3 = State and CurrentTheme.Accent or CurrentTheme.ElementBg2}, 0.2)
                Tween(Circle, {Position = State and UDim2.new(1,-23,0.5,-10) or UDim2.new(0,3,0.5,-10)}, 0.2)
                pcall(function() Cfg.Callback(State) end)
            end)
            return ToggleAPI
        end

        local function NormalizeSliderConfig(Cfg, defaultDecimals, controlName)
            Cfg.Min = ConfigNumber(Cfg.Min, 0, controlName .. ".Min")
            Cfg.Max = ConfigNumber(Cfg.Max, 100, controlName .. ".Max")
            if Cfg.Max <= Cfg.Min then
                error("[GGH v1.9] " .. controlName .. ".Max must be greater than .Min.", 3)
            end
            Cfg.Default = ConfigNumber(Cfg.Default, Cfg.Min, controlName .. ".Default")
            local decimals = Cfg.Decimals
            if decimals == nil then decimals = Cfg.Precision end
            if decimals == nil then decimals = Cfg.FloatPrecision end
            if decimals == nil then decimals = defaultDecimals end
            Cfg.Decimals = ConfigNumber(decimals, defaultDecimals, controlName .. ".Decimals")
            if Cfg.Decimals < 0 or Cfg.Decimals > 10 or Cfg.Decimals % 1 ~= 0 then
                error("[GGH v1.9] " .. controlName .. ".Decimals must be an integer from 0 to 10.", 3)
            end
            if Cfg.Precision ~= nil then
                Cfg.Precision = ConfigNumber(Cfg.Precision, nil, controlName .. ".Precision")
                if Cfg.Precision < 0 or Cfg.Precision > 10 or Cfg.Precision % 1 ~= 0 then
                    error("[GGH v1.9] " .. controlName .. ".Precision must be an integer from 0 to 10.", 3)
                end
            end
            if Cfg.Increment ~= nil then
                Cfg.Increment = ConfigNumber(Cfg.Increment, nil, controlName .. ".Increment")
                if Cfg.Increment < 0 then
                    error("[GGH v1.9] " .. controlName .. ".Increment cannot be negative.", 3)
                end
            end
            Cfg.Title = tostring(Cfg.Title or "Slider")
            if Cfg.Increment then
                local s = tostring(Cfg.Increment)
                if s:find("%.") then
                    local parts = string.split(s, ".")
                    local dec = parts[2] and #parts[2] or 0
                    if dec > Cfg.Decimals then Cfg.Decimals = dec end
                end
            end
            if Cfg.Decimals > 10 then
                error("[GGH v1.9] " .. controlName .. " supports at most 10 decimal places.", 3)
            end
        end

        local function CreateSlider(Cfg)
            NormalizeSliderConfig(Cfg, Cfg.Float and 1 or 0, "Slider")
            local isFloat = Cfg.Float or Cfg.Decimals > 0 or Cfg.Precision ~= nil or Cfg.AllowDecimals
            local function FormatVal(v)
                if isFloat then
                    local dec = Cfg.Decimals
                    if dec == 0 and Cfg.Precision == nil and Cfg.Float then dec = 1 end
                    if Cfg.Precision then dec = Cfg.Precision end
                    return string.format("%."..tostring(dec).."f", v)
                else
                    if Cfg.Integer or Cfg.Round then
                        return tostring(math.floor(v+0.5))
                    end
                    return tostring(math.floor(v*100)/100):gsub("%.0+$",""):gsub("%.$","")
                end
            end
            local function SnapValue(v)
                if Cfg.Increment and Cfg.Increment > 0 then
                    v = math.floor((v / Cfg.Increment)+0.5) * Cfg.Increment
                    v = tonumber(string.format("%."..tostring(Cfg.Decimals+4).."f", v))
                end
                return v
            end
            local Value = math.clamp(Cfg.Default, Cfg.Min, Cfg.Max)
            Value = SnapValue(Value)
            local function RelOf(v)
                local range = Cfg.Max - Cfg.Min
                if range <= 0 then return 0 end
                return math.clamp((v - Cfg.Min) / range, 0, 1)
            end
            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0,58)
            Frame.BackgroundColor3 = CurrentTheme.ElementBg
            Corner(Frame, 10)
            RegisterThemable(Frame, "BackgroundColor3", "ElementBg")
            RegisterThemable(SoftStroke(Frame, CurrentTheme.Stroke), "Stroke", "Stroke")
            AddSearch(Frame, Cfg.Title, "Slider", Name)
            local Label = Instance.new("TextLabel", Frame)
            Label.Size = UDim2.new(1,-16,0,18)
            Label.Position = UDim2.new(0,10,0,6)
            Label.BackgroundTransparency = 1
            Label.TextXAlignment = Enum.TextXAlignment.Left
            Label.Font = Enum.Font.GothamMedium
            Label.TextSize = 13
            Label.TextColor3 = CurrentTheme.Text
            Label.Text = Cfg.Title.." : "..FormatVal(Value)
            Label.AutoLocalize = true
            RegisterThemable(Label, "TextColor3", "Text")
            local Bar = Instance.new("Frame", Frame)
            Bar.Size = UDim2.new(1,-20,0,8)
            Bar.Position = UDim2.new(0,10,0,32)
            Bar.BackgroundColor3 = CurrentTheme.ElementBg2
            Corner(Bar, 4)
            RegisterThemable(Bar, "BackgroundColor3", "ElementBg2")
            local Fill = Instance.new("Frame", Bar)
            Fill.Size = UDim2.new(RelOf(Value),0,1,0)
            Fill.BackgroundColor3 = CurrentTheme.Accent
            Corner(Fill, 4)
            RegisterThemable(Fill, "BackgroundColor3", "Accent")
            local Circle = Instance.new("Frame", Bar)
            Circle.Size = UDim2.new(0,18,0,18)
            Circle.AnchorPoint = Vector2.new(0.5,0.5)
            Circle.Position = UDim2.new(RelOf(Value), 0, 0.5, 0)
            Circle.BackgroundColor3 = Color3.fromRGB(255,255,255)
            Circle.ZIndex = 10
            Corner(Circle, 9)
            local S = Stroke(Circle, CurrentTheme.Accent, 2)
            RegisterThemable(S, "Stroke", "Accent")
            local DragArea = Instance.new("TextButton", Bar)
            DragArea.Size = UDim2.new(1,0,2.5,0)
            DragArea.Position = UDim2.new(0,0,0.5,-10)
            DragArea.BackgroundTransparency = 1
            DragArea.Text = ""
            local dragging = false
            local function UpdateSlider(inputX)
                local barPos = Bar.AbsolutePosition.X
                local barSize = Bar.AbsoluteSize.X
                if barSize <= 0 then barSize = 200 end
                local rel = math.clamp((inputX - barPos) / barSize, 0, 1)
                local newVal = Cfg.Min + (Cfg.Max - Cfg.Min) * rel
                newVal = SnapValue(newVal)
                if not isFloat then
                    if Cfg.Round or Cfg.Integer then
                        newVal = math.floor(newVal+0.5)
                    end
                end
                Value = math.clamp(newVal, Cfg.Min, Cfg.Max)
                local r = RelOf(Value)
                Fill.Size = UDim2.new(r,0,1,0)
                Circle.Position = UDim2.new(r, 0, 0.5, 0)
                Label.Text = Cfg.Title.." : "..FormatVal(Value)
                pcall(Cfg.Callback or function() end, Value)
            end
            DragArea.InputBegan:Connect(function(input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then dragging = true UpdateSlider(input.Position.X) end
            end)
            Circle.InputBegan:Connect(function(input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then dragging = true end
            end)
            TrackConnection(UserInputService.InputChanged:Connect(function(input)
                if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then UpdateSlider(input.Position.X) end
            end))
            TrackConnection(UserInputService.InputEnded:Connect(function(input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then dragging = false end
            end))
            local SliderAPI = {}
            function SliderAPI:SetValue(v)
                v = SnapValue(math.clamp(v, Cfg.Min, Cfg.Max))
                Value = v
                local rel = RelOf(Value)
                Fill.Size = UDim2.new(rel,0,1,0)
                Circle.Position = UDim2.new(rel, 0, 0.5, 0)
                Label.Text = Cfg.Title.." : "..FormatVal(Value)
                pcall(Cfg.Callback or function() end, Value)
                return SliderAPI
            end
            function SliderAPI:GetValue() return Value end
            function SliderAPI:Refresh(newCfg)
                if newCfg then
                    if newCfg.Min then Cfg.Min = newCfg.Min end
                    if newCfg.Max then Cfg.Max = newCfg.Max end
                    if newCfg.Title then Label.Text = newCfg.Title.." : "..FormatVal(Value); Cfg.Title = newCfg.Title end
                    if newCfg.Default then self:SetValue(newCfg.Default) end
                end
                return SliderAPI
            end
            return SliderAPI
        end

        local function CreateInput(Cfg)
            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0,40)
            Frame.BackgroundColor3 = CurrentTheme.ElementBg
            Corner(Frame, 10)
            RegisterThemable(Frame, "BackgroundColor3", "ElementBg")
            RegisterThemable(SoftStroke(Frame, CurrentTheme.Stroke), "Stroke", "Stroke")
            AddSearch(Frame, Cfg.Title, "Input", Name)
            local Box = Instance.new("TextBox", Frame)
            Box.Size = UDim2.new(1,-20,1,-10)
            Box.Position = UDim2.new(0,10,0,5)
            Box.BackgroundTransparency = 1
            Box.PlaceholderText = Cfg.Placeholder or Cfg.Title
            Box.Text = Cfg.Default or ""
            Box.Font = Enum.Font.Gotham
            Box.TextSize = 13
            Box.TextColor3 = CurrentTheme.Text
            Box.PlaceholderColor3 = CurrentTheme.SubText
            Box.TextXAlignment = Enum.TextXAlignment.Left
            Box.ClearTextOnFocus = false
            Box.AutoLocalize = true
            RegisterThemable(Box, "TextColor3", "Text")
            local InputAPI = {}
            function InputAPI:SetValue(t) Box.Text = t return InputAPI end
            function InputAPI:GetValue() return Box.Text end
            function InputAPI:Refresh(newCfg)
                if newCfg then
                    if newCfg.Placeholder then Box.PlaceholderText = newCfg.Placeholder end
                    if newCfg.Default then Box.Text = newCfg.Default end
                    if newCfg.Title then Cfg.Title = newCfg.Title end
                end
                return InputAPI
            end
            function InputAPI:Set(t) return self:SetValue(t) end
            function InputAPI:Get() return self:GetValue() end
            Box.FocusLost:Connect(function() if IsScrolling then return end pcall(Cfg.Callback or function() end, Box.Text) end)
            return InputAPI
        end

local function CreateDropdown(Cfg)
    local isMulti = Cfg.Multi or Cfg.MultiSelect or Cfg.Multiple or false
    Cfg.Options = Cfg.Options or {}
    local Selected = Cfg.Default or Cfg.Options[1]
    if isMulti then
        if type(Selected) ~= "table" then Selected = {Selected} end
        local valid = {}
        for _, v in ipairs(Selected) do for _, o in ipairs(Cfg.Options) do if v==o then table.insert(valid,v) break end end end
        Selected = valid
    end

    local MAX_VISIBLE = 7
    local OPT_H = 30

    local Frame = Instance.new("Frame", TabPage)
    Frame.Size = UDim2.new(1,-4,0,38)
    Frame.BackgroundColor3 = CurrentTheme.ElementBg
    Frame.ClipsDescendants = true
    Corner(Frame, 10)
    RegisterThemable(Frame, "BackgroundColor3", "ElementBg")
    RegisterThemable(SoftStroke(Frame, CurrentTheme.Stroke), "Stroke", "Stroke")
    AddSearch(Frame, Cfg.Title, "Dropdown", Name)

    local function GetDisplayText()
        if isMulti then
            if #Selected == 0 then return Cfg.Title.." : (None)"
            elseif #Selected == 1 then return Cfg.Title.." : "..Selected[1]
            else return Cfg.Title.." : "..#Selected.." selected ("..table.concat(Selected, ", "):sub(1,20)..")"
            end
        else
            return Cfg.Title.." : "..tostring(Selected)
        end
    end

    local Btn = Instance.new("TextButton", Frame)
    Btn.Size = UDim2.new(1,0,0,38)
    Btn.BackgroundTransparency = 1
    Btn.Text = GetDisplayText()
    Btn.Font = Enum.Font.GothamMedium
    Btn.TextSize = 12
    Btn.TextColor3 = CurrentTheme.Text
    Btn.AutoLocalize = true
    Btn.TextTruncate = Enum.TextTruncate.AtEnd
    RegisterThemable(Btn, "TextColor3", "Text")
    AddTextStroke(Btn)

    local List = Instance.new("ScrollingFrame", Frame)
    List.Name = "DropdownList"
    List.Position = UDim2.new(0,0,0,38)
    List.Size = UDim2.new(1,0,0,0)
    List.BackgroundTransparency = 1
    List.BorderSizePixel = 0
    List.CanvasSize = UDim2.new(0,0,0,0)
    List.ScrollBarThickness = 4
    List.ScrollBarImageColor3 = CurrentTheme.Accent
    List.ScrollingDirection = Enum.ScrollingDirection.Y
    List.ClipsDescendants = true
    RegisterThemable(List, "ScrollBar", "Accent")

    local ll = Instance.new("UIListLayout", List)
    ll.Padding = UDim.new(0,2)
    ll.SortOrder = Enum.SortOrder.LayoutOrder

    local Open = false

    local function GetListHeight()
        local count = #Cfg.Options
        local visible = math.min(count, MAX_VISIBLE)
        return visible * (OPT_H + 2)
    end

    local function UpdateListSize()
        local count = #Cfg.Options
        List.CanvasSize = UDim2.new(0,0,0, count * (OPT_H + 2))
        if Open then
            local h = GetListHeight()
            List.Size = UDim2.new(1,0,0,h)
            Tween(Frame, {Size = UDim2.new(1,-4,0, 38 + h + 6)}, 0.2)
        end
    end

    Btn.MouseButton1Click:Connect(function()
        if IsScrolling then return end
        Open = not Open
        if Open then
            local h = GetListHeight()
            List.Size = UDim2.new(1,0,0,h)
            Tween(Frame, {Size = UDim2.new(1,-4,0, 38 + h + 6)}, 0.2)
        else
            Tween(Frame, {Size = UDim2.new(1,-4,0,38)}, 0.2)
        end
    end)

    local function IsSelected(opt)
        if not isMulti then return opt == Selected end
        for _, v in ipairs(Selected) do if v == opt then return true end end
        return false
    end

    local function RefreshOptions()
        for _, child in ipairs(List:GetChildren()) do
            if child:IsA("TextButton") then
                local name = child:GetAttribute("OptName") or child.Text
                local sel = IsSelected(name)
                child.BackgroundColor3 = sel and CurrentTheme.Accent or CurrentTheme.ElementBg2
                child.Text = name
                local ck = child:FindFirstChild("Check")
                if ck then ck.Visible = sel end
            end
        end
        Btn.Text = GetDisplayText()
    end

    table.insert(ThemeListeners, function(th)
        if not Frame.Parent then return end
        List.ScrollBarImageColor3 = th.Accent
        for _, child in ipairs(List:GetChildren()) do
            if child:IsA("TextButton") then
                local nm = child:GetAttribute("OptName") or child.Text
                child.BackgroundColor3 = IsSelected(nm) and th.Accent or th.ElementBg2
                child.TextColor3 = th.Text
            end
        end
    end)

    local function CreateOptionButton(opt)
        local O = Instance.new("TextButton", List)
        O.Size = UDim2.new(1,-4,0,28)
        O.BackgroundColor3 = IsSelected(opt) and CurrentTheme.Accent or CurrentTheme.ElementBg2
        O.Text = opt
        O.Font = Enum.Font.Gotham
        O.TextSize = 11
        O.TextColor3 = CurrentTheme.Text
        O.AutoLocalize = true
        Corner(O, 6)
        AddBlackBorder(O, 0.8, 0.8)
        AddTextStroke(O)
        O:SetAttribute("OptName", opt)
        do
            local ck = MakeIcon(O, "check", 14, Color3.new(1, 1, 1))
            ck.Name = "Check"
            ck.AnchorPoint = Vector2.new(1, 0.5)
            ck.Position = UDim2.new(1, -8, 0.5, 0)
            ck.Visible = IsSelected(opt)
        end
        O.MouseButton1Click:Connect(function()
            if isMulti then
                if IsSelected(opt) then
                    for i,v in ipairs(Selected) do if v==opt then table.remove(Selected,i) break end end
                else
                    table.insert(Selected, opt)
                end
                RefreshOptions()
                pcall(Cfg.Callback or function() end, Selected)
            else
                Selected = opt
                RefreshOptions()
                Open = false
                Tween(Frame, {Size = UDim2.new(1,-4,0,38)}, 0.2)
                pcall(Cfg.Callback or function() end, Selected)
            end
        end)
        return O
    end

    for _, opt in ipairs(Cfg.Options) do
        CreateOptionButton(opt)
    end
    List.CanvasSize = UDim2.new(0,0,0, #Cfg.Options * (OPT_H + 2))

    local DropdownAPI = {}
    function DropdownAPI:Refresh(newOptions)
        if newOptions and type(newOptions) == "table" then
            Cfg.Options = newOptions
        end
        for _, child in ipairs(List:GetChildren()) do
            if child:IsA("TextButton") then child:Destroy() end
        end
        if not isMulti then
            local stillExists = false
            for _, o in ipairs(Cfg.Options) do if o == Selected then stillExists = true break end end
            if not stillExists then Selected = Cfg.Options[1] end
        else
            local newSel = {}
            for _, s in ipairs(Selected) do for _, o in ipairs(Cfg.Options) do if s==o then table.insert(newSel,s) break end end end
            Selected = newSel
        end
        for _, opt in ipairs(Cfg.Options) do CreateOptionButton(opt) end
        List.CanvasSize = UDim2.new(0,0,0, #Cfg.Options * (OPT_H + 2))
        RefreshOptions()
        if Open then
            local h = GetListHeight()
            List.Size = UDim2.new(1,0,0,h)
            Tween(Frame, {Size = UDim2.new(1,-4,0, 38 + h + 6)}, 0.2)
        end
        return DropdownAPI
    end
    function DropdownAPI:SetOptions(newOptions) return self:Refresh(newOptions) end
    function DropdownAPI:Set(option)
        if isMulti then
            if type(option) == "table" then Selected = option else Selected = {option} end
        else
            Selected = option
        end
        RefreshOptions()
        pcall(Cfg.Callback or function() end, Selected)
        return DropdownAPI
    end
    function DropdownAPI:Get() return Selected end
    function DropdownAPI:Clear()
        if isMulti then Selected = {} else Selected = nil end
        RefreshOptions()
        return DropdownAPI
    end
    function DropdownAPI:AddOption(opt)
        table.insert(Cfg.Options, opt)
        self:Refresh()
        return DropdownAPI
    end
    function DropdownAPI:RemoveOption(opt)
        for i,o in ipairs(Cfg.Options) do if o==opt then table.remove(Cfg.Options,i) break end end
        self:Refresh()
        return DropdownAPI
    end

    return DropdownAPI
end

local function CreateColorpicker(Cfg)

    local function CenterPicker(pickerFrame, screenGui)
        local vp = screenGui.AbsoluteSize
        if vp.X < 10 or vp.Y < 10 then
            vp = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize or Vector2.new(1920,1080)
        end
        local pSize = pickerFrame.AbsoluteSize
        if pSize.X < 10 then pSize = Vector2.new(320, 280) end
        local x = (vp.X - pSize.X) / 2
        local y = (vp.Y - pSize.Y) / 2
        x = math.clamp(x, 10, vp.X - pSize.X - 10)
        y = math.clamp(y, 10, vp.Y - pSize.Y - 10)
        pickerFrame.Position = UDim2.fromOffset(x, y)
    end

            Cfg.Title = Cfg.Title or Cfg.Name or "Colorpicker"
            Cfg.Default = Cfg.Default or Cfg.Color or CurrentTheme.Accent
            Cfg.Mode = Cfg.Mode or Cfg.ColorMode or "Player"
            if Cfg.Mode=="Both" then Cfg.Mode="Player" end
            Cfg.DeveloperColors = Cfg.DeveloperColors or Cfg.DevColors or Cfg.Palette or {}
            Cfg.Callback = Cfg.Callback or Cfg.OnChanged or function() end
            local Color = Cfg.Default
            local Hue,Sat,Vib = Color3.toHSV(Color)
            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0,38)
            Frame.BackgroundColor3 = CurrentTheme.ElementBg
            Frame.BackgroundTransparency = ElementTrans
            Frame.BorderSizePixel = 0
            Corner(Frame, 10)
            RegisterThemable(Frame, "BackgroundColor3", "ElementBg")
            RegisterThemable(Stroke(Frame, CurrentTheme.Stroke, 1), "Stroke", "Stroke")
            local Title = Instance.new("TextLabel", Frame)
            Title.Size = UDim2.new(1,-90,1,0)
            Title.Position = UDim2.new(0,12,0,0)
            Title.BackgroundTransparency = 1
            Title.Text = Cfg.Title
            Title.AutoLocalize = true
            Title.Font = Enum.Font.GothamMedium
            Title.TextSize = 13
            Title.TextColor3 = CurrentTheme.Text
            Title.TextXAlignment = Enum.TextXAlignment.Left
            RegisterThemable(Title, "TextColor3", "Text")
            AddTextStroke(Title)
            local PreviewBtn = Instance.new("TextButton", Frame)
            PreviewBtn.Size = UDim2.new(0,56,0,22)
            PreviewBtn.Position = UDim2.new(1,-66,0.5,-11)
            PreviewBtn.BackgroundColor3 = Color
            PreviewBtn.Text = ""
            PreviewBtn.AutoButtonColor = false
            Corner(PreviewBtn, 6)
            RegisterThemable(Stroke(PreviewBtn, CurrentTheme.StrokeLight, 1), "Stroke", "StrokeLight")
            local DevContainer = nil
            local function Fire(c)
                Color = c
                PreviewBtn.BackgroundColor3 = c
                pcall(Cfg.Callback, c)
            end
            local AdvancedGui = nil
            local function OpenAdvancedPicker()
                if AdvancedGui and AdvancedGui.Parent then AdvancedGui:Destroy() end
                local originalColor = Color
                local ov = Instance.new("Frame", ScreenGui)
                ov.Name = "GGH_ColorPicker_Overlay"
                ov.Size = UDim2.new(1,0,1,0)
                ov.BackgroundColor3 = Color3.new(0,0,0)
                ov.BackgroundTransparency = 1
                ov.ZIndex = 300
                ov.BorderSizePixel = 0
                ov.Active = true
                local main = Instance.new("Frame", ov)
                main.AnchorPoint = Vector2.new(0,0)
                main.Size = UDim2.fromOffset(300,200)
                main.Position = UDim2.fromOffset(10,10)
                main.BackgroundColor3 = CurrentTheme.MainBg
                main.BackgroundTransparency = 0
                main.ClipsDescendants = true
                main.ZIndex = 301
                Corner(main, 18)
                Stroke(main, CurrentTheme.Accent, 1.5).Transparency = 0.35
                local cont = Instance.new("Frame", main)
                cont.BackgroundTransparency = 1
                cont.ClipsDescendants = false
                cont.ZIndex = 302

                local hueBar = Instance.new("Frame", cont)
                hueBar.ZIndex = 303
                Corner(hueBar, 6)
                hueBar.Active = true
                Stroke(hueBar, Color3.new(1,1,1), 1).Transparency = 0.8
                local grad = Instance.new("UIGradient", hueBar)
                grad.Rotation = 90
                local colors = {}
                for i=0,1,0.1 do table.insert(colors, ColorSequenceKeypoint.new(i, Color3.fromHSV(i,1,1))) end
                grad.Color = ColorSequence.new(colors)
                local hueMarker = Instance.new("Frame", hueBar)
                hueMarker.AnchorPoint = Vector2.new(0.5,0.5)
                hueMarker.Size = UDim2.new(1,6,0,6)
                hueMarker.BackgroundColor3 = Color3.new(1,1,1)
                hueMarker.ZIndex = 310
                Corner(hueMarker, 3)
                Stroke(hueMarker, Color3.new(0,0,0), 1)

                local right = Instance.new("Frame", cont)
                right.BackgroundColor3 = CurrentTheme.ElementBg
                right.BackgroundTransparency = ElementTrans
                right.ZIndex = 302
                Corner(right, 12)
                local preview = Instance.new("Frame", right)
                preview.ZIndex = 303
                Corner(preview, 12)
                Stroke(preview, CurrentTheme.Stroke, 1)
                local hexBox = Instance.new("TextBox", preview)
                hexBox.Size = UDim2.new(1,0,1,0)
                hexBox.BackgroundTransparency = 1
                hexBox.Font = Enum.Font.GothamBold
                hexBox.TextSize = 14
                hexBox.TextScaled = true
                hexBox.TextColor3 = Color3.new(1,1,1)
                hexBox.TextStrokeTransparency = 0.3
                hexBox.ClearTextOnFocus = false
                hexBox.ZIndex = 304
                local hexLimit = Instance.new("UITextSizeConstraint", hexBox)
                hexLimit.MaxTextSize = 14
                hexLimit.MinTextSize = 6
                local btns = Instance.new("Frame", right)
                btns.BackgroundTransparency = 1
                btns.ZIndex = 302
                local bLay = Instance.new("UIListLayout", btns)
                bLay.FillDirection = Enum.FillDirection.Horizontal
                bLay.Padding = UDim.new(0,10)
                local done = Instance.new("TextButton", btns)
                done.Size = UDim2.new(0.5,-5,1,0)
                done.BackgroundColor3 = CurrentTheme.Accent
                done.Text = "Done"
                done.Font = Enum.Font.GothamBold
                done.TextScaled = true
                done.TextColor3 = Color3.new(1,1,1)
                done.ZIndex = 303
                Corner(done, 12)
                Instance.new("UITextSizeConstraint", done).MaxTextSize = 14
                local ex = Instance.new("TextButton", btns)
                ex.Size = UDim2.new(0.5,-5,1,0)
                ex.BackgroundColor3 = CurrentTheme.ElementBg2
                ex.Text = "Exit"
                ex.Font = Enum.Font.GothamBold
                ex.TextScaled = true
                ex.TextColor3 = CurrentTheme.Text
                ex.ZIndex = 303
                Corner(ex, 12)
                Instance.new("UITextSizeConstraint", ex).MaxTextSize = 14

                local svFrame = Instance.new("ImageLabel", cont)
                svFrame.Image = "rbxassetid://4155801252"
                svFrame.BackgroundColor3 = Color3.fromHSV(Hue,1,1)
                svFrame.ZIndex = 303
                svFrame.ClipsDescendants = true
                Corner(svFrame, 10)
                svFrame.Active = true
                Stroke(svFrame, Color3.new(1,1,1), 1).Transparency = 0.8
                local svMarker = Instance.new("Frame", svFrame)
                svMarker.AnchorPoint = Vector2.new(0.5,0.5)
                svMarker.Size = UDim2.new(0,16,0,16)
                svMarker.BackgroundColor3 = Color
                svMarker.ZIndex = 310
                Corner(svMarker, 8)
                Stroke(svMarker, Color3.new(1,1,1), 2)

                local function LayoutPicker()
                    if not ov.Parent or not main.Parent then return end
                    local vp = ov.AbsoluteSize
                    if vp.X < 10 or vp.Y < 10 then
                        local cam = workspace.CurrentCamera
                        vp = cam and cam.ViewportSize or Vector2.new(800, 450)
                    end
                    local MARGIN = 8
                    local maxW = math.max(150, vp.X - MARGIN*2)
                    local maxH = math.max(120, vp.Y - MARGIN*2)
                    local mS = Main.AbsoluteSize
                    local mP = Main.AbsolutePosition
                    local w = math.floor(math.clamp(mS.X * 0.94, math.min(280, maxW), math.min(520, maxW)))
                    local h = math.floor(math.clamp(mS.Y * 0.88, math.min(180, maxH), math.min(340, maxH)))
                    local ovP = ov.AbsolutePosition
                    local cx = mP.X + mS.X/2 - ovP.X
                    local cy = mP.Y + mS.Y/2 - ovP.Y
                    local x = math.clamp(cx - w/2, MARGIN, math.max(MARGIN, vp.X - w - MARGIN))
                    local y = math.clamp(cy - h/2, MARGIN, math.max(MARGIN, vp.Y - h - MARGIN))
                    main.Size = UDim2.fromOffset(w, h)
                    main.Position = UDim2.fromOffset(math.floor(x), math.floor(y))

                    local PAD, GAP = 10, 10
                    local iw, ih = w - PAD*2, h - PAD*2
                    cont.Position = UDim2.fromOffset(PAD, PAD)
                    cont.Size = UDim2.fromOffset(iw, ih)

                    local hueW = math.clamp(math.floor(iw * 0.09), 20, 34)
                    local rem = iw - hueW - GAP*2
                    local rightW = math.floor(rem * 0.48)
                    local svW = rem - rightW
                    hueBar.Position = UDim2.fromOffset(0, 0)
                    hueBar.Size = UDim2.fromOffset(hueW, ih)
                    right.Position = UDim2.fromOffset(hueW + GAP, 0)
                    right.Size = UDim2.fromOffset(rightW, ih)
                    svFrame.Position = UDim2.fromOffset(hueW + GAP + rightW + GAP, 0)
                    svFrame.Size = UDim2.fromOffset(svW, ih)

                    local pv = math.clamp(math.floor(ih * 0.40), 26, 80)
                    local bh = math.clamp(math.floor(ih * 0.20), 22, 36)
                    local vgap = 8
                    local top = math.max(6, math.floor((ih - (pv + vgap + bh)) / 2))
                    preview.Position = UDim2.fromOffset(8, top)
                    preview.Size = UDim2.new(1,-16,0,pv)
                    btns.Position = UDim2.fromOffset(8, top + pv + vgap)
                    btns.Size = UDim2.new(1,-16,0,bh)
                end
                LayoutPicker()
                task.defer(LayoutPicker)
                local layoutConns = {
                    Main:GetPropertyChangedSignal("AbsoluteSize"):Connect(LayoutPicker),
                    Main:GetPropertyChangedSignal("AbsolutePosition"):Connect(LayoutPicker),
                    ov:GetPropertyChangedSignal("AbsoluteSize"):Connect(LayoutPicker),
                }
                ov.Destroying:Connect(function()
                    for _, c in ipairs(layoutConns) do c:Disconnect() end
                end)
                local function toHex(c) return "#"..c:ToHex() end
                local curSat = Sat
                local curVib = Vib
                local curHue = Hue
                local function updateSV(noFire)
                    svFrame.BackgroundColor3 = Color3.fromHSV(curHue,1,1)
                    local c = Color3.fromHSV(curHue,curSat,curVib)
                    Color = c
                    svMarker.BackgroundColor3 = c
                    preview.BackgroundColor3 = c
                    hexBox.Text = toHex(c)
                    svMarker.Position = UDim2.new(curSat,0,1-curVib,0)
                    PreviewBtn.BackgroundColor3 = c
                    if not noFire then
                    end
                end
                local function updateHue(noFire)
                    curHue = Hue
                    svFrame.BackgroundColor3 = Color3.fromHSV(curHue,1,1)
                    hueMarker.BackgroundColor3 = Color3.fromHSV(curHue,1,1)
                    local c = Color3.fromHSV(curHue,curSat,curVib)
                    Color = c
                    svMarker.BackgroundColor3 = c
                    preview.BackgroundColor3 = c
                    hexBox.Text = toHex(c)
                    hueMarker.Position = UDim2.new(0.5,0,curHue,0)
                    PreviewBtn.BackgroundColor3 = c
                end
                local draggingMode = nil
                local origScroll = TabPage.ScrollingEnabled
                local pickerResources = ConnectionBag.new()
                local function UpdateSatVib(pos)
                    local p = svFrame.AbsolutePosition
                    local s = svFrame.AbsoluteSize
                    if s.X==0 or s.Y==0 then return end
                    curSat = math.clamp((pos.X-p.X)/s.X,0,1)
                    curVib = 1-math.clamp((pos.Y-p.Y)/s.Y,0,1)
                    Sat = curSat
                    Vib = curVib
                    updateSV()
                end
                local function UpdateHue(pos)
                    local p = hueBar.AbsolutePosition
                    local s = hueBar.AbsoluteSize
                    if s.Y==0 then return end
                    curHue = math.clamp((pos.Y-p.Y)/s.Y,0,1)
                    Hue = curHue
                    updateHue()
                end
                Hue,Sat,Vib = Color3.toHSV(Color)
                curHue,curSat,curVib = Hue,Sat,Vib
                svMarker.Position = UDim2.new(curSat,0,1-curVib,0)
                hueMarker.Position = UDim2.new(0.5,0,curHue,0)
                svFrame.BackgroundColor3 = Color3.fromHSV(curHue,1,1)
                hueMarker.BackgroundColor3 = Color3.fromHSV(curHue,1,1)
                preview.BackgroundColor3 = Color
                hexBox.Text = toHex(Color)
                svFrame.InputBegan:Connect(function(i) if i.UserInputType==Enum.UserInputType.MouseButton1 or i.UserInputType==Enum.UserInputType.Touch then TabPage.ScrollingEnabled=false draggingMode="SatVib" UpdateSatVib(i.Position) end end)
                svFrame.InputChanged:Connect(function(i) if (i.UserInputType==Enum.UserInputType.MouseMovement or i.UserInputType==Enum.UserInputType.Touch) and draggingMode=="SatVib" then UpdateSatVib(i.Position) end end)
                hueBar.InputBegan:Connect(function(i) if i.UserInputType==Enum.UserInputType.MouseButton1 or i.UserInputType==Enum.UserInputType.Touch then TabPage.ScrollingEnabled=false draggingMode="Hue" UpdateHue(i.Position) end end)
                hueBar.InputChanged:Connect(function(i) if (i.UserInputType==Enum.UserInputType.MouseMovement or i.UserInputType==Enum.UserInputType.Touch) and draggingMode=="Hue" then UpdateHue(i.Position) end end)
                pickerResources:Connect(UserInputService.InputChanged, function(i) if i.UserInputType==Enum.UserInputType.MouseMovement or i.UserInputType==Enum.UserInputType.Touch then if draggingMode=="SatVib" then UpdateSatVib(i.Position) elseif draggingMode=="Hue" then UpdateHue(i.Position) end end end)
                pickerResources:Connect(UserInputService.InputEnded, function(i) if i.UserInputType==Enum.UserInputType.MouseButton1 or i.UserInputType==Enum.UserInputType.Touch then draggingMode=nil TabPage.ScrollingEnabled=origScroll end end)
                pickerResources:Connect(ov.Destroying, function() pickerResources:Destroy() end)
                hexBox.FocusLost:Connect(function(enter)
                    if enter then
                        local txt = hexBox.Text:gsub("%s","")
                        if txt:sub(1,1)=="#" then
                            local ok,col = pcall(Color3.fromHex, txt)
                            if ok and col then
                                local h,s,v = Color3.toHSV(col)
                                curHue,curSat,curVib = h,s,v
                                Hue,Sat,Vib = h,s,v
                                svMarker.Position = UDim2.new(curSat,0,1-curVib,0)
                                hueMarker.Position = UDim2.new(0.5,0,curHue,0)
                                svFrame.BackgroundColor3 = Color3.fromHSV(curHue,1,1)
                                hueMarker.BackgroundColor3 = Color3.fromHSV(curHue,1,1)
                                preview.BackgroundColor3 = col
                                PreviewBtn.BackgroundColor3 = col
                                Color = col
                                local h2,s2,v2 = Color3.toHSV(col)
                                curHue,curSat,curVib = h2,s2,v2
                                Hue,Sat,Vib = h2,s2,v2
                                return
                            end
                        end
                        local num = tonumber(txt:gsub("°",""))
                        if num then
                            if num>1 and num<=360 then curHue = num/360 else curHue = math.clamp(num,0,1) end
                            Hue = curHue
                            updateHue()
                        end
                    end
                end)
                local function closePicker(apply)
                    TabPage.ScrollingEnabled=origScroll
                    if apply then
                        Fire(Color)
                    else
                        Color = originalColor
                        PreviewBtn.BackgroundColor3 = originalColor
                        Hue,Sat,Vib = Color3.toHSV(originalColor)
                    end
                    ov:Destroy()
                    AdvancedGui=nil
                end
                ex.MouseButton1Click:Connect(function() closePicker(false) end)
                done.MouseButton1Click:Connect(function() closePicker(true) end)
                AdvancedGui = ov
            end
            if Cfg.Mode=="Developer" then
                if #Cfg.DeveloperColors>0 then
                    DevContainer = Instance.new("Frame", TabPage)
                    DevContainer.Size = UDim2.new(1,-4,0, 50)
                    DevContainer.BackgroundColor3 = CurrentTheme.TabListBg
                    DevContainer.BackgroundTransparency = ElementTrans
                    DevContainer.BorderSizePixel = 0
                    RegisterThemable(DevContainer, "BackgroundColor3", "TabListBg")
                    Corner(DevContainer, 8)
                    local grid = Instance.new("UIGridLayout", DevContainer)
                    grid.CellSize = UDim2.new(0,28,0,28)
                    grid.CellPadding = UDim2.new(0,6,0,6)
                    local pad = Instance.new("UIPadding", DevContainer)
                    pad.PaddingTop = UDim.new(0,6) pad.PaddingLeft = UDim.new(0,6) pad.PaddingRight = UDim.new(0,6) pad.PaddingBottom = UDim.new(0,6)
                    for _,col in ipairs(Cfg.DeveloperColors) do
                        local b = Instance.new("TextButton", DevContainer)
                        b.Size = UDim2.new(0,28,0,28)
                        b.BackgroundColor3 = col
                        b.BackgroundTransparency = 0
                        b.Text = ""
                        Corner(b, 6)
                        Stroke(b, CurrentTheme.Stroke, 1)
                        b.MouseButton1Click:Connect(function() Fire(col) end)
                    end
                end
            end
            PreviewBtn.MouseButton1Click:Connect(function()
                if Cfg.Mode=="Developer" then
                    if #Cfg.DeveloperColors>0 then
                        local idx = 1
                        for i,c in ipairs(Cfg.DeveloperColors) do if c:ToHex()==Color:ToHex() then idx=i+1 break end end
                        if idx>#Cfg.DeveloperColors then idx=1 end
                        Fire(Cfg.DeveloperColors[idx])
                    end
                else
                    OpenAdvancedPicker()
                end
            end)
            local function Set(c)
                if typeof(c)=="string" then local ok,col=pcall(Color3.fromHex,c) if ok then c=col end end
                Color=c
                local h,s,v = Color3.toHSV(c)
                Hue,Sat,Vib = h,s,v
                PreviewBtn.BackgroundColor3=c
            end
            return {
                Frame=Frame,
                Set=function(self,c) Set(c) Fire(c) end,
                SetValue=function(self,c) Set(c) Fire(c) end,
                Get=function() return Color end,
                GetValue=function() return Color end,
                SetVisible=function(self,v) Frame.Visible=v if DevContainer then DevContainer.Visible=v end end,
                Destroy=function() Frame:Destroy() if DevContainer then DevContainer:Destroy() end if AdvancedGui then AdvancedGui:Destroy() end end,
                Update=function(self,newCfg) if newCfg.Title then Title.Text=newCfg.Title end if newCfg.Default then Set(newCfg.Default) end if newCfg.DeveloperColors then Cfg.DeveloperColors=newCfg.DeveloperColors end end
            }
        end

        local function CreateKeybind(Cfg)
            local Key = Cfg.Default or Enum.KeyCode.F
            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0,38)
            Frame.BackgroundColor3 = CurrentTheme.ElementBg
            Corner(Frame, 10)
            RegisterThemable(Frame, "BackgroundColor3", "ElementBg")
            RegisterThemable(SoftStroke(Frame, CurrentTheme.Stroke), "Stroke", "Stroke")
            AddSearch(Frame, Cfg.Title, "Keybind", Name)
            local Label = Instance.new("TextLabel", Frame)
            Label.Text = Cfg.Title.." : "..Key.Name
            Label.Size = UDim2.new(1,-16,1,0)
            Label.Position = UDim2.new(0,10,0,0)
            Label.BackgroundTransparency = 1
            Label.TextXAlignment = Enum.TextXAlignment.Left
            Label.Font = Enum.Font.GothamMedium
            Label.TextSize = 12
            Label.TextColor3 = CurrentTheme.Text
            Label.AutoLocalize = true
            RegisterThemable(Label, "TextColor3", "Text")
            local Btn = Instance.new("TextButton", Frame)
            Btn.Size = UDim2.new(1,0,1,0)
            Btn.BackgroundTransparency = 1
            Btn.Text = ""
            Btn.MouseButton1Click:Connect(function()
                if IsScrolling then return end
                Label.Text = Cfg.Title.." : ..."
                local conn; conn = TrackConnection(UserInputService.InputBegan:Connect(function(input)
                    if input.UserInputType == Enum.UserInputType.Keyboard then
                        Key = input.KeyCode
                        Label.Text = Cfg.Title.." : "..Key.Name
                        pcall(Cfg.Callback or function() end, Key)
                        conn:Disconnect()
                    end
                end))
            end)
            local CreateKeybindAPI = {}
            function CreateKeybindAPI:Refresh(newCfg) return CreateKeybindAPI end
            function CreateKeybindAPI:SetValue(k)
                if type(k) == "string" then
                    local ok, kc = pcall(function() return Enum.KeyCode[k] end)
                    k = ok and kc or nil
                end
                if typeof(k) == "EnumItem" then
                    Key = k
                    Label.Text = Cfg.Title.." : "..Key.Name
                    pcall(Cfg.Callback or function() end, Key)
                end
                return CreateKeybindAPI
            end
            function CreateKeybindAPI:GetValue() return Key end
            function CreateKeybindAPI:Set(k) return self:SetValue(k) end
            function CreateKeybindAPI:Get() return Key end
            return CreateKeybindAPI

        end

        local function CreateCode(Cfg)
            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0,80)
            Frame.BackgroundColor3 = CurrentTheme.TabListBg
            Corner(Frame, 10)
            RegisterThemable(Frame, "BackgroundColor3", "TabListBg")
            AddSearch(Frame, Cfg.Code or "Code", "Code", Name)
            local CodeLabel = Instance.new("TextLabel", Frame)
            CodeLabel.Size = UDim2.new(1,-16,1,-16)
            CodeLabel.Position = UDim2.new(0,8,0,8)
            CodeLabel.BackgroundTransparency = 1
            CodeLabel.Text = Cfg.Code or ""
            CodeLabel.Font = Enum.Font.Code
            CodeLabel.TextSize = 11
            CodeLabel.TextColor3 = CurrentTheme.Accent
            CodeLabel.TextXAlignment = Enum.TextXAlignment.Left
            CodeLabel.TextYAlignment = Enum.TextYAlignment.Top
            CodeLabel.TextWrapped = true
            RegisterThemable(CodeLabel, "TextColor3", "Accent")
            local CreateCodeAPI = {}
            function CreateCodeAPI:Refresh(newCfg) return CreateCodeAPI end
            return CreateCodeAPI

        end

        local function CreateLabel(Cfg)
            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0,24)
            Frame.AutomaticSize = Enum.AutomaticSize.Y
            Frame.BackgroundTransparency = 1
            AddSearch(Frame, Cfg.Title or Cfg.Text or "Label", "Label", Name)
            local Label = Instance.new("TextLabel", Frame)
            Label.Size = UDim2.new(1,0,0,20)
            Label.AutomaticSize = Enum.AutomaticSize.Y
            Label.BackgroundTransparency = 1
            Label.Text = Cfg.Title or Cfg.Text or "Label"
            Label.Font = Cfg.Font or Enum.Font.Gotham
            Label.TextSize = Cfg.TextSize or 13
            Label.TextColor3 = Cfg.Color or Cfg.TextColor or CurrentTheme.Text
            Label.TextXAlignment = Cfg.Alignment and (Cfg.Alignment == "Center" and Enum.TextXAlignment.Center or Cfg.Alignment == "Right" and Enum.TextXAlignment.Right or Enum.TextXAlignment.Left) or Enum.TextXAlignment.Left
            Label.TextYAlignment = Enum.TextYAlignment.Top
            Label.TextWrapped = true
            Label.AutoLocalize = Cfg.AutoLocalize ~= false
            RegisterThemable(Label, "TextColor3", "Text")
            local CreateLabelAPI = {}
            function CreateLabelAPI:Refresh(newCfg) return CreateLabelAPI end
            return CreateLabelAPI

        end

        local function CreateSeparator(Cfg)
            Cfg = Cfg or {}
            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0,16)
            Frame.BackgroundTransparency = 1
            AddSearch(Frame, "Separator", "Separator", Name)
            local Line = Instance.new("Frame", Frame)
            Line.Size = UDim2.new(1,0,0,Cfg.Thickness or 1)
            Line.Position = UDim2.new(0,0,0.5,0)
            Line.BackgroundColor3 = Cfg.Color or CurrentTheme.Stroke
            Line.BackgroundTransparency = Cfg.Transparency or 0.5
            Line.BorderSizePixel = 0
            Corner(Line, 1)
            if not Cfg.Color then RegisterThemable(Line, "BackgroundColor3", "Stroke") end
            if Cfg.Title and Cfg.Title ~= "" then
                local Text = Instance.new("TextLabel", Frame)
                Text.Size = UDim2.new(0,0,1,0)
                Text.AutomaticSize = Enum.AutomaticSize.X
                Text.Position = UDim2.new(0.5,0,0,0)
                Text.AnchorPoint = Vector2.new(0.5,0)
                Text.BackgroundColor3 = CurrentTheme.MainBg
                Text.BorderSizePixel = 0
                Text.Text = " "..Cfg.Title.." "
                Text.Font = Enum.Font.Gotham
                Text.TextSize = 11
                Text.TextColor3 = CurrentTheme.SubText
                Text.AutoLocalize = true
                Corner(Text, 4)
                RegisterThemable(Text, "BackgroundColor3", "MainBg")
                RegisterThemable(Text, "TextColor3", "SubText")
                local Pad = Instance.new("UIPadding", Text)
                Pad.PaddingLeft = UDim.new(0,8) Pad.PaddingRight = UDim.new(0,8)
            end
            local CreateSeparatorAPI = {}
            function CreateSeparatorAPI:Refresh(newCfg) return CreateSeparatorAPI end
            return CreateSeparatorAPI

        end

        local function IsUrlImage(str)
            if not str then return false end
            str = tostring(str):lower()
            return str:match("^https?://") ~= nil
        end

        local function ResolveImageAsset(inputStr)
            if not inputStr or inputStr == "" then return "" end
            local s = tostring(inputStr)
            if GGH_ICONS[s] then return GGH_ICONS[s] end
            if GGH_ICONS[s:lower()] then return GGH_ICONS[s:lower()] end
            if IsUrlImage(s) then
                return s
            end
            if s:match("rbxassetid://%d+") then
                return s
            end
            local id = s:match("id=(%d+)") or s:match("rbxassetid://(%d+)") or s:match("(%d+)")
            if id then
                return "rbxassetid://"..id
            end
            return s
        end

        local function CreateImage(Cfg)
            Cfg = Cfg or {}
            local function extractId(text)
                if not text then return nil end
                text = tostring(text)
                local id = text:match("id=(%d+)") or text:match("rbxassetid://(%d+)") or text:match("(%d+)")
                return id
            end

            local Frame = Instance.new("Frame", TabPage)
            local useInput = Cfg.AllowInput or Cfg.Input or Cfg.Viewer or false
            local imgHeight = Cfg.Height or (useInput and 320 or 120)
            Frame.Size = UDim2.new(1,-4,0,imgHeight + (Cfg.Title and Cfg.Title ~= "" and 24 or 0))
            Frame.BackgroundColor3 = CurrentTheme.ElementBg
            Frame.BackgroundTransparency = 0
            Corner(Frame, 10)
            RegisterThemable(Frame, "BackgroundColor3", "ElementBg")
            AddSearch(Frame, Cfg.Title or "Image", "Image", Name)

            local ImageLabel = Instance.new("ImageLabel", Frame)
            local titleOffset = (Cfg.Title and Cfg.Title ~= "" and 24 or 0)
            if useInput then
                ImageLabel.Size = UDim2.new(1,-12,0,200)
                ImageLabel.Position = UDim2.new(0,6,0,50)
            else
                ImageLabel.Size = Cfg.Size and UDim2.new(0,Cfg.Size.X,0,Cfg.Size.Y) or UDim2.new(1,-12,1,-12 - titleOffset)
                ImageLabel.Position = UDim2.new(0,6,0,6)
            end
            ImageLabel.BackgroundColor3 = Color3.fromRGB(20,20,22)
            ImageLabel.BackgroundTransparency = 0.2
            ImageLabel.ScaleType = Cfg.ScaleType or Enum.ScaleType.Fit
            Corner(ImageLabel, 8)

            local rawImg = Cfg.Image or Cfg.Url or Cfg.Id or Cfg.Default or ""
            ImageLabel.Image = ResolveImageAsset(rawImg)

            if useInput then
                local InputBox = Instance.new("TextBox", Frame)
                InputBox.Size = UDim2.new(1,-12,0,32)
                InputBox.Position = UDim2.new(0,6,0,6)
                InputBox.BackgroundColor3 = CurrentTheme.ElementBg2
                InputBox.PlaceholderText = Cfg.Placeholder or "ID or https:// image.png/jpg"
                InputBox.Text = Cfg.DefaultText or tostring(rawImg or "")
                InputBox.TextColor3 = CurrentTheme.Text
                InputBox.PlaceholderColor3 = CurrentTheme.SubText
                InputBox.Font = Enum.Font.Gotham
                InputBox.TextSize = 12
                InputBox.ClearTextOnFocus = false
                Corner(InputBox, 8)
                RegisterThemable(InputBox, "BackgroundColor3", "ElementBg2")

                local function showImageFromInput()
                    local txt = InputBox.Text
                    if txt and txt ~= "" then
                        ImageLabel.Image = ResolveImageAsset(txt)
                    end
                end

                InputBox.FocusLost:Connect(function(enter)
                    if enter then showImageFromInput() end
                end)

                local ShowBtn = Instance.new("TextButton", Frame)
                ShowBtn.Size = UDim2.new(1,-12,0,28)
                ShowBtn.Position = UDim2.new(0,6,0,258)
                ShowBtn.BackgroundColor3 = CurrentTheme.Accent
                ShowBtn.Text = "Show Image"
                ShowBtn.TextColor3 = Color3.new(1,1,1)
                ShowBtn.Font = Enum.Font.GothamBold
                ShowBtn.TextSize = 12
                Corner(ShowBtn, 8)
                RegisterThemable(ShowBtn, "BackgroundColor3", "Accent")
                ShowBtn.MouseButton1Click:Connect(showImageFromInput)
            end

            if Cfg.Title and Cfg.Title ~= "" then
                local Title = Instance.new("TextLabel", Frame)
                Title.Size = UDim2.new(1,-12,0,20)
                Title.Position = UDim2.new(0,6,1,-20)
                Title.BackgroundTransparency = 1
                Title.Text = Cfg.Title
            Title.AutoLocalize = true
                Title.Font = Enum.Font.GothamMedium
                Title.TextSize = 12
                Title.TextColor3 = CurrentTheme.Text
                Title.TextXAlignment = Enum.TextXAlignment.Center
                Title.AutoLocalize = true
                RegisterThemable(Title, "TextColor3", "Text")
            end

            local ImageAPI = {}
            function ImageAPI:SetImage(newImg)
                ImageLabel.Image = ResolveImageAsset(newImg)
                return ImageAPI
            end
            function ImageAPI:Refresh(newCfg)
                if newCfg and newCfg.Image then
                    ImageLabel.Image = ResolveImageAsset(newCfg.Image)
                end
                return ImageAPI
            end
            return ImageAPI
        end

        local function CreateLinkButton(Cfg)
            Cfg = Cfg or {}
            local title = Cfg.Title or Cfg.Name or "Link"
            local linkUrl = Cfg.Link or Cfg.Url or Cfg.Discord or Cfg.Youtube or Cfg.YouTube or ""
            local imgSrc = Cfg.Image or Cfg.Icon or nil
            local btnText = Cfg.ButtonText or Cfg.Text or "Copy Link"

            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0, (imgSrc and 110 or 70))
            Frame.BackgroundColor3 = CurrentTheme.ElementBg
            Corner(Frame, 10)
            RegisterThemable(Frame, "BackgroundColor3", "ElementBg")
            AddSearch(Frame, title.." "..linkUrl, "LinkButton", Name)

            local ImgLabel
            local yOffset = 0
            if imgSrc then
                ImgLabel = Instance.new("ImageLabel", Frame)
                ImgLabel.Size = UDim2.new(0,50,0,50)
                ImgLabel.Position = UDim2.new(0.5,-25,0,8)
                ImgLabel.BackgroundColor3 = Color3.fromRGB(20,20,22)
                ImgLabel.BackgroundTransparency = 0.3
                ImgLabel.Image = ResolveImageAsset(imgSrc)
                ImgLabel.ScaleType = Enum.ScaleType.Crop
                Corner(ImgLabel, 25)
                yOffset = 58
            end

            local NameLabel = Instance.new("TextLabel", Frame)
            NameLabel.Size = UDim2.new(1,-12,0,20)
            NameLabel.Position = UDim2.new(0,6,0, yOffset + 4)
            NameLabel.BackgroundTransparency = 1
            NameLabel.Text = title
            NameLabel.Font = Enum.Font.GothamBold
            NameLabel.TextSize = 13
            NameLabel.TextColor3 = CurrentTheme.Text
            NameLabel.TextXAlignment = Enum.TextXAlignment.Center
            NameLabel.AutoLocalize = true
            AddTextStroke(NameLabel)
            RegisterThemable(NameLabel, "TextColor3", "Text")

            local CopyBtn = Instance.new("TextButton", Frame)
            CopyBtn.Size = UDim2.new(1,-12,0,32)
            CopyBtn.Position = UDim2.new(0,6,0, yOffset + 26)
            CopyBtn.BackgroundColor3 = CurrentTheme.ElementBg2
            CopyBtn.Text = btnText
            CopyBtn.Font = Enum.Font.GothamMedium
            CopyBtn.TextSize = 12
            CopyBtn.TextColor3 = CurrentTheme.Text
            CopyBtn.AutoLocalize = true
            Corner(CopyBtn, 8)
            RegisterThemable(Stroke(CopyBtn, CurrentTheme.StrokeLight, 1), "Stroke", "StrokeLight")
            RegisterThemable(CopyBtn, "BackgroundColor3", "ElementBg2")
            RegisterThemable(CopyBtn, "TextColor3", "Text")
            local CopyIcon = MakeIcon(CopyBtn, "clipboard-copy", 16)
            CopyIcon.AnchorPoint = Vector2.new(0, 0.5)
            CopyIcon.Position = UDim2.new(0, 12, 0.5, 0)
            CopyIcon.ZIndex = CopyBtn.ZIndex + 1
            BindIconToText(CopyBtn, CopyIcon)
            local function ApplyCopyIconTint()
                CopyIcon.ImageColor3 = CopyBtn.TextColor3
            end

            local function DoCopy()
                local ok = pcall(function()
                    if setclipboard then setclipboard(tostring(linkUrl)) end
                end)
                local old = CopyBtn.Text
                CopyBtn.Text = "Copied!"
                CopyIcon.Image = ResolveIcon("circle-check") or ""
                Tween(CopyBtn, {BackgroundColor3 = CurrentTheme.Accent}, 0.15)
                task.wait(1.2)
                CopyBtn.Text = old
                CopyIcon.Image = ResolveIcon("clipboard-copy") or ""
                Tween(CopyBtn, {BackgroundColor3 = CurrentTheme.ElementBg2}, 0.15)
                if Cfg.Callback then pcall(Cfg.Callback, linkUrl) end
            end

            CopyBtn.MouseButton1Click:Connect(DoCopy)

            local API = {}
            function API:SetLink(newLink) linkUrl = newLink return API end
            function API:SetTitle(t) NameLabel.Text = t return API end
            function API:SetImage(i) if ImgLabel then ImgLabel.Image = ResolveImageAsset(i) end return API end
            function API:SetButtonText(t) CopyBtn.Text = t return API end
            function API:Refresh(newCfg)
                if not newCfg then return API end
                if newCfg.Title then NameLabel.Text = newCfg.Title end
                if newCfg.Link or newCfg.Url then linkUrl = newCfg.Link or newCfg.Url end
                if newCfg.Image and ImgLabel then ImgLabel.Image = ResolveImageAsset(newCfg.Image) end
                if newCfg.ButtonText then CopyBtn.Text = newCfg.ButtonText end
                return API
            end
            return API
        end

        local Players = game:GetService("Players")
        local HttpService = game:GetService("HttpService")

        local function GetInstanceByPath(pathStr)
            if not pathStr or pathStr == "" then return nil end
            local parts = {}
            for p in string.gmatch(tostring(pathStr), "[^%.]+") do table.insert(parts, p) end
            if #parts == 0 then return nil end
            local first = string.lower(parts[1])
            local cur = nil
            if first == "workspace" then cur = workspace
            elseif first == "game" then cur = game
            elseif first == "players" then cur = Players
            elseif first == "replicatedstorage" then cur = game:GetService("ReplicatedStorage")
            elseif first == "replicatedfirst" then cur = game:GetService("ReplicatedFirst")
            elseif first == "startergui" then cur = game:GetService("StarterGui")
            elseif first == "lighting" then cur = game:GetService("Lighting")
            elseif first == "localplayer" then cur = Players.LocalPlayer
            else
                cur = workspace
                parts = {}
                for p in string.gmatch(tostring(pathStr), "[^%.]+") do table.insert(parts, p) end
            end

            local startIdx = 2
            if first ~= "workspace" and first ~= "game" and first ~= "players" and first ~= "replicatedstorage" and first ~= "replicatedfirst" and first ~= "startergui" and first ~= "lighting" and first ~= "localplayer" then
                startIdx = 1
                cur = workspace
                local tryGame = game
                local found = tryGame
                for i=1,#parts do
                    local child = found:FindFirstChild(parts[i])
                    if child then found = child else found = nil break end
                end
                if found then return found end
            end

            for i=startIdx,#parts do
                if not cur then break end
                local name = parts[i]
                local nextInst = cur:FindFirstChild(name)
                if nextInst then
                    cur = nextInst
                else
                    local ok, val = pcall(function() return cur[name] end)
                    if ok then
                        if i == #parts then
                            return val
                        else
                            cur = val
                        end
                    else
                        cur = nil
                        break
                    end
                end
            end
            return cur
        end

        local function ExtractValueFromInstance(obj)
            if obj == nil then return "N/A" end
            if type(obj) ~= "userdata" and type(obj) ~= "table" then return tostring(obj) end
            local ok, v = pcall(function() return obj.Value end)
            if ok then return v end
            local ok2, t = pcall(function() return obj.Text end)
            if ok2 then return t end
            return tostring(obj)
        end

        local function CreatePlayerStats(Cfg)
            Cfg = Cfg or {}
            local title = Cfg.Title or Cfg.Name or "Player Stats"
            local playerInput = Cfg.Player or Cfg.PlayerName or Players.LocalPlayer
            local customImg = Cfg.Image or Cfg.Avatar or nil
            local statsList = Cfg.Stats or Cfg.List or {}
            local updateInterval = Cfg.UpdateInterval or Cfg.Interval or 1
            local autoUpdate = Cfg.AutoUpdate
            if autoUpdate == nil then autoUpdate = true end

            local totalStats = #statsList
            local baseHeight = 78 + (totalStats * 32) + 8
            if baseHeight < 120 then baseHeight = 120 end

            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0, baseHeight)
            Frame.BackgroundColor3 = CurrentTheme.ElementBg
            Frame.AutomaticSize = Enum.AutomaticSize.Y
            Corner(Frame, 10)
            RegisterThemable(Frame, "BackgroundColor3", "ElementBg")
            AddSearch(Frame, title, "PlayerStats", Name)

            local HeaderF = Instance.new("Frame", Frame)
            HeaderF.Size = UDim2.new(1,0,0,68)
            HeaderF.BackgroundTransparency = 1

            local AvatarImg = Instance.new("ImageLabel", HeaderF)
            AvatarImg.Size = UDim2.new(0,48,0,48)
            AvatarImg.Position = UDim2.new(0,10,0,10)
            AvatarImg.BackgroundColor3 = Color3.fromRGB(30,30,35)
            AvatarImg.BackgroundTransparency = 0.2
            AvatarImg.ScaleType = Enum.ScaleType.Crop
            Corner(AvatarImg, 24)

            local PlayerNameLabel = Instance.new("TextLabel", HeaderF)
            PlayerNameLabel.Size = UDim2.new(1,-70,0,20)
            PlayerNameLabel.Position = UDim2.new(0,68,0,12)
            PlayerNameLabel.BackgroundTransparency = 1
            PlayerNameLabel.Text = title
            PlayerNameLabel.Font = Enum.Font.GothamBold
            PlayerNameLabel.TextSize = 14
            PlayerNameLabel.TextColor3 = CurrentTheme.Text
            PlayerNameLabel.TextXAlignment = Enum.TextXAlignment.Left
            PlayerNameLabel.AutoLocalize = true
            AddTextStroke(PlayerNameLabel)
            RegisterThemable(PlayerNameLabel, "TextColor3", "Text")

            local RealPlayerName = Instance.new("TextLabel", HeaderF)
            RealPlayerName.Size = UDim2.new(1,-70,0,16)
            RealPlayerName.Position = UDim2.new(0,68,0,32)
            RealPlayerName.BackgroundTransparency = 1
            RealPlayerName.Text = "Loading..."
            RealPlayerName.Font = Enum.Font.Gotham
            RealPlayerName.TextSize = 12
            RealPlayerName.TextColor3 = CurrentTheme.SubText
            RealPlayerName.TextXAlignment = Enum.TextXAlignment.Left
            RegisterThemable(RealPlayerName, "TextColor3", "SubText")

            local StatsContainer = Instance.new("Frame", Frame)
            StatsContainer.Name = "StatsContainer"
            StatsContainer.Size = UDim2.new(1,-12,0,0)
            StatsContainer.AutomaticSize = Enum.AutomaticSize.Y
            StatsContainer.Position = UDim2.new(0,6,0,70)
            StatsContainer.BackgroundTransparency = 1
            local sLayout = Instance.new("UIListLayout", StatsContainer)
            sLayout.Padding = UDim.new(0,4)
            sLayout.SortOrder = Enum.SortOrder.LayoutOrder

            local targetPlayer = nil
            if type(playerInput) == "string" then
                if string.lower(playerInput) == "localplayer" or string.lower(playerInput) == "local" then
                    targetPlayer = Players.LocalPlayer
                else
                    targetPlayer = Players:FindFirstChild(playerInput) or Players.LocalPlayer
                end
            elseif typeof(playerInput) == "Instance" and playerInput:IsA("Player") then
                targetPlayer = playerInput
            else
                targetPlayer = Players.LocalPlayer
            end

            local function UpdateAvatar()
                if customImg and customImg ~= "" then
                    AvatarImg.Image = ResolveImageAsset(customImg)
                    RealPlayerName.Text = type(playerInput) == "string" and playerInput or (targetPlayer and targetPlayer.Name or "Player")
                    return
                end
                if targetPlayer then
                    RealPlayerName.Text = targetPlayer.Name.." ("..targetPlayer.DisplayName..")"
                    local ok, thumb = pcall(function()
                        return Players:GetUserThumbnailAsync(targetPlayer.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size100x100)
                    end)
                    if ok and thumb then
                        AvatarImg.Image = thumb
                    end
                end
            end
            UpdateAvatar()

            local statLabels = {}

            local function CreateSingleStatRow(statCfg, idx)
                local cfg = statCfg
                local row = Instance.new("Frame", StatsContainer)
                row.Size = UDim2.new(1,0,0,28)
                row.AutomaticSize = Enum.AutomaticSize.Y
                row.BackgroundColor3 = CurrentTheme.ElementBg2
                row.BackgroundTransparency = 0.2
                Corner(row, 8)
                RegisterThemable(Stroke(row, CurrentTheme.Stroke, 1), "Stroke", "Stroke")
                RegisterThemable(row, "BackgroundColor3", "ElementBg2")

                local left = Instance.new("TextLabel", row)
                left.Size = UDim2.new(0.35,-8,0,0)
                left.AutomaticSize = Enum.AutomaticSize.Y
                left.Position = UDim2.new(0,8,0,4)
                left.BackgroundTransparency = 1
                left.Text = cfg.Name or cfg.Title or ("Stat "..idx)
                left.Font = Enum.Font.GothamMedium
                left.TextSize = 12
                left.TextColor3 = CurrentTheme.Text
                left.TextXAlignment = Enum.TextXAlignment.Left
                left.TextWrapped = true
                left.AutoLocalize = true
                RegisterThemable(left, "TextColor3", "Text")

                local right = Instance.new("TextLabel", row)
                right.Size = UDim2.new(0.65,-12,0,0)
                right.AutomaticSize = Enum.AutomaticSize.Y
                right.Position = UDim2.new(0.35,4,0,4)
                right.BackgroundTransparency = 1
                right.Text = tostring(cfg.Value ~= nil and cfg.Value or cfg.Default or "0")
                right.Font = Enum.Font.GothamBold
                right.TextSize = 12
                right.TextColor3 = CurrentTheme.ParagraphText
                right.TextXAlignment = Enum.TextXAlignment.Right
                right.TextWrapped = true
                right.TextYAlignment = Enum.TextYAlignment.Top
                right.AutoLocalize = false
                RegisterThemable(right, "TextColor3", "ParagraphText")

                local pad = Instance.new("UIPadding", row)
                pad.PaddingBottom = UDim.new(0,6)
                pad.PaddingTop = UDim.new(0,6)

                return {row=row, valueLabel=right, nameLabel=left, cfg=cfg}
            end

            for i, sCfg in ipairs(statsList) do
                local obj = CreateSingleStatRow(sCfg, i)
                table.insert(statLabels, obj)
            end

            local function FetchRawValue(rawUrl, keyPath)
                if not rawUrl or rawUrl == "" then return nil end
                local ok, result = pcall(function()
                    return game:HttpGet(rawUrl)
                end)
                if not ok then return nil end
                local ok2, json = pcall(function() return HttpService:JSONDecode(result) end)
                if ok2 and type(json) == "table" then
                    if keyPath and keyPath ~= "" then
                        local cur = json
                        for k in string.gmatch(keyPath, "[^%.]+") do
                            if type(cur) == "table" then cur = cur[k] else cur = nil break end
                        end
                        return cur
                    else
                        return json
                    end
                else
                    return result
                end
            end

            local function UpdateAllStats()
                for _, item in ipairs(statLabels) do
                    local c = item.cfg
                    local newVal = nil
                    if c.Value ~= nil and (c.Path == nil and c.Raw == nil and c.RawUrl == nil and c.Link == nil) then
                        newVal = c.Value
                    end
                    if c.Path and c.Path ~= "" then
                        local inst = GetInstanceByPath(c.Path)
                        newVal = ExtractValueFromInstance(inst)
                    end
                    if c.Raw or c.RawUrl or c.Link or c.Url then
                        local url = c.Raw or c.RawUrl or c.Link or c.Url
                        local key = c.Key or c.JsonKey or c.PathKey or ""
                        if IsUrlImage(url) or tostring(url):match("^https?://") then
                            local fetched = FetchRawValue(url, key)
                            if fetched ~= nil then newVal = fetched end
                        end
                    end
                    if newVal ~= nil then
                        item.valueLabel.Text = tostring(newVal)
                    end
                end
            end

            UpdateAllStats()

            if autoUpdate then
                task.spawn(function()
                    while Frame.Parent do
                        task.wait(updateInterval)
                        pcall(UpdateAllStats)
                    end
                end)
            end

            local API = {}
            function API:SetStat(nameOrIndex, value)
                for _, it in ipairs(statLabels) do
                    if type(nameOrIndex) == "number" then
                        if _ == nameOrIndex then
                            it.cfg.Value = value
                            it.valueLabel.Text = tostring(value)
                        end
                    else
                        if string.lower(it.cfg.Name or "") == string.lower(tostring(nameOrIndex)) then
                            it.cfg.Value = value
                            it.valueLabel.Text = tostring(value)
                        end
                    end
                end
                return API
            end
            function API:GetStat(nameOrIndex)
                for idx, it in ipairs(statLabels) do
                    if type(nameOrIndex) == "number" and idx == nameOrIndex then
                        return it.valueLabel.Text
                    elseif string.lower(it.cfg.Name or "") == string.lower(tostring(nameOrIndex)) then
                        return it.valueLabel.Text
                    end
                end
                return nil
            end
            function API:AddStat(newCfg)
                local obj = CreateSingleStatRow(newCfg, #statLabels+1)
                table.insert(statLabels, obj)
                StatsContainer.Size = UDim2.new(1,-12,0, #statLabels * 32)
                Frame.Size = UDim2.new(1,-4,0, 78 + (#statLabels * 32) + 8)
                return API
            end
            function API:RemoveStat(nameOrIndex)
                for i=#statLabels,1,-1 do
                    local it = statLabels[i]
                    local match = false
                    if type(nameOrIndex) == "number" and i == nameOrIndex then match = true end
                    if type(nameOrIndex) == "string" and string.lower(it.cfg.Name or "") == string.lower(nameOrIndex) then match = true end
                    if match then
                        it.row:Destroy()
                        table.remove(statLabels, i)
                    end
                end
                StatsContainer.Size = UDim2.new(1,-12,0, #statLabels * 32)
                Frame.Size = UDim2.new(1,-4,0, 78 + (#statLabels * 32) + 8)
                return API
            end
            function API:Refresh(newCfg)
                if not newCfg then UpdateAllStats() return API end
                if newCfg.Stats then
                    for _, it in ipairs(statLabels) do it.row:Destroy() end
                    table.clear(statLabels)
                    for i, s in ipairs(newCfg.Stats) do
                        local obj = CreateSingleStatRow(s, i)
                        table.insert(statLabels, obj)
                    end
                    StatsContainer.Size = UDim2.new(1,-12,0, #statLabels * 32)
                end
                UpdateAllStats()
                return API
            end
            function API:Update() UpdateAllStats() return API end
            return API
        end

if true then
end

        local function CreateFloatingButton(Cfg)
            Cfg = Cfg or {}
            local title = Cfg.Title or Cfg.Name or "Button"
            local callback = Cfg.Callback or function() end
            local floatEnabledDefault = Cfg.FloatDefault or Cfg.ToggleDefault or false
            local floatDraggable = Cfg.FloatDraggable
            if floatDraggable == nil then floatDraggable = true end
            if Cfg.Draggable ~= nil then floatDraggable = Cfg.Draggable end
            local floatText = Cfg.FloatText or Cfg.FloatName or title
            local floatImage = Cfg.FloatImage or Cfg.FloatIcon or Cfg.Image or nil
            local floatPosCfg = Cfg.FloatPosition or Cfg.Position or "Center"
            local floatSize = Cfg.FloatSize or Cfg.Size or Cfg.ButtonSize or Vector2.new(50,50)
            if type(floatSize) == "number" then
                floatSize = Vector2.new(floatSize, floatSize)
            elseif type(floatSize) == "table" then
                floatSize = Vector2.new(tonumber(floatSize[1] or floatSize.W or floatSize.Width) or 50, tonumber(floatSize[2] or floatSize.H or floatSize.Height) or 50)
            elseif typeof(floatSize) == "UDim2" then
                floatSize = Vector2.new(floatSize.X.Offset, floatSize.Y.Offset)
            elseif typeof(floatSize) ~= "Vector2" then
                floatSize = Vector2.new(50,50)
            end
            if Cfg.FloatWidth or Cfg.Width then floatSize = Vector2.new(tonumber(Cfg.FloatWidth or Cfg.Width) or floatSize.X, floatSize.Y) end
            if Cfg.FloatHeight or Cfg.Height then floatSize = Vector2.new(floatSize.X, tonumber(Cfg.FloatHeight or Cfg.Height) or floatSize.Y) end
            floatSize = Vector2.new(math.clamp(math.floor(floatSize.X + 0.5), 1, 500), math.clamp(math.floor(floatSize.Y + 0.5), 1, 500))
            local allowSizeControl = true
            do
                local a = Cfg.AllowSizeControl
                if a == nil then a = Cfg.UserSize end
                if a == nil then a = Cfg.SizeControl end
                if a == nil then a = Cfg.AllowResize end
                if a ~= nil then allowSizeControl = (a == true) end
            end
            local SIZE_ROW_END = allowSizeControl and 114 or 76
            local floatLocked = (Cfg.FloatLocked or Cfg.Locked) == true
            local floatTrans = tonumber(Cfg.FloatTransparency or Cfg.FloatTrans) or 0
            if floatTrans > 1 then floatTrans = floatTrans / 100 end
            floatTrans = math.clamp(floatTrans, 0, 0.9)
            local savedFloatPos = nil
            local floatKey = nil
            do
                local k = Cfg.Keybind or Cfg.Key or Cfg.FloatKey or Cfg.Bind
                if type(k) == "string" then
                    local ok, kc = pcall(function() return Enum.KeyCode[k] end)
                    k = ok and kc or nil
                end
                if typeof(k) == "EnumItem" then floatKey = k end
            end

            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0,76)
            Frame.BackgroundColor3 = CurrentTheme.ElementBg
            Corner(Frame, 10)
            RegisterThemable(Frame, "BackgroundColor3", "ElementBg")
            RegisterThemable(SoftStroke(Frame, CurrentTheme.Stroke), "Stroke", "Stroke")
            AddSearch(Frame, title, "FloatingButton", Name)

            local TitleLabel = Instance.new("TextLabel", Frame)
            TitleLabel.Size = UDim2.new(1,-100,0,38)
            TitleLabel.Position = UDim2.new(0,10,0,0)
            TitleLabel.BackgroundTransparency = 1
            TitleLabel.Text = title
            TitleLabel.Font = Enum.Font.GothamMedium
            TitleLabel.TextSize = 12
            TitleLabel.TextColor3 = CurrentTheme.Text
            TitleLabel.TextXAlignment = Enum.TextXAlignment.Left
            TitleLabel.AutoLocalize = true
            RegisterThemable(TitleLabel, "TextColor3", "Text")

            local ToggleBg = Instance.new("Frame", Frame)
            ToggleBg.Size = UDim2.new(0,38,0,20)
            ToggleBg.Position = UDim2.new(1,-88,0,9)
            ToggleBg.BackgroundColor3 = floatEnabledDefault and CurrentTheme.Accent or CurrentTheme.ElementBg2
            Corner(ToggleBg, 10)

            local ToggleCircle = Instance.new("Frame", ToggleBg)
            ToggleCircle.Size = UDim2.new(0,14,0,14)
            ToggleCircle.Position = floatEnabledDefault and UDim2.new(1,-17,0.5,-7) or UDim2.new(0,3,0.5,-7)
            ToggleCircle.BackgroundColor3 = Color3.fromRGB(255,255,255)
            Corner(ToggleCircle, 7)

            local ToggleBtn = Instance.new("TextButton", Frame)
            ToggleBtn.Size = UDim2.new(0,38,0,20)
            ToggleBtn.Position = ToggleBg.Position
            ToggleBtn.BackgroundTransparency = 1
            ToggleBtn.Text = ""

            local MainBtn = Instance.new("TextButton", Frame)
            MainBtn.Size = UDim2.new(0,44,0,24)
            MainBtn.Position = UDim2.new(1,-42,0,7)
            MainBtn.BackgroundColor3 = CurrentTheme.ElementBg2
            MainBtn.Text = ""
            MainBtn.AutoButtonColor = false
            Corner(MainBtn, 7)
            Stroke(MainBtn, CurrentTheme.StrokeLight, 1)
            local PlayIcon = MakeIcon(MainBtn, "play", 14, CurrentTheme.Text)
            PlayIcon.AnchorPoint = Vector2.new(0.5, 0.5)
            PlayIcon.Position = UDim2.fromScale(0.5, 0.5)

            local RowLine = Instance.new("Frame", Frame)
            RowLine.Size = UDim2.new(1,-20,0,1)
            RowLine.Position = UDim2.new(0,10,0,38)
            RowLine.BackgroundColor3 = CurrentTheme.Stroke
            RowLine.BackgroundTransparency = 0.6
            RowLine.BorderSizePixel = 0
            RegisterThemable(RowLine, "BackgroundColor3", "Stroke")

            local LockBtn = Instance.new("TextButton", Frame)
            LockBtn.Name = "LockBtn"
            LockBtn.Size = UDim2.new(0,34,0,28)
            LockBtn.Position = UDim2.new(0,10,0,42)
            LockBtn.BackgroundColor3 = CurrentTheme.ElementBg2
            LockBtn.Text = ""
            LockBtn.AutoButtonColor = false
            Corner(LockBtn, 8)
            Stroke(LockBtn, CurrentTheme.StrokeLight, 1)
            local LockIcon = MakeIcon(LockBtn, "lock-open", 16, CurrentTheme.Text)
            LockIcon.AnchorPoint = Vector2.new(0.5, 0.5)
            LockIcon.Position = UDim2.fromScale(0.5, 0.5)

            local TransCaption = Instance.new("TextLabel", Frame)
            TransCaption.Size = UDim2.new(1,-126,0,28)
            TransCaption.Position = UDim2.new(0,52,0,42)
            TransCaption.BackgroundTransparency = 1
            TransCaption.Text = "Transparency %"
            TransCaption.Font = Enum.Font.GothamMedium
            TransCaption.TextSize = 10
            TransCaption.TextColor3 = CurrentTheme.SubText
            TransCaption.TextXAlignment = Enum.TextXAlignment.Left
            TransCaption.TextTruncate = Enum.TextTruncate.AtEnd
            TransCaption.AutoLocalize = true
            RegisterThemable(TransCaption, "TextColor3", "SubText")

            local TransBox = Instance.new("TextBox", Frame)
            TransBox.Name = "TransBox"
            TransBox.Size = UDim2.new(0,48,0,28)
            TransBox.Position = UDim2.new(1,-58,0,42)
            TransBox.BackgroundColor3 = CurrentTheme.ElementBg2
            TransBox.Text = tostring(math.floor(floatTrans * 100 + 0.5))
            TransBox.PlaceholderText = "0-90"
            TransBox.Font = Enum.Font.GothamMedium
            TransBox.TextSize = 11
            TransBox.TextColor3 = CurrentTheme.Text
            TransBox.PlaceholderColor3 = CurrentTheme.SubText
            TransBox.ClearTextOnFocus = false
            Corner(TransBox, 8)
            Stroke(TransBox, CurrentTheme.StrokeLight, 1)
            RegisterThemable(TransBox, "BackgroundColor3", "ElementBg2")
            RegisterThemable(TransBox, "TextColor3", "Text")

            local SizeLine = Instance.new("Frame", Frame)
            SizeLine.Size = UDim2.new(1,-20,0,1)
            SizeLine.Position = UDim2.new(0,10,0,76)
            SizeLine.BackgroundColor3 = CurrentTheme.Stroke
            SizeLine.BackgroundTransparency = 0.6
            SizeLine.BorderSizePixel = 0
            RegisterThemable(SizeLine, "BackgroundColor3", "Stroke")

            local SizeCaption = Instance.new("TextLabel", Frame)
            SizeCaption.Size = UDim2.new(1,-130,0,28)
            SizeCaption.Position = UDim2.new(0,10,0,80)
            SizeCaption.BackgroundTransparency = 1
            SizeCaption.Text = "Size  W / H  (1-100)"
            SizeCaption.Font = Enum.Font.GothamMedium
            SizeCaption.TextSize = 10
            SizeCaption.TextColor3 = CurrentTheme.SubText
            SizeCaption.TextXAlignment = Enum.TextXAlignment.Left
            SizeCaption.TextTruncate = Enum.TextTruncate.AtEnd
            SizeCaption.AutoLocalize = true
            RegisterThemable(SizeCaption, "TextColor3", "SubText")

            local function MakeSizeBox(name, xOff, val)
                local b = Instance.new("TextBox", Frame)
                b.Name = name
                b.Size = UDim2.new(0,50,0,28)
                b.Position = UDim2.new(1,xOff,0,80)
                b.BackgroundColor3 = CurrentTheme.ElementBg2
                b.Text = tostring(val)
                b.PlaceholderText = "1-100"
                b.Font = Enum.Font.GothamMedium
                b.TextSize = 11
                b.TextColor3 = CurrentTheme.Text
                b.PlaceholderColor3 = CurrentTheme.SubText
                b.ClearTextOnFocus = false
                Corner(b, 8)
                Stroke(b, CurrentTheme.StrokeLight, 1)
                RegisterThemable(b, "BackgroundColor3", "ElementBg2")
                RegisterThemable(b, "TextColor3", "Text")
                return b
            end
            local WBox = MakeSizeBox("WBox", -116, floatSize.X)
            local HBox = MakeSizeBox("HBox", -62, floatSize.Y)

            if not allowSizeControl then
                SizeLine.Visible = false
                SizeCaption.Visible = false
                WBox.Visible = false
                HBox.Visible = false
            end

            local KeyLine = Instance.new("Frame", Frame)
            KeyLine.Size = UDim2.new(1,-20,0,1)
            KeyLine.Position = UDim2.new(0,10,0,SIZE_ROW_END)
            KeyLine.BackgroundColor3 = CurrentTheme.Stroke
            KeyLine.BackgroundTransparency = 0.6
            KeyLine.BorderSizePixel = 0
            RegisterThemable(KeyLine, "BackgroundColor3", "Stroke")

            local KeyCaption = Instance.new("TextLabel", Frame)
            KeyCaption.Size = UDim2.new(1,-130,0,28)
            KeyCaption.Position = UDim2.new(0,10,0,SIZE_ROW_END + 4)
            KeyCaption.BackgroundTransparency = 1
            KeyCaption.Text = "Keybind (works when ON)"
            KeyCaption.Font = Enum.Font.GothamMedium
            KeyCaption.TextSize = 10
            KeyCaption.TextColor3 = CurrentTheme.SubText
            KeyCaption.TextXAlignment = Enum.TextXAlignment.Left
            KeyCaption.TextTruncate = Enum.TextTruncate.AtEnd
            KeyCaption.AutoLocalize = true
            RegisterThemable(KeyCaption, "TextColor3", "SubText")

            local KeyBtn = Instance.new("TextButton", Frame)
            KeyBtn.Name = "KeyBtn"
            KeyBtn.Size = UDim2.new(0,108,0,28)
            KeyBtn.Position = UDim2.new(1,-118,0,SIZE_ROW_END + 4)
            KeyBtn.BackgroundColor3 = CurrentTheme.ElementBg2
            KeyBtn.Text = floatKey and floatKey.Name or "None"
            KeyBtn.Font = Enum.Font.GothamBold
            KeyBtn.TextSize = 11
            KeyBtn.TextColor3 = CurrentTheme.Text
            KeyBtn.TextTruncate = Enum.TextTruncate.AtEnd
            KeyBtn.AutoButtonColor = false
            Corner(KeyBtn, 8)
            Stroke(KeyBtn, CurrentTheme.StrokeLight, 1)
            RegisterThemable(KeyBtn, "BackgroundColor3", "ElementBg2")
            RegisterThemable(KeyBtn, "TextColor3", "Text")

            local function KeyRowAllowed()
                if Cfg.ShowKeybind == true then return true end
                if Cfg.ShowKeybind == false then return false end
                return UserInputService.KeyboardEnabled or UserInputService.GamepadEnabled
            end
            local function RefreshKeyRow()
                local show = KeyRowAllowed()
                KeyLine.Visible = show
                KeyCaption.Visible = show
                KeyBtn.Visible = show
                Frame.Size = UDim2.new(1,-4,0, show and (SIZE_ROW_END + 38) or SIZE_ROW_END)
            end
            RefreshKeyRow()
            local keyRowConn = TrackConnection(UserInputService.LastInputTypeChanged:Connect(function()
                if not Frame.Parent then return end
                RefreshKeyRow()
            end))

            local floatingInstance = nil
            local floatPressFn = nil
            local keyListening = false
            local floatStroke = nil
            local floatConns = {}
            local floatResources = nil
            local isFloatEnabled = floatEnabledDefault

            local function DisconnectFloat()
                for _, c in ipairs(floatConns) do pcall(function() c:Disconnect() end) end
                floatConns = {}
                if floatResources then
                    floatResources:Destroy()
                    floatResources = nil
                end
            end

            local function GetViewport()
                local vp = ScreenGui.AbsoluteSize
                if vp.X < 10 then
                    vp = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize or Vector2.new(1920,1080)
                end
                return vp
            end

            local function ClampFloatPartial(pos, size)
                local vp = GetViewport()
                local minX = -size.X * 0.5
                local maxX = vp.X - size.X * 0.5
                local minY = -size.Y * 0.5
                local maxY = vp.Y - size.Y * 0.5
                local x = math.clamp(pos.X.Offset, minX, maxX)
                local y = math.clamp(pos.Y.Offset, minY, maxY)
                return UDim2.fromOffset(x, y)
            end

            local function ResolveFloatPosition()
                if typeof(floatPosCfg) == "UDim2" then
                    return floatPosCfg
                elseif type(floatPosCfg) == "string" then
                    local vp = GetViewport()
                    local p = string.lower(floatPosCfg)
                    if p == "center" or p == "middle" then
                        return UDim2.fromOffset(vp.X/2 - floatSize.X/2, vp.Y/2 - floatSize.Y/2)
                    elseif p == "top" then
                        return UDim2.fromOffset(vp.X/2 - floatSize.X/2, 20)
                    elseif p == "bottom" then
                        return UDim2.fromOffset(vp.X/2 - floatSize.X/2, vp.Y - floatSize.Y - 20)
                    elseif p == "topleft" then
                        return UDim2.fromOffset(20, 20)
                    elseif p == "topright" then
                        return UDim2.fromOffset(vp.X - floatSize.X - 20, 20)
                    else
                        return UDim2.fromOffset(vp.X/2 - floatSize.X/2, vp.Y/2 - floatSize.Y/2)
                    end
                else
                    local vp = GetViewport()
                    return UDim2.fromOffset(vp.X/2 - floatSize.X/2, vp.Y/2 - floatSize.Y/2)
                end
            end

            local function ApplyFloatLook()
                if not floatingInstance or not floatingInstance.Parent then return end
                floatingInstance.BackgroundTransparency = floatTrans
                if floatingInstance:IsA("ImageButton") then
                    floatingInstance.ImageTransparency = floatTrans
                else
                    floatingInstance.TextTransparency = floatTrans
                end
                if floatStroke then floatStroke.Transparency = 0.3 + (0.7 * floatTrans) end
                local sh = floatingInstance:FindFirstChild("Sheen")
                if sh then sh.BackgroundTransparency = 0.86 + (0.14 * floatTrans) end
            end

            local function RefreshLockVisual()
                local th = CurrentTheme
                LockBtn.BackgroundColor3 = floatLocked and th.Accent or th.ElementBg2
                LockIcon.Image = ResolveIcon(floatLocked and "lock" or "lock-open") or ""
                LockIcon.ImageColor3 = floatLocked and Color3.new(1,1,1) or th.Text
            end
            RefreshLockVisual()

            local function ParseTransText(txt)
                local n = tonumber((tostring(txt):gsub("[%%%s]", "")))
                if not n then return nil end
                return math.clamp(n, 0, 90) / 100
            end

            local function SetTransFromValue(v, updateBox)
                v = tonumber(v) or 0
                if v > 1 then v = v / 100 end
                floatTrans = math.clamp(v, 0, 0.9)
                if updateBox then TransBox.Text = tostring(math.floor(floatTrans * 100 + 0.5)) end
                ApplyFloatLook()
            end

            local function ApplyFloatSize(w, h, updateBoxes, maxV)
                maxV = maxV or 100
                w = math.clamp(math.floor((tonumber(w) or floatSize.X) + 0.5), 1, maxV)
                h = math.clamp(math.floor((tonumber(h) or floatSize.Y) + 0.5), 1, maxV)
                local oldS = floatSize
                floatSize = Vector2.new(w, h)
                if updateBoxes then
                    WBox.Text = tostring(w)
                    HBox.Text = tostring(h)
                end
                if floatingInstance and floatingInstance.Parent then
                    local p = floatingInstance.Position
                    local nx = p.X.Offset + (oldS.X - w) / 2
                    local ny = p.Y.Offset + (oldS.Y - h) / 2
                    floatingInstance.Size = UDim2.fromOffset(w, h)
                    floatingInstance.Position = ClampFloatPartial(UDim2.fromOffset(nx, ny), floatSize)
                    savedFloatPos = Vector2.new(floatingInstance.Position.X.Offset, floatingInstance.Position.Y.Offset)
                end
            end
            local function ParseSizeText(txt)
                local n = tonumber((tostring(txt):gsub("[%s%%px]", "")))
                if not n then return nil end
                return math.clamp(math.floor(n + 0.5), 1, 100)
            end
            WBox:GetPropertyChangedSignal("Text"):Connect(function()
                local n = ParseSizeText(WBox.Text)
                if n and n ~= floatSize.X then ApplyFloatSize(n, floatSize.Y, false) end
            end)
            HBox:GetPropertyChangedSignal("Text"):Connect(function()
                local n = ParseSizeText(HBox.Text)
                if n and n ~= floatSize.Y then ApplyFloatSize(floatSize.X, n, false) end
            end)
            WBox.FocusLost:Connect(function()
                WBox.Text = tostring(floatSize.X)
                SaveMgr.MarkDirty()
            end)
            HBox.FocusLost:Connect(function()
                HBox.Text = tostring(floatSize.Y)
                SaveMgr.MarkDirty()
            end)

            local floatDown = false
            local function FloatBaseColor() return CurrentTheme.Accent end
            local function FloatPressedColor()
                local th = CurrentTheme
                return th.Accent:Lerp(th.ElementBg2, 0.5)
            end
            local function ApplyFloatTheme(th)
                if not floatingInstance or not floatingInstance.Parent then return end
                floatingInstance.BackgroundColor3 = floatDown and FloatPressedColor() or th.Accent
                if floatStroke then floatStroke.Color = th.Accent:Lerp(Color3.new(1,1,1), 0.55) end
                if floatingInstance:IsA("TextButton") then floatingInstance.TextColor3 = ContrastColor(th.Accent) end
            end
            local function SetFloatPressed(state)
                if not floatingInstance or not floatingInstance.Parent then return end
                floatDown = state
                local sc = floatingInstance:FindFirstChild("PressScale")
                local sh = floatingInstance:FindFirstChild("Sheen")
                if state then
                    Tween(floatingInstance, {BackgroundColor3 = FloatPressedColor()}, 0.08)
                    if sc then TweenService:Create(sc, TweenInfo.new(0.09, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {Scale = 0.86}):Play() end
                    if floatStroke then Tween(floatStroke, {Thickness = 3}, 0.08) end
                    if sh then Tween(sh, {BackgroundTransparency = 1}, 0.08) end
                else
                    Tween(floatingInstance, {BackgroundColor3 = CurrentTheme.Accent}, 0.2)
                    if sc then TweenService:Create(sc, TweenInfo.new(0.28, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {Scale = 1}):Play() end
                    if floatStroke then Tween(floatStroke, {Thickness = 2}, 0.2) end
                    if sh then Tween(sh, {BackgroundTransparency = 0.86 + (0.14 * floatTrans)}, 0.2) end
                end
            end

            local function CreateFloat()
                DisconnectFloat()
                if floatingInstance then floatingInstance:Destroy() floatingInstance = nil end
                floatDown = false
                local btn
                if floatImage and floatImage ~= "" then
                    btn = Instance.new("ImageButton", ScreenGui)
                    btn.Image = ResolveImageAsset(floatImage)
                    btn.ScaleType = Enum.ScaleType.Crop
                else
                    btn = Instance.new("TextButton", ScreenGui)
                    btn.Text = floatText
                    btn.Font = Enum.Font.GothamBold
                    btn.TextSize = 12
                    btn.TextColor3 = ContrastColor(CurrentTheme.Accent)
                    btn.TextWrapped = true
                    btn.TextScaled = true
                    local tc = Instance.new("UITextSizeConstraint", btn)
                    tc.MaxTextSize = 15
                    tc.MinTextSize = 8
                    local tp = Instance.new("UIPadding", btn)
                    tp.PaddingLeft = UDim.new(0.12,0) tp.PaddingRight = UDim.new(0.12,0)
                    tp.PaddingTop = UDim.new(0.12,0) tp.PaddingBottom = UDim.new(0.12,0)
                end
                btn.Name = "GGH_Float_"..title
                local buttonResources = ConnectionBag.new()
                floatResources = buttonResources
                Viewport.Attach(ScreenGui, btn, buttonResources, "partial", 0)
                buttonResources:Connect(btn.Destroying, function()
                    buttonResources:Destroy()
                    if floatResources == buttonResources then
                        floatResources = nil
                    end
                end)
                btn.Size = UDim2.new(0, floatSize.X, 0, floatSize.Y)
                if savedFloatPos then
                    btn.Position = ClampFloatPartial(UDim2.fromOffset(savedFloatPos.X, savedFloatPos.Y), floatSize)
                else
                    btn.Position = ResolveFloatPosition()
                end
                btn.BackgroundColor3 = CurrentTheme.Accent
                btn.BorderSizePixel = 0
                btn.ZIndex = 199
                btn.AutoButtonColor = false
                btn.Active = true
                local cr = Instance.new("UICorner", btn)
                cr.CornerRadius = UDim.new(0.3, 0)
                local ps = Instance.new("UIScale", btn)
                ps.Name = "PressScale"
                local sheen = Instance.new("Frame", btn)
                sheen.Name = "Sheen"
                sheen.Size = UDim2.new(1,0,0.5,0)
                sheen.BackgroundColor3 = Color3.new(1,1,1)
                sheen.BackgroundTransparency = 0.86
                sheen.BorderSizePixel = 0
                sheen.ZIndex = 200
                sheen.Active = false
                local sc2 = Instance.new("UICorner", sheen)
                sc2.CornerRadius = UDim.new(0.6, 0)
                floatStroke = Instance.new("UIStroke", btn)
                floatStroke.Thickness = 2
                floatStroke.Color = CurrentTheme.Accent:Lerp(Color3.new(1,1,1), 0.55)
                floatStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
                floatingInstance = btn
                ApplyFloatLook()

                floatPressFn = function()
                    SetFloatPressed(true)
                    task.delay(0.14, function() SetFloatPressed(false) end)
                end

                local dragging = false
                local dragStart, startPos
                local hasDragged = false

                table.insert(floatConns, btn.InputBegan:Connect(function(input)
                    if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                        SetFloatPressed(true)
                    end
                    if floatDraggable and not floatLocked and (input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch) then
                        dragging = true
                        hasDragged = false
                        dragStart = input.Position
                        startPos = btn.Position
                    end
                end))
                table.insert(floatConns, buttonResources:Connect(UserInputService.InputChanged, function(input)
                    if dragging and floatDraggable and not floatLocked and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
                        local delta = input.Position - dragStart
                        if delta.Magnitude > 4 then hasDragged = true end
                        local newPos = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
                        btn.Position = ClampFloatPartial(newPos, floatSize)
                    end
                end))
                table.insert(floatConns, buttonResources:Connect(UserInputService.InputEnded, function(input)
                    if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                        if floatDown then SetFloatPressed(false) end
                        if dragging and hasDragged and btn.Parent then
                            savedFloatPos = Vector2.new(btn.Position.X.Offset, btn.Position.Y.Offset)
                            SaveMgr.MarkDirty()
                        end
                        dragging = false
                        task.wait(0.05)
                        hasDragged = false
                    end
                end))

                table.insert(floatConns, btn.MouseButton1Click:Connect(function()
                    if hasDragged then return end
                    pcall(callback)
                end))

                return btn
            end

            local function RemoveFloat()
                DisconnectFloat()
                if floatingInstance then
                    floatingInstance:Destroy()
                    floatingInstance = nil
                end
                floatStroke = nil
                floatPressFn = nil
                floatDown = false
            end

            local function SetToggleState(state)
                isFloatEnabled = state
                if state then
                    Tween(ToggleBg, {BackgroundColor3 = CurrentTheme.Accent}, 0.15)
                    Tween(ToggleCircle, {Position = UDim2.new(1,-17,0.5,-7)}, 0.15)
                    CreateFloat()
                else
                    Tween(ToggleBg, {BackgroundColor3 = CurrentTheme.ElementBg2}, 0.15)
                    Tween(ToggleCircle, {Position = UDim2.new(0,3,0.5,-7)}, 0.15)
                    RemoveFloat()
                end
            end

            local function SetFloatKey(k)
                floatKey = k
                KeyBtn.Text = k and k.Name or "None"
            end
            KeyBtn.MouseButton1Click:Connect(function()
                if IsScrolling or keyListening then return end
                keyListening = true
                KeyBtn.Text = "..."
                Tween(KeyBtn, {BackgroundColor3 = CurrentTheme.Accent}, 0.15)
                local conn
                local function finish()
                    keyListening = false
                    if conn then conn:Disconnect() conn = nil end
                    KeyBtn.Text = floatKey and floatKey.Name or "None"
                    Tween(KeyBtn, {BackgroundColor3 = CurrentTheme.ElementBg2}, 0.15)
                end
                conn = TrackConnection(UserInputService.InputBegan:Connect(function(input)
                    local ut = input.UserInputType
                    local isPad = string.find(ut.Name, "^Gamepad") ~= nil
                    if ut ~= Enum.UserInputType.Keyboard and not isPad then return end
                    local kc = input.KeyCode
                    if kc == Enum.KeyCode.Unknown or kc == Enum.KeyCode.Thumbstick1 or kc == Enum.KeyCode.Thumbstick2 then return end
                    if kc == Enum.KeyCode.Escape or kc == Enum.KeyCode.Backspace then
                        floatKey = nil
                    else
                        floatKey = kc
                    end
                    finish()
                    SaveMgr.MarkDirty()
                end))
                task.delay(8, function() if keyListening then finish() end end)
            end)
            local keyTrigConn
            keyTrigConn = TrackConnection(UserInputService.InputBegan:Connect(function(input)
                if not Frame.Parent then
                    if keyTrigConn then keyTrigConn:Disconnect() end
                    if keyRowConn then keyRowConn:Disconnect() end
                    return
                end
                if keyListening or not floatKey or not isFloatEnabled then return end
                if UserInputService:GetFocusedTextBox() then return end
                if input.KeyCode == floatKey then
                    if floatPressFn then floatPressFn() end
                    pcall(callback)
                end
            end))

            ToggleBtn.MouseButton1Click:Connect(function()
                if IsScrolling then return end
                SetToggleState(not isFloatEnabled)
                SaveMgr.MarkDirty()
            end)

            MainBtn.MouseButton1Click:Connect(function()
                if IsScrolling then return end
                Tween(MainBtn, {BackgroundColor3 = CurrentTheme.ElementBg}, 0.08)
                task.wait(0.08)
                Tween(MainBtn, {BackgroundColor3 = CurrentTheme.ElementBg2}, 0.08)
                pcall(callback)
            end)

            LockBtn.MouseButton1Click:Connect(function()
                if IsScrolling then return end
                floatLocked = not floatLocked
                RefreshLockVisual()
                SaveMgr.MarkDirty()
            end)

            TransBox:GetPropertyChangedSignal("Text"):Connect(function()
                local n = ParseTransText(TransBox.Text)
                if n then
                    floatTrans = n
                    ApplyFloatLook()
                end
            end)
            TransBox.FocusLost:Connect(function()
                local n = ParseTransText(TransBox.Text)
                if n then floatTrans = n end
                TransBox.Text = tostring(math.floor(floatTrans * 100 + 0.5))
                ApplyFloatLook()
                SaveMgr.MarkDirty()
            end)

            table.insert(ThemeListeners, function(th)
                if not Frame.Parent then return end
                ToggleBg.BackgroundColor3 = isFloatEnabled and th.Accent or th.ElementBg2
                MainBtn.BackgroundColor3 = th.ElementBg2
                PlayIcon.ImageColor3 = th.Text
                TransBox.PlaceholderColor3 = th.SubText
                RefreshLockVisual()
                KeyBtn.BackgroundColor3 = keyListening and th.Accent or th.ElementBg2
                KeyBtn.TextColor3 = th.Text
                WBox.PlaceholderColor3 = th.SubText
                HBox.PlaceholderColor3 = th.SubText
                ApplyFloatTheme(th)
            end)

            if isFloatEnabled then
                task.spawn(function()
                    task.wait(0.2)
                    if isFloatEnabled and not floatingInstance then CreateFloat() end
                end)
            end

            local function GetState()
                local px, py
                if floatingInstance and floatingInstance.Parent then
                    px, py = floatingInstance.Position.X.Offset, floatingInstance.Position.Y.Offset
                elseif savedFloatPos then
                    px, py = savedFloatPos.X, savedFloatPos.Y
                end
                return {on = isFloatEnabled, locked = floatLocked, trans = floatTrans, x = px, y = py, key = floatKey and floatKey.Name or "", w = floatSize.X, h = floatSize.Y}
            end

            local function SetState(s)
                if type(s) ~= "table" then return end
                if type(s.locked) == "boolean" then
                    floatLocked = s.locked
                    RefreshLockVisual()
                end
                if type(s.trans) == "number" then SetTransFromValue(s.trans, true) end
                if allowSizeControl and (type(s.w) == "number" or type(s.h) == "number") then
                    ApplyFloatSize(s.w, s.h, true)
                end
                if type(s.key) == "string" then
                    if s.key == "" then SetFloatKey(nil)
                    else
                        local ok, kc = pcall(function() return Enum.KeyCode[s.key] end)
                        if ok and kc then SetFloatKey(kc) end
                    end
                end
                if type(s.x) == "number" and type(s.y) == "number" then
                    savedFloatPos = Vector2.new(s.x, s.y)
                end
                if type(s.on) == "boolean" then SetToggleState(s.on) end
            end

            local API = {}
            function API:SetValue(v) SetToggleState(v) return API end
            function API:GetValue() return isFloatEnabled end
            function API:SetTitle(t) TitleLabel.Text = t return API end
            function API:Fire() pcall(callback) return API end
            function API:SetLocked(v)
                floatLocked = v and true or false
                RefreshLockVisual()
                SaveMgr.MarkDirty()
                return API
            end
            function API:GetLocked() return floatLocked end
            function API:SetKeybind(k)
                if type(k) == "string" then
                    local ok, kc = pcall(function() return Enum.KeyCode[k] end)
                    k = ok and kc or nil
                end
                SetFloatKey(typeof(k) == "EnumItem" and k or nil)
                SaveMgr.MarkDirty()
                return API
            end
            function API:GetKeybind() return floatKey end
            function API:SetSize(w, h)
                if typeof(w) == "Vector2" then w, h = w.X, w.Y end
                ApplyFloatSize(w, h or w, true, 500)
                SaveMgr.MarkDirty()
                return API
            end
            function API:GetSize() return floatSize end
            function API:SetSizeControl(v)
                allowSizeControl = v and true or false
                SizeLine.Visible = allowSizeControl
                SizeCaption.Visible = allowSizeControl
                WBox.Visible = allowSizeControl
                HBox.Visible = allowSizeControl
                SIZE_ROW_END = allowSizeControl and 114 or 76
                KeyLine.Position = UDim2.new(0,10,0,SIZE_ROW_END)
                KeyCaption.Position = UDim2.new(0,10,0,SIZE_ROW_END + 4)
                KeyBtn.Position = UDim2.new(1,-118,0,SIZE_ROW_END + 4)
                RefreshKeyRow()
                return API
            end
            function API:SetTransparency(v)
                SetTransFromValue(v, true)
                SaveMgr.MarkDirty()
                return API
            end
            function API:GetTransparency() return floatTrans end
            function API:GetState() return GetState() end
            function API:SetState(s) SetState(s) return API end
            function API:Destroy()
                RemoveFloat()
                Frame:Destroy()
            end
            function API:Refresh(newCfg)
                if not newCfg then return API end
                if newCfg.Title then TitleLabel.Text = newCfg.Title end
                if newCfg.Callback then callback = newCfg.Callback end
                if newCfg.FloatText then floatText = newCfg.FloatText if floatingInstance and floatingInstance:IsA("TextButton") then floatingInstance.Text = floatText end end
                if newCfg.FloatImage and floatingInstance and floatingInstance:IsA("ImageButton") then floatingInstance.Image = ResolveImageAsset(newCfg.FloatImage) end
                return API
            end
            return API
        end

        local function CreateSliderWithInput(Cfg)
            NormalizeSliderConfig(Cfg, Cfg.Float and 2 or 0, "SliderInput")
            local isFloat = Cfg.Float or Cfg.Decimals > 0 or Cfg.AllowDecimals or Cfg.Precision ~= nil
            local function FormatVal(v)
                if isFloat or Cfg.Decimals > 0 then
                    local dec = Cfg.Decimals
                    if dec == 0 and isFloat then dec = 2 end
                    return string.format("%."..tostring(dec).."f", v)
                else
                    return tostring(math.floor(v*100)/100):gsub("%.0+$","")
                end
            end
            local function SnapValue(v)
                if Cfg.Increment and Cfg.Increment > 0 then
                    v = math.floor((v / Cfg.Increment)+0.5) * Cfg.Increment
                    v = tonumber(string.format("%."..tostring(Cfg.Decimals+4).."f", v))
                end
                return v
            end
            local Value = math.clamp(Cfg.Default, Cfg.Min, Cfg.Max)
            Value = SnapValue(Value)
            local function RelOf(v)
                local range = Cfg.Max - Cfg.Min
                if range <= 0 then return 0 end
                return math.clamp((v - Cfg.Min) / range, 0, 1)
            end

            local Frame = Instance.new("Frame", TabPage)
            Frame.Size = UDim2.new(1,-4,0,58)
            Frame.BackgroundColor3 = CurrentTheme.ElementBg
            Corner(Frame, 10)
            RegisterThemable(Frame, "BackgroundColor3", "ElementBg")
            RegisterThemable(SoftStroke(Frame, CurrentTheme.Stroke), "Stroke", "Stroke")
            AddSearch(Frame, Cfg.Title, "SliderInput", Name)

            local TitleLabel = Instance.new("TextLabel", Frame)
            TitleLabel.Size = UDim2.new(1,-90,0,18)
            TitleLabel.Position = UDim2.new(0,10,0,6)
            TitleLabel.BackgroundTransparency = 1
            TitleLabel.TextXAlignment = Enum.TextXAlignment.Left
            TitleLabel.Font = Enum.Font.GothamMedium
            TitleLabel.TextSize = 12
            TitleLabel.TextColor3 = CurrentTheme.Text
            TitleLabel.Text = Cfg.Title or "Slider"
            TitleLabel.AutoLocalize = true
            RegisterThemable(TitleLabel, "TextColor3", "Text")

            local NumberBox = Instance.new("TextBox", Frame)
            NumberBox.Size = UDim2.new(0,70,0,20)
            NumberBox.Position = UDim2.new(1,-80,0,5)
            NumberBox.BackgroundColor3 = CurrentTheme.ElementBg2
            NumberBox.Text = FormatVal(Value)
            NumberBox.Font = Enum.Font.Gotham
            NumberBox.TextSize = 12
            NumberBox.TextColor3 = CurrentTheme.Text
            NumberBox.PlaceholderColor3 = CurrentTheme.SubText
            NumberBox.ClearTextOnFocus = false
            Corner(NumberBox, 6)
            RegisterThemable(Stroke(NumberBox, CurrentTheme.Stroke, 1), "Stroke", "Stroke")
            RegisterThemable(NumberBox, "BackgroundColor3", "ElementBg2")

            local Bar = Instance.new("Frame", Frame)
            Bar.Size = UDim2.new(1,-90,0,8)
            Bar.Position = UDim2.new(0,10,0,32)
            Bar.BackgroundColor3 = CurrentTheme.ElementBg2
            Corner(Bar, 4)
            RegisterThemable(Bar, "BackgroundColor3", "ElementBg2")

            local Fill = Instance.new("Frame", Bar)
            Fill.Size = UDim2.new(RelOf(Value),0,1,0)
            Fill.BackgroundColor3 = CurrentTheme.Accent
            Corner(Fill, 4)
            RegisterThemable(Fill, "BackgroundColor3", "Accent")

            local Circle = Instance.new("Frame", Bar)
            Circle.Size = UDim2.new(0,16,0,16)
            Circle.AnchorPoint = Vector2.new(0.5,0.5)
            Circle.Position = UDim2.new(RelOf(Value), 0, 0.5, 0)
            Circle.BackgroundColor3 = Color3.fromRGB(255,255,255)
            Circle.ZIndex = 10
            Corner(Circle, 8)
            local S = Stroke(Circle, CurrentTheme.Accent, 2)
            RegisterThemable(S, "Stroke", "Accent")

            local dragging = false

            local function UpdateVisuals(newVal, tween)
                newVal = SnapValue(math.clamp(newVal, Cfg.Min, Cfg.Max))
                Value = newVal
                local rel = RelOf(Value)
                if tween then
                    Tween(Fill, {Size = UDim2.new(rel,0,1,0)}, 0.15)
                    Tween(Circle, {Position = UDim2.new(rel, 0, 0.5, 0)}, 0.15)
                else
                    Fill.Size = UDim2.new(rel,0,1,0)
                    Circle.Position = UDim2.new(rel, 0, 0.5, 0)
                end
                NumberBox.Text = FormatVal(Value)
                TitleLabel.Text = (Cfg.Title or "Slider").." : "..FormatVal(Value)
                pcall(Cfg.Callback or function() end, Value)
            end

            local function UpdateFromInputPos(inputX)
                local barPos = Bar.AbsolutePosition.X
                local barSize = Bar.AbsoluteSize.X
                if barSize <= 0 then barSize = 200 end
                local rel = math.clamp((inputX - barPos)/barSize, 0, 1)
                local newVal = Cfg.Min + (Cfg.Max - Cfg.Min)*rel
                newVal = SnapValue(newVal)
                UpdateVisuals(newVal, false)
            end

            local DragArea = Instance.new("TextButton", Bar)
            DragArea.Size = UDim2.new(1,0,2.5,0)
            DragArea.Position = UDim2.new(0,0,0.5,-10)
            DragArea.BackgroundTransparency = 1
            DragArea.Text = ""

            DragArea.InputBegan:Connect(function(input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                    dragging = true
                    UpdateFromInputPos(input.Position.X)
                end
            end)
            Circle.InputBegan:Connect(function(input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                    dragging = true
                end
            end)
            TrackConnection(UserInputService.InputChanged:Connect(function(input)
                if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
                    UpdateFromInputPos(input.Position.X)
                end
            end))
            TrackConnection(UserInputService.InputEnded:Connect(function(input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                    dragging = false
                end
            end))

            NumberBox.FocusLost:Connect(function(enter)
                if enter then
                    local num = tonumber(NumberBox.Text)
                    if num then
                        UpdateVisuals(num, true)
                    else
                        NumberBox.Text = FormatVal(Value)
                    end
                end
            end)

            local API = {}
            function API:SetValue(v) UpdateVisuals(v, true) return API end
            function API:GetValue() return Value end
            function API:Refresh(newCfg)
                if newCfg then
                    if newCfg.Min then Cfg.Min = newCfg.Min end
                    if newCfg.Max then Cfg.Max = newCfg.Max end
                    if newCfg.Title then Cfg.Title = newCfg.Title end
                    if newCfg.Default then UpdateVisuals(newCfg.Default, true) end
                end
                return API
            end
            return API
        end

        local Elements = ElementRegistry.new({
            TabName = Name,
            SaveManager = SaveMgr,
        }, {
            Section = CreateSection,
            Paragraph = CreateParagraph,
            Button = CreateButton,
            Toggle = CreateToggle,
            Slider = CreateSlider,
            Input = CreateInput,
            Dropdown = CreateDropdown,
            Colorpicker = CreateColorpicker,
            Keybind = CreateKeybind,
            Code = CreateCode,
            Label = CreateLabel,
            Separator = CreateSeparator,
            Image = CreateImage,
            LinkButton = CreateLinkButton,
            PlayerStats = CreatePlayerStats,
            FloatingButton = CreateFloatingButton,
            SliderInput = CreateSliderWithInput,
        })
        return Elements
    end
    function Window:AddTab(Cfg)
        Cfg = Cfg or {}
        local name = Cfg.Title or Cfg.Name or "Tab"
        return self:CreateTab(name, Cfg.Icon or Cfg.Image)
    end

function Window:SetSizePreset(presetName)
        if GGH.SizePresets and GGH.SizePresets[presetName] then
            local p = GGH.SizePresets[presetName]
            local newSize = UDim2.new(0, p.W, 0, p.H)
            savedSize = newSize
            baseSize = newSize
            Tween(Main, {Size = newSize}, 0.3)
        end
    end

    function Window:SetTransparency(winT, elemT)
        if winT then
            if winT>1 then winT=winT/100 end
            WindowAPI_Trans_W = math.clamp(winT,0,0.7)
            Main.BackgroundTransparency = WindowAPI_Trans_W
            Header.BackgroundTransparency = WindowAPI_Trans_W
            HeaderFix.BackgroundTransparency = WindowAPI_Trans_W
            TabList.BackgroundTransparency = WindowAPI_Trans_W
        end
        if elemT then
            if elemT>1 then elemT=elemT/100 end
            WindowAPI_Trans_E = math.clamp(elemT,0,0.7)
            for _,b in ipairs(TabList:GetChildren()) do if b:IsA("TextButton") then b.BackgroundTransparency = WindowAPI_Trans_E end end
            for _,page in ipairs(Container:GetChildren()) do
                if page:IsA("ScrollingFrame") then
                    for _,v in ipairs(page:GetDescendants()) do
                        if v:IsA("Frame") or v:IsA("TextButton") then
                            if v.BackgroundColor3==CurrentTheme.ElementBg or v.BackgroundColor3==CurrentTheme.ElementBg2 or v.BackgroundColor3==CurrentTheme.TabListBg then
                                v.BackgroundTransparency = WindowAPI_Trans_E
                            end
                        end
                    end
                end
            end
        end
    end
    function Window:Update(newCfg)
        newCfg = newCfg or {}
        if newCfg.Title then TitleLabel.Text = newCfg.Title end
        if newCfg.Icon ~= nil then ApplyTitleIcon(newCfg.Icon) end
        if newCfg.SubTitle then SubLabel.Text = newCfg.SubTitle end
        if newCfg.WindowTransparency or newCfg.ElementTransparency or newCfg.WindowTrans or newCfg.ElementTrans then
            self:SetTransparency(newCfg.WindowTransparency or newCfg.WindowTrans, newCfg.ElementTransparency or newCfg.ElementTrans)
        end
        if newCfg.Theme and Themes[newCfg.Theme] then
            ApplyTheme(newCfg.Theme)
        end
    end
    function Window:Refresh() self:Update({}) end
    function Window:ClearAllTabs()
        for _,b in ipairs(TabList:GetChildren()) do if b:IsA("TextButton") then b:Destroy() end end
        for _,p in ipairs(Container:GetChildren()) do if p:IsA("ScrollingFrame") then p:Destroy() end end
        table.clear(Tabs)
        table.clear(TabsByName)
        table.clear(AllSearchElements)
        FirstTab = true
        if SearchBox then SearchBox.Text = "" end
    end
    function Window:RemoveTab(name)
        local tab = TabsByName[name]
        if tab then
            local wasActive = tab.Page.Visible
            local removedIndex
            for index, existing in ipairs(Tabs) do
                if existing == tab then
                    removedIndex = index
                    break
                end
            end
            tab.Button:Destroy()
            tab.Page:Destroy()
            TabsByName[name] = nil
            if removedIndex then table.remove(Tabs, removedIndex) end
            if #Tabs == 0 then
                FirstTab = true
            elseif wasActive then
                local nextTab = Tabs[math.min(removedIndex or 1, #Tabs)]
                nextTab.Page.Visible = true
                Tween(nextTab.Button, {BackgroundColor3 = CurrentTheme.Accent}, 0.15)
                nextTab.Button.TextColor3 = Color3.fromRGB(255,255,255)
            end
        end
    end

    function Window:Destroy()
        SmoothDestroy(ScreenGui)
    end
    function Window:Close()
        if GGH_Closing then return end
        GGH_Closing = true
        pcall(function() ConfirmFrame.Visible = false end)
        FadeOutGui(ScreenGui, 0.4, function() SmoothDestroy(ScreenGui) end)
    end
    function Window:Hide() Main.Visible = false end
    function Window:Show() Main.Visible = true end
    function Window:Toggle() Main.Visible = not Main.Visible end
    function Window:HideButton(name)
        local n = string.lower(tostring(name))
        if n == "search" and SearchBtn then SearchBtn.Visible = false end
        if (n == "theme" or n == "settings") and ThemeBtn then ThemeBtn.Visible = false end
        if (n == "float" or n == "floating") and FloatBtn then FloatBtn.Visible = false end
    end
    function Window:ShowButton(name)
        local n = string.lower(tostring(name))
        if n == "search" and SearchBtn then SearchBtn.Visible = true end
        if (n == "theme" or n == "settings") and ThemeBtn then ThemeBtn.Visible = true end
        if (n == "float" or n == "floating") and FloatBtn then FloatBtn.Visible = true end
    end
    function Window:SetTheme(name)
        if Themes[name] then ApplyTheme(name) SubLabel.Text = "Theme: "..name SaveMgr.MarkDirty() end
    end
    function Window:GetThemes()
        local t = {}
        for k,_ in pairs(Themes) do table.insert(t,k) end
        table.sort(t)
        return t
    end
    function Window:CreateThemeDropdown(Cfg)
        Cfg = Cfg or {}
        local targetPage = Cfg.Parent
        if not targetPage or not targetPage:IsA("ScrollingFrame") then
            for _, tb in pairs(Tabs) do if tb.Page then targetPage = tb.Page break end end
        end
        local themeNames = {}
        for n,_ in pairs(Themes) do table.insert(themeNames, n) end
        table.sort(themeNames)
        local Frame = Instance.new("Frame", targetPage)
        Frame.Size = UDim2.new(1,-4,0,38)
        Frame.BackgroundColor3 = CurrentTheme.ElementBg
        Frame.ClipsDescendants = true
        Corner(Frame, 10)
        local Btn = Instance.new("TextButton", Frame)
        Btn.Size = UDim2.new(1,0,0,38)
        Btn.BackgroundTransparency = 1
        RegisterThemable(Frame, "BackgroundColor3", "ElementBg")
        Btn.Text = (Cfg.Title or "Theme").." : Dark"
        Btn.Font = Enum.Font.GothamMedium
        Btn.TextSize = 12
        Btn.TextColor3 = CurrentTheme.Text
        local List = Instance.new("ScrollingFrame", Frame)
        List.Position = UDim2.new(0,0,0,38)
        List.Size = UDim2.new(1,0,0,0)
        List.BackgroundTransparency = 1
        List.CanvasSize = UDim2.new(0,0,0, #themeNames*32)
        List.ScrollBarThickness = 3
        List.ScrollBarImageColor3 = CurrentTheme.Accent
        local ll = Instance.new("UIListLayout", List)
        ll.Padding = UDim.new(0,2)
        local Open = false
        Btn.MouseButton1Click:Connect(function()
            Open = not Open
            if Open then
                local h = math.clamp(#themeNames*30, 30, 180)
                List.Size = UDim2.new(1,0,0,h)
                Frame.Size = UDim2.new(1,-4,0, 38 + h + 6)
            else
                Frame.Size = UDim2.new(1,-4,0,38)
            end
        end)
        for _, thName in ipairs(themeNames) do
            local O = Instance.new("TextButton", List)
            O.Size = UDim2.new(1,-4,0,28)
            O.BackgroundColor3 = CurrentTheme.ElementBg2
            RegisterThemable(O, "BackgroundColor3", "ElementBg2")
            RegisterThemable(O, "TextColor3", "Text")
            O.Text = thName
            O.Font = Enum.Font.Gotham
            O.TextSize = 11
            O.TextColor3 = CurrentTheme.Text
            Corner(O, 6)
            O.MouseButton1Click:Connect(function()
                Window:SetTheme(thName)
                Btn.Text = (Cfg.Title or "Theme").." : "..thName
                Open = false
                Frame.Size = UDim2.new(1,-4,0,38)
                if Cfg.Callback then pcall(Cfg.Callback, thName) end
            end)
        end
        return {}
    end
    function Window:CreateDestroyButton(Cfg)
        Cfg = Cfg or {}
        local targetPage = Cfg.Parent
        if not targetPage or not targetPage:IsA("ScrollingFrame") then
            for _, tb in pairs(Tabs) do if tb.Page then targetPage = tb.Page break end end
        end
        local Btn = Instance.new("TextButton", targetPage)
        Btn.Size = UDim2.new(1,-4,0,34)
        Btn.BackgroundColor3 = Color3.fromRGB(80,30,35)
        Btn.Text = Cfg.Title or "Destroy UI"
        Btn.Font = Enum.Font.GothamBold
        Btn.TextSize = 13
        Btn.TextColor3 = Color3.new(1,1,1)
        Corner(Btn, 8)
        Btn.MouseButton1Click:Connect(function()
            if Cfg.Callback then pcall(Cfg.Callback) end
            Window:Destroy()
        end)
        return Btn
    end
    function Window:GetTab(name) return TabsByName[name] end
    function Window:SetIcon(icon) ApplyTitleIcon(icon) return Window end
    function Window:SetSaveEnabled(state) return SaveMgr.SetEnabled(state) end
    function Window:GetSaveEnabled() return SaveMgr.Enabled end
    function Window:SaveNow() SaveMgr.Flush() return Window end
    function Window:GetConfigPath() return SaveMgr.Path end

        return Window
end

end
