local Registry = {}

function Registry.new(context, constructors)
	context = context or {}
	constructors = constructors or {}
	local tabName = context.TabName or "Tab"
	local saveManager = context.SaveManager
	local elements = {}
	local allElements = {}

	local function registerElement(api, typeName, config)
		if api and type(api) == "table" then
			api.Type = typeName
			api.Config = config
			table.insert(allElements, api)
		end
		return api
	end

	function elements:Add(typeName, config)
		config = config or {}
		typeName = string.lower(tostring(typeName))
		local api
		local saveTypes = {
			toggle = true, slider = true, input = true, dropdown = true,
			colorpicker = true, color = true, keybind = true, key = true,
			sliderinput = true, sliderbox = true, inputslider = true,
		}
		local userCallback
		if saveTypes[typeName] then
			userCallback = config.Callback or config.OnChanged
			config.Callback = function(...)
				if saveManager and saveManager.MarkDirty then
					saveManager.MarkDirty()
				end
				if userCallback then
					return userCallback(...)
				end
			end
		end

		local create = constructors
		if typeName == "section" then api = create.Section(config)
		elseif typeName == "paragraph" then api = create.Paragraph(config)
		elseif typeName == "button" then api = create.Button(config)
		elseif typeName == "toggle" then api = create.Toggle(config)
		elseif typeName == "slider" then api = create.Slider(config)
		elseif typeName == "input" then api = create.Input(config)
		elseif typeName == "dropdown" then api = create.Dropdown(config)
		elseif typeName == "colorpicker" or typeName == "color" then api = create.Colorpicker(config)
		elseif typeName == "keybind" or typeName == "key" then api = create.Keybind(config)
		elseif typeName == "code" then api = create.Code(config)
		elseif typeName == "label" then api = create.Label(config)
		elseif typeName == "separator" or typeName == "line" or typeName == "divider" then api = create.Separator(config)
		elseif typeName == "image" or typeName == "img" or typeName == "logo" then api = create.Image(config)
		elseif typeName == "linkbutton" or typeName == "link" or typeName == "social" or typeName == "discord" or typeName == "copylink" then api = create.LinkButton(config)
		elseif typeName == "playerstats" or typeName == "stats" or typeName == "statlist" or typeName == "player" then api = create.PlayerStats(config)
		elseif typeName == "floatbutton" or typeName == "buttonfloat" or typeName == "btnfloat" or typeName == "floatingbutton" then api = create.FloatingButton(config)
		elseif typeName == "sliderinput" or typeName == "sliderbox" or typeName == "inputslider" then api = create.SliderInput(config)
		else warn("[GGH Library v1.9] Unknown Add type: " .. tostring(typeName))
		end

		if api and type(api) == "table" and not api.Refresh then
			function api:Refresh(newConfig)
				if newConfig and type(newConfig) == "table" then
					for key, value in pairs(newConfig) do
						config[key] = value
					end
				end
				return api
			end
		end

		local isFloatingButton = typeName == "floatbutton" or typeName == "buttonfloat"
			or typeName == "btnfloat" or typeName == "floatingbutton"
		if api and saveManager and saveManager.RegisterElement and (saveTypes[typeName] or isFloatingButton) then
			pcall(saveManager.RegisterElement, tabName, typeName, config, api, userCallback)
		end
		return registerElement(api, typeName, config)
	end

	function elements:RefreshAll()
		for _, element in ipairs(allElements) do
			if element and element.Refresh then
				pcall(function()
					element:Refresh()
				end)
			end
		end
	end

	function elements:GetAll()
		return allElements
	end

	function elements:Section(config) return self:Add("Section", config) end
	function elements:Paragraph(config) return self:Add("Paragraph", config) end
	function elements:Button(config) return self:Add("Button", config) end
	function elements:Toggle(config) return self:Add("Toggle", config) end
	function elements:Slider(config) return self:Add("Slider", config) end
	function elements:Input(config) return self:Add("Input", config) end
	function elements:Dropdown(config) return self:Add("Dropdown", config) end
	function elements:Colorpicker(config) return self:Add("Colorpicker", config) end
	function elements:Keybind(config) return self:Add("Keybind", config) end
	function elements:Code(config) return self:Add("Code", config) end
	function elements:Label(config) return self:Add("Label", config) end
	function elements:Separator(config) return self:Add("Separator", config) end
	function elements:Image(config) return self:Add("Image", config) end
	function elements:LinkButton(config) return self:Add("LinkButton", config) end
	function elements:Link(config) return self:Add("LinkButton", config) end
	function elements:Social(config) return self:Add("LinkButton", config) end
	function elements:CopyLink(config) return self:Add("LinkButton", config) end
	function elements:PlayerStats(config) return self:Add("PlayerStats", config) end
	function elements:Stats(config) return self:Add("PlayerStats", config) end
	function elements:StatList(config) return self:Add("PlayerStats", config) end
	function elements:FloatButton(config) return self:Add("FloatButton", config) end
	function elements:ButtonFloat(config) return self:Add("FloatButton", config) end
	function elements:FloatingButton(config) return self:Add("FloatButton", config) end
	function elements:SliderInput(config) return self:Add("SliderInput", config) end
	function elements:SliderBox(config) return self:Add("SliderInput", config) end

	return elements
end

return Registry