return function(GGH)
local TweenService = game:GetService("TweenService")
local CoreGui = game:GetService("CoreGui")
local ResolveIcon = GGH.ResolveIcon
local function MakeIcon(parent, icon, size, color)
    local img = Instance.new("ImageLabel")
    img.Name = "Icon"
    img.BackgroundTransparency = 1
    img.BorderSizePixel = 0
    img.Size = UDim2.fromOffset(size or 16, size or 16)
    img.Image = ResolveIcon(icon) or ""
    img.ImageColor3 = color or Color3.new(1, 1, 1)
    img.ScaleType = Enum.ScaleType.Fit
    img.Parent = parent
    return img
end

local function BindIconToText(btn, img)
    img.ImageColor3 = btn.TextColor3
    btn:GetPropertyChangedSignal("TextColor3"):Connect(function()
        img.ImageColor3 = btn.TextColor3
    end)
end

local function GetGuiParent()
    local ok, hui = pcall(function() return gethui() end)
    if ok and hui then return hui end
    return CoreGui
end

    local function MakeTranslatable(textObj)
        if textObj:IsA("TextLabel") or textObj:IsA("TextButton") or textObj:IsA("TextBox") then
            textObj.AutoLocalize = true
            pcall(function() textObj.RichText = false end)
        end
        return textObj
    end

    local function Corner(p,r)
    local c = Instance.new("UICorner")
    c.CornerRadius = UDim.new(0, r or 8)
    c.Parent = p
    return c
end

local function Stroke(p,color,thick)
    local s = Instance.new("UIStroke")
    s.Color = color or Color3.fromRGB(40,40,50)
    s.Thickness = thick or 1
    s.Parent = p
    return s
end

local function AddTextStroke(txtObj)
    if not txtObj then return end
    local st = Instance.new("UIStroke", txtObj)
    st.Color = Color3.fromRGB(0,0,0)
    st.Thickness = 1.1
    st.Transparency = 0.4
    st.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
    st.LineJoinMode = Enum.LineJoinMode.Round
    return st
end

local function SoftStroke(frame, color)
    local s = Instance.new("UIStroke")
    s.Color = color or Color3.fromRGB(60,60,70)
    s.Thickness = 1
    s.Transparency = 0.55
    s.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    s.Parent = frame
    return s
end

local function AddBlackBorder(frame, thick, trans)
    if not frame then return end
    local s = Instance.new("UIStroke", frame)
    s.Color = Color3.fromRGB(0,0,0)
    s.Thickness = thick or 1
    s.Transparency = trans or 0.6
    s.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    return s
end

local function Tween(o,props,dur)
    TweenService:Create(o, TweenInfo.new(dur or 0.22, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), props):Play()
end

local function ClampFrameToScreen(frame, gui)
    if not frame or not gui then return end
    local viewport = gui.AbsoluteSize
    if viewport.X <= 10 or viewport.Y <= 10 then return end
    local fSize = frame.AbsoluteSize
    if fSize.X <= 0 then return end
    local fPos = frame.Position
    local newX, newY
    if fPos.X.Scale == 0 and fPos.Y.Scale == 0 then
        newX = math.clamp(fPos.X.Offset, 0, viewport.X - fSize.X)
        newY = math.clamp(fPos.Y.Offset, 0, viewport.Y - fSize.Y)
        frame.Position = UDim2.fromOffset(newX, newY)
    else
        local absX = fPos.X.Scale * viewport.X + fPos.X.Offset
        local absY = fPos.Y.Scale * viewport.Y + fPos.Y.Offset
        absX = math.clamp(absX, 0, viewport.X - fSize.X)
        absY = math.clamp(absY, 0, viewport.Y - fSize.Y)
        frame.Position = UDim2.fromOffset(absX, absY)
    end
end

local function GetSafePickerPosition(anchorBtn, pickerSize, screenGui)
    local vp = screenGui.AbsoluteSize
    local btnPos = anchorBtn.AbsolutePosition
    local btnSize = anchorBtn.AbsoluteSize
    local pW, pH = pickerSize.X, pickerSize.Y
    local x = btnPos.X + btnSize.X + 10
    local y = btnPos.Y
    if x + pW > vp.X - 5 then x = btnPos.X - pW - 10 end
    if y + pH > vp.Y - 5 then y = vp.Y - pH - 10 end
    x = math.clamp(x, 5, vp.X - pW - 5)
    y = math.clamp(y, 5, vp.Y - pH - 5)
    return UDim2.fromOffset(x, y)
end

local function ContrastColor(c)
    local lum = 0.299*c.R + 0.587*c.G + 0.114*c.B
    if lum > 0.62 then return Color3.fromRGB(20,20,26) end
    return Color3.new(1,1,1)
end

local RunService = game:GetService("RunService")

local function SmoothDestroy(gui)
    pcall(function() if gui:IsA("ScreenGui") then gui.Enabled = false end end)
    task.spawn(function()
        local ok, list = pcall(function() return gui:GetDescendants() end)
        if not ok then pcall(function() gui:Destroy() end) return end
        local budget = 0.004
        local t0 = os.clock()
        for i = #list, 1, -1 do
            local o = list[i]
            pcall(function() o:Destroy() end)
            if os.clock() - t0 > budget then
                RunService.Heartbeat:Wait()
                t0 = os.clock()
            end
        end
        pcall(function() gui:Destroy() end)
    end)
end

local function FadeOutGui(gui, dur, done)
    dur = dur or 0.4
    local info = TweenInfo.new(dur, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
    local function tw(o, props)
        pcall(function() TweenService:Create(o, info, props):Play() end)
    end
    local function simpleFade(root)
        for _, d in ipairs(root:GetDescendants()) do
            if d:IsA("GuiObject") then
                local props = {}
                if d.BackgroundTransparency < 1 then props.BackgroundTransparency = 1 end
                if d:IsA("TextLabel") or d:IsA("TextButton") or d:IsA("TextBox") then props.TextTransparency = 1 end
                if d:IsA("ImageLabel") or d:IsA("ImageButton") then props.ImageTransparency = 1 end
                if next(props) then tw(d, props) end
            elseif d:IsA("UIStroke") then
                tw(d, {Transparency = 1})
            end
        end
    end
    for _, top in ipairs(gui:GetChildren()) do
        if top:IsA("GuiObject") then
            local count = #top:GetDescendants()
            if count <= 40 then
                simpleFade(top)
                if top.BackgroundTransparency < 1 then tw(top, {BackgroundTransparency = 1}) end
            else
                local ok = pcall(function()
                    local cg = Instance.new("CanvasGroup")
                    cg.Name = "GGH_FadeGroup"
                    cg.BackgroundTransparency = 1
                    cg.BorderSizePixel = 0
                    cg.Size = UDim2.fromScale(1, 1)
                    cg.ZIndex = 1
                    local corner = top:FindFirstChildOfClass("UICorner")
                    if corner then
                        local c2 = Instance.new("UICorner")
                        c2.CornerRadius = corner.CornerRadius
                        c2.Parent = cg
                    end
                    for _, ch in ipairs(top:GetChildren()) do
                        if ch:IsA("GuiObject") then ch.Parent = cg end
                    end
                    cg.Parent = top
                    tw(cg, {GroupTransparency = 1})
                    if top.BackgroundTransparency < 1 then tw(top, {BackgroundTransparency = 1}) end
                    for _, ch in ipairs(top:GetChildren()) do
                        if ch:IsA("UIStroke") then tw(ch, {Transparency = 1}) end
                    end
                end)
                if not ok then
                    if top.BackgroundTransparency < 1 then tw(top, {BackgroundTransparency = 1}) end
                end
            end
        end
    end
    task.delay(dur + 0.05, function() if done then pcall(done) end end)
end

return {
    MakeIcon = MakeIcon, BindIconToText = BindIconToText, GetGuiParent = GetGuiParent,
    MakeTranslatable = MakeTranslatable, Corner = Corner, Stroke = Stroke,
    AddTextStroke = AddTextStroke, SoftStroke = SoftStroke, AddBlackBorder = AddBlackBorder,
    Tween = Tween, ClampFrameToScreen = ClampFrameToScreen, GetSafePickerPosition = GetSafePickerPosition,
    ContrastColor = ContrastColor, SmoothDestroy = SmoothDestroy, FadeOutGui = FadeOutGui,
}
end
