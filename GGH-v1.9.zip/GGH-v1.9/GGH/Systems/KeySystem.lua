return function(GGH, Modules)
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local HttpService = game:GetService("HttpService")
local Themes = Modules.Themes
local Utils = Modules.Utils
local GetGuiParent = Utils.GetGuiParent
local Corner = Utils.Corner
local Stroke = Utils.Stroke
local Tween = Utils.Tween
function GGH:GetHWID()
    local hwid = "UNKNOWN"
    pcall(function()
        if gethwid then hwid = gethwid()
        elseif syn and syn.get_hwid then hwid = syn.get_hwid()
        else
            local ok, id = pcall(function() return game:GetService("RbxAnalyticsService"):GetClientId() end)
            if ok and id then hwid = id end
        end
    end)
    return tostring(hwid)
end

function GGH:MakeKeySystem(Config)
    Config = Config or {}
    if type(Config) ~= "table" then
        error("[GGH v1.9] MakeKeySystem expects a configuration table.", 2)
    end
    local Title = tostring(Config.Title or "Key System")
    local Description = tostring(Config.Description or "Enter your key to continue")
    local GetKeyUrl = Config.GetKeyUrl or Config.GetKeyLink or Config.KeyLink or ""
    local DiscordUrl = Config.DiscordUrl or Config.ServerUrl or Config.Discord or ""
    local CustomKeys = Config.Keys or Config.ValidKeys or Config.CustomKeys or {}
    if type(CustomKeys) == "string" then
        CustomKeys = {CustomKeys}
    elseif type(CustomKeys) ~= "table" then
        CustomKeys = {}
    end
    local RawUrl = Config.RawUrl or Config.PastebinUrl or Config.GitHubUrl or ""
    local APIUrl = Config.APIUrl or Config.ApiUrl or ""
    if type(RawUrl) ~= "string" then RawUrl = "" end
    if type(APIUrl) ~= "string" then APIUrl = "" end
    local SaveKey = Config.SaveKey ~= false
    local FileName = Config.FileName or Config.SaveFileName or "GGH_Key.txt"
    local UseHWID = Config.UseHWID or Config.HWID or false
    local HWIDList = Config.HWIDList or {}
    if type(HWIDList) == "string" then
        HWIDList = {HWIDList}
    elseif type(HWIDList) ~= "table" then
        HWIDList = {}
    end
    local OnSuccess = Config.OnSuccess or Config.SuccessCallback or function() end
    local OnFail = Config.OnFailed or Config.OnFail or function() end
    if type(OnSuccess) ~= "function" then
        error("[GGH v1.9] OnSuccess must be a function.", 2)
    end
    if type(OnFail) ~= "function" then
        error("[GGH v1.9] OnFail must be a function.", 2)
    end
    local ThemeName = Config.Theme or "Dark"
    local CurrentTheme = table.clone(Themes[ThemeName] or Themes["Dark"])

    local function HttpGet(url)
        local success, result = pcall(function()
            if syn and syn.request then
                return syn.request({Url = url, Method = "GET"})
            elseif http_request then
                return http_request({Url = url, Method = "GET"})
            elseif request then
                return request({Url = url, Method = "GET"})
            elseif http and http.request then
                return http.request({Url = url, Method = "GET"})
            else
                return game:HttpGet(url)
            end
        end)
        if not success then return nil end
        if type(result) == "string" then return result end
        if type(result) == "table" then
            local statusCode = tonumber(result.StatusCode or result.Status)
            if (statusCode and (statusCode < 200 or statusCode >= 300)) or result.Success == false then
                return nil
            end
            if type(result.Body) == "string" then return result.Body end
        end
        return nil
    end

    local function ValidateKey(inputKey)
        if inputKey == nil or tostring(inputKey) == "" then return false, "Empty key" end
        inputKey = tostring(inputKey):gsub("^%s+", ""):gsub("%s+$", "")
        if inputKey == "" then return false, "Empty key" end

        if #CustomKeys == 0 and APIUrl == "" and RawUrl == "" and not UseHWID then
            return false, "No key validation source configured"
        end

        if #CustomKeys > 0 then
            for _, k in pairs(CustomKeys) do
                if tostring(k) == inputKey then
                    return true
                end
            end
        end

        if APIUrl and APIUrl ~= "" then
            local encodedKey = HttpService:UrlEncode(inputKey)
            local url, keyCount = APIUrl:gsub("{key}", function() return encodedKey end)
            local upperUrl, upperCount = url:gsub("{KEY}", function() return encodedKey end)
            url = upperUrl
            local formatUrl, formatCount = url:gsub("%%s", function() return encodedKey end)
            url = formatUrl
            if keyCount + upperCount + formatCount == 0 then
                if url:find("?", 1, true) then
                    url = url .. "&key=" .. encodedKey
                else
                    url = url .. "?key=" .. encodedKey
                end
            end
            local body = HttpGet(url)
            if body then
                local lower = string.lower(body)
                local ok, decoded = pcall(function() return HttpService:JSONDecode(body) end)
                if ok and type(decoded) == "table" then
                    if decoded.valid == true or decoded.success == true or decoded.Valid == true or decoded.status == "valid" then
                        return true
                    end
                elseif lower:match("^%s*true%s*$") or lower:match("^%s*valid%s*$") then
                    return true
                end
            end
        end

        if RawUrl and RawUrl ~= "" then
            local body = HttpGet(RawUrl)
            if body then
                for line in body:gmatch("[^\r\n]+") do
                    if line:gsub("%s+", "") == inputKey then
                        return true
                    end
                end
            end
        end

        if UseHWID then
            local currentHwid = GGH:GetHWID()
            if #HWIDList > 0 then
                for _, v in pairs(HWIDList) do
                    if tostring(v) == currentHwid or tostring(v) == inputKey then
                        return true
                    end
                end
            end
        end

        return false, "Invalid key"
    end

    local GuiParent = GetGuiParent()
    if GuiParent:FindFirstChild("GGH_KeySystem") then GuiParent:FindFirstChild("GGH_KeySystem"):Destroy() end

    local ScreenGui = Instance.new("ScreenGui")
    ScreenGui.Name = "GGH_KeySystem"
    ScreenGui.ResetOnSpawn = false
    ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    ScreenGui.Parent = GuiParent

    local Main = Instance.new("Frame", ScreenGui)
    Main.Size = UDim2.new(0, 380, 0, 270)
    Main.Position = UDim2.new(0.5, -190, 0.5, -135)
    Main.BackgroundColor3 = CurrentTheme.MainBg
    Main.BorderSizePixel = 0
    Main.ClipsDescendants = true
    Main.Active = true
    Main.Draggable = true
    Corner(Main, 12)
    Stroke(Main, CurrentTheme.Stroke, 1)

    local Header = Instance.new("Frame", Main)
    Header.Size = UDim2.new(1,0,0,48)
    Header.BackgroundColor3 = CurrentTheme.HeaderBg
    Corner(Header, 12)
    local HeaderFix = Instance.new("Frame", Header)
    HeaderFix.Size = UDim2.new(1,0,0,12)
    HeaderFix.Position = UDim2.new(0,0,1,-6)
    HeaderFix.BackgroundColor3 = CurrentTheme.HeaderBg
    HeaderFix.BorderSizePixel = 0

    local TitleLabel = Instance.new("TextLabel", Header)
    TitleLabel.Size = UDim2.new(1,-20,1,0)
    TitleLabel.Position = UDim2.new(0,15,0,0)
    TitleLabel.BackgroundTransparency = 1
    TitleLabel.Text = Title
    TitleLabel.Font = Enum.Font.GothamBold
    TitleLabel.TextSize = 16
    TitleLabel.TextColor3 = CurrentTheme.Text
    TitleLabel.TextXAlignment = Enum.TextXAlignment.Left

    local Desc = Instance.new("TextLabel", Main)
    Desc.Size = UDim2.new(1,-30,0,20)
    Desc.Position = UDim2.new(0,15,0,58)
    Desc.BackgroundTransparency = 1
    Desc.Text = Description
    Desc.Font = Enum.Font.Gotham
    Desc.TextSize = 12
    Desc.TextColor3 = CurrentTheme.SubText
    Desc.TextXAlignment = Enum.TextXAlignment.Left

    local InputFrame = Instance.new("Frame", Main)
    InputFrame.Size = UDim2.new(1,-30,0,42)
    InputFrame.Position = UDim2.new(0,15,0,88)
    InputFrame.BackgroundColor3 = CurrentTheme.ElementBg
    Corner(InputFrame, 8)
    Stroke(InputFrame, CurrentTheme.StrokeLight, 1)

    local InputBox = Instance.new("TextBox", InputFrame)
    InputBox.Size = UDim2.new(1,-16,1,0)
    InputBox.Position = UDim2.new(0,8,0,0)
    InputBox.BackgroundTransparency = 1
    InputBox.PlaceholderText = "Enter Key Here..."
    InputBox.Text = ""
    InputBox.Font = Enum.Font.Gotham
    InputBox.TextSize = 13
    InputBox.TextColor3 = CurrentTheme.Text
    InputBox.PlaceholderColor3 = CurrentTheme.SubText
    InputBox.ClearTextOnFocus = false

    local StatusLabel = Instance.new("TextLabel", Main)
    StatusLabel.Size = UDim2.new(1,-30,0,18)
    StatusLabel.Position = UDim2.new(0,15,0,135)
    StatusLabel.BackgroundTransparency = 1
    StatusLabel.Text = ""
    StatusLabel.Font = Enum.Font.GothamMedium
    StatusLabel.TextSize = 11
    StatusLabel.TextColor3 = Color3.fromRGB(255,100,100)
    StatusLabel.TextXAlignment = Enum.TextXAlignment.Left

    local SubmitBtn = Instance.new("TextButton", Main)
    SubmitBtn.Size = UDim2.new(1,-30,0,40)
    SubmitBtn.Position = UDim2.new(0,15,0,160)
    SubmitBtn.BackgroundColor3 = CurrentTheme.Accent
    SubmitBtn.Text = "Unlock"
    SubmitBtn.Font = Enum.Font.GothamBold
    SubmitBtn.TextSize = 14
    SubmitBtn.TextColor3 = Color3.new(1,1,1)
    Corner(SubmitBtn, 8)

    local BottomRow = Instance.new("Frame", Main)
    BottomRow.Size = UDim2.new(1,-30,0,38)
    BottomRow.Position = UDim2.new(0,15,0,210)
    BottomRow.BackgroundTransparency = 1

    local function CreateBottomBtn(text, pos, size)
        local btn = Instance.new("TextButton", BottomRow)
        btn.Size = size
        btn.Position = pos
        btn.BackgroundColor3 = CurrentTheme.ElementBg2
        btn.Text = text
        btn.Font = Enum.Font.GothamMedium
        btn.TextSize = 12
        btn.TextColor3 = CurrentTheme.Text
        Corner(btn, 8)
        Stroke(btn, CurrentTheme.Stroke, 1)
        return btn
    end

    local GetKeyBtn = CreateBottomBtn("Get Key", UDim2.new(0,0,0,0), UDim2.new(0.5,-4,1,0))
    local DiscordBtn = CreateBottomBtn("Copy Server", UDim2.new(0.5,4,0,0), UDim2.new(0.5,-4,1,0))

    pcall(function()
        if SaveKey and isfile and isfile(FileName) then
            local saved = readfile(FileName)
            if saved and saved ~= "" then
                InputBox.Text = saved
                local valid = ValidateKey(saved)
                if valid then
                    ScreenGui:Destroy()
                    OnSuccess(saved)
                    return
                end
            end
        end
    end)

    local function SetStatus(text, color)
        StatusLabel.Text = text
        StatusLabel.TextColor3 = color or Color3.fromRGB(255,100,100)
    end

    SubmitBtn.MouseButton1Click:Connect(function()
        local key = InputBox.Text
        if key == "" then SetStatus("Please enter a key") return end
        SetStatus("Checking...", CurrentTheme.SubText)
        Tween(SubmitBtn, {BackgroundColor3 = Color3.fromRGB(70,70,80)}, 0.1)

        task.wait(0.2)
        local valid, err = ValidateKey(key)
        if valid then
            SetStatus("Success! Loading...", Color3.fromRGB(80,255,120))
            if SaveKey then
                pcall(function()
                    if writefile then writefile(FileName, key) end
                end)
            end
            Tween(Main, {Size = UDim2.new(0, 380, 0, 0)}, 0.25)
            task.wait(0.26)
            ScreenGui:Destroy()
            OnSuccess(key)
        else
            SetStatus("Invalid Key! Please try again.", Color3.fromRGB(255,80,80))
            OnFail(err)
            local orig = Main.Position
            for i=1,3 do
                Tween(Main, {Position = orig + UDim2.new(0,5,0,0)}, 0.05)
                task.wait(0.05)
                Tween(Main, {Position = orig + UDim2.new(0,-5,0,0)}, 0.05)
                task.wait(0.05)
            end
            Tween(Main, {Position = orig}, 0.08)
            Tween(SubmitBtn, {BackgroundColor3 = CurrentTheme.Accent}, 0.2)
        end
    end)

    GetKeyBtn.MouseButton1Click:Connect(function()
        if GetKeyUrl and GetKeyUrl ~= "" then
            pcall(function() setclipboard(GetKeyUrl) end)
            SetStatus("Link copied to clipboard!", Color3.fromRGB(80,200,255))
        else
            SetStatus("No key link set by developer", Color3.fromRGB(255,200,80))
        end
    end)

    DiscordBtn.MouseButton1Click:Connect(function()
        if DiscordUrl and DiscordUrl ~= "" then
            pcall(function() setclipboard(DiscordUrl) end)
            SetStatus("Server link copied!", Color3.fromRGB(80,200,255))
        else
            SetStatus("No server link set", Color3.fromRGB(255,200,80))
        end
    end)

    SubmitBtn.MouseEnter:Connect(function() Tween(SubmitBtn, {BackgroundColor3 = Color3.fromRGB(CurrentTheme.Accent.R*255+20, CurrentTheme.Accent.G*255+20, CurrentTheme.Accent.B*255+20)}, 0.15) end)
    SubmitBtn.MouseLeave:Connect(function() Tween(SubmitBtn, {BackgroundColor3 = CurrentTheme.Accent}, 0.15) end)

    return ScreenGui
end

GGH.CreateKey = GGH.MakeKeySystem
GGH.KeySystem = GGH.MakeKeySystem
GGH.AddKeySystem = GGH.MakeKeySystem

end
