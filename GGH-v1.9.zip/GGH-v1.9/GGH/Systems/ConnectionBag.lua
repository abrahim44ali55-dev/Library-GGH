local ConnectionBag = {}

function ConnectionBag.new()
	local connections = {}
	local cleanups = {}
	local disposed = false
	local bag = {}

	function bag:Add(connection)
		if not connection then
			return connection
		end
		if disposed then
			pcall(function()
				connection:Disconnect()
			end)
			return connection
		end
		table.insert(connections, connection)
		return connection
	end

	function bag:Connect(signal, callback)
		return self:Add(signal:Connect(callback))
	end

	function bag:AddCleanup(callback)
		if type(callback) ~= "function" then
			return
		end
		if disposed then
			pcall(callback)
			return
		end
		table.insert(cleanups, callback)
	end

	function bag:Destroy()
		if disposed then
			return
		end
		disposed = true
		for index = #connections, 1, -1 do
			pcall(function()
				connections[index]:Disconnect()
			end)
		end
		table.clear(connections)
		for index = #cleanups, 1, -1 do
			pcall(cleanups[index])
		end
		table.clear(cleanups)
	end

	return bag
end

return ConnectionBag