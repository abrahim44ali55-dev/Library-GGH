local Workspace = game:GetService("Workspace")
local Viewport = {}

local function getViewport(screenGui)
	local guiSize = screenGui and screenGui.AbsoluteSize
	if guiSize and guiSize.X > 10 and guiSize.Y > 10 then
		return guiSize
	end
	local camera = Workspace.CurrentCamera
	return camera and camera.ViewportSize or Vector2.new(1920, 1080)
end

function Viewport.ClampPosition(frame, screenGui, position, mode, padding)
	if not frame or not screenGui or not position then
		return position
	end

	padding = tonumber(padding) or 0
	local viewport = getViewport(screenGui)
	local size = frame.AbsoluteSize
	if size.X <= 0 or size.Y <= 0 then
		size = Vector2.new(frame.Size.X.Offset, frame.Size.Y.Offset)
	end

	local minX, minY = padding, padding
	local maxX = viewport.X - size.X - padding
	local maxY = viewport.Y - size.Y - padding
	if mode == "partial" then
		minX = -size.X * 0.5
		minY = -size.Y * 0.5
		maxX = viewport.X - size.X * 0.5
		maxY = viewport.Y - size.Y * 0.5
	end
	maxX = math.max(minX, maxX)
	maxY = math.max(minY, maxY)

	local x = position.X.Scale * viewport.X + position.X.Offset
	local y = position.Y.Scale * viewport.Y + position.Y.Offset
	x = math.clamp(x, minX, maxX)
	y = math.clamp(y, minY, maxY)
	return UDim2.fromOffset(x, y)
end

function Viewport.Attach(screenGui, frame, resources, mode, padding)
	if not screenGui or not frame or not resources then
		return function() end
	end

	local cameraConnection
	local function enforce()
		if not screenGui.Parent or not frame.Parent then
			return
		end
		local position = Viewport.ClampPosition(frame, screenGui, frame.Position, mode, padding)
		if math.abs(position.X.Offset - frame.Position.X.Offset) > 0.5
			or math.abs(position.Y.Offset - frame.Position.Y.Offset) > 0.5
			or frame.Position.X.Scale ~= 0
			or frame.Position.Y.Scale ~= 0 then
			frame.Position = position
		end
	end

	local function watchCamera(camera)
		if cameraConnection then
			cameraConnection:Disconnect()
			cameraConnection = nil
		end
		if camera then
			cameraConnection = resources:Connect(camera:GetPropertyChangedSignal("ViewportSize"), enforce)
		end
	end

	resources:Connect(frame:GetPropertyChangedSignal("AbsolutePosition"), enforce)
	resources:Connect(frame:GetPropertyChangedSignal("AbsoluteSize"), enforce)
	resources:Connect(screenGui:GetPropertyChangedSignal("AbsoluteSize"), enforce)
	resources:Connect(Workspace:GetPropertyChangedSignal("CurrentCamera"), function()
		watchCamera(Workspace.CurrentCamera)
		enforce()
	end)
	watchCamera(Workspace.CurrentCamera)
	resources:AddCleanup(function()
		if cameraConnection then
			cameraConnection:Disconnect()
			cameraConnection = nil
		end
	end)
	task.defer(enforce)
	return enforce
end

return Viewport